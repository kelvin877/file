<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\EnrollmentController;
use App\Http\Controllers\PayPalPaymentController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DiscussionController;
use App\Http\Controllers\EvaluationController;
use App\Http\Controllers\AssignmentController;
use App\Http\Controllers\CommunicationController;
use App\Http\Controllers\MessageController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PageController::class, 'index'])->name('home');



Route::get('/login', [StudentController::class, 'login'])->name('student.login');
Route::post('/login', [StudentController::class, 'studentLogin'])->name('student.login.post');
Route::get('/logout', [StudentController::class, 'studentLogout'])->name('student.logout');

Route::get('/login/reset', [StudentController::class, 'reset'])->name('student.login.reset');
Route::post('/login/reset', [StudentController::class, 'resetPost'])->name('student.login.reset.post');
Route::get('/login/reset/{student_id}/{student_reset_token}', [StudentController::class, 'resetPassword'])->where('student_id', '[0-9]+')->name('student.login.reset.password');
Route::post('/login/reset/{student_id}/{student_reset_token}', [StudentController::class, 'resetPasswordPost'])->where('student_id', '[0-9]+')->name('student.login.reset.password.post');


Route::get('/registration', [StudentController::class, 'registration_index'])->name('registration.index');
Route::post('/students', [StudentController::class, 'store'])->name('students.store');
Route::get('/students/verify/{confirmation_code}', [StudentController::class,'confirm'])->name('students.verify');



Route::get('/contact', [StudentController::class, 'contact'])->name('contact');

Route::post('/contact', [StudentController::class, 'contactPost'])->name('contact.post');


Route::get('/terms-conditions', [PageController::class, 'terms'])->name('terms');
Route::get('/privacy-policy', [PageController::class, 'policy'])->name('policy');
Route::get('/ceu', [PageController::class, 'ceu'])->name('ceu');






Route::group(['middleware' => 'auth.student'], function () {


    Route::get('/alumnis', [StudentController::class, 'alumnis'])->name('alumnis');


    Route::get('/student/profile/{student_id}', [StudentController::class, 'student_profile'])->name('student.info.profile');

    Route::post('/student/profile/upload/avatar/{student_id}', [StudentController::class, 'uploadAvatar'])->where('student_id', '[0-9]+')->name('student.avatar.upload');
    Route::delete('/student/profile/remove/avatar/{student_id}', [StudentController::class, 'removeAvatar'])->where('student_id', '[0-9]+')->name('student.avatar.remove');
    Route::get('/student/profile/avatar/{student_id}', [StudentController::class, 'showAvatar'])->where('student_id', '[0-9]+')->name('student.avatar.show');


    Route::get('/courses/{course_id}', [StudentController::class, 'checkCoursePermission'])->name('courses.test');

    Route::get('/courses/{course_slug}', [StudentController::class, 'course_description'])->name('courses.description');
    Route::get('/courses/{course_slug}/description', [StudentController::class, 'course_description'])->name('courses.description');

    Route::get('/courses/{course_slug}/participants', [StudentController::class, 'participants'])->name('courses.participants');
    Route::get('/courses/{course_slug}/modules/{module_id}', [StudentController::class, 'course_modules'])->where(['module_id'=>'[0-9]+'])->name('courses.modules.index');


    Route::get('/courses/{course_slug}/discussion', [DiscussionController::class, 'index'])->name('courses.discussion');
    Route::post('/courses/{course_slug}/discussion', [DiscussionController::class, 'store'])->name('courses.discussion.post');
    Route::get('/courses/{course_slug}/discussion/{discussion_id}', [DiscussionController::class, 'discussionComments'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.comments');
    Route::post('/courses/{course_slug}/discussion/{discussion_id}', [DiscussionController::class, 'commentStore'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.comment.post');
    Route::get('/delete/discussion/{discussion_id}', [DiscussionController::class, 'destroy'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.delete');
    Route::get('/delete/comment/{comment_id}', [DiscussionController::class, 'commentDestroy'])->where(['comment_id'=>'[0-9]+'])->name('courses.discussion.comment.delete');
    Route::get('/comment/{comment_id}', [DiscussionController::class, 'getComment'])->where(['comment_id'=>'[0-9]+'])->name('courses.discussion.comment');


    Route::get('/courses/{course_slug}/summary', [StudentController::class, 'course_summary'])->name('courses.summary');
    Route::get('/courses/{course_slug}/modules/{module_id}/sections/{section_id}/pages/{page}', [StudentController::class, 'course_page'])->where(['module_id'=>'[0-9]+','section_id'=>'[0-9]+','page'=>'[0-9]+'])->name('courses.page');


    Route::get('/courses/{course_id}/thumbnail', [StudentController::class, 'showCourseThumbnail'])->where(['course_id'=>'[0-9]+'])->name('courses.thumbnail.show');


    Route::get('/courses/{course_id}/modules/{module_id}/sections/{section_id}/thumbnail', [StudentController::class, 'showSectionThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('courses.sections.thumbnail.show');


    Route::post('/courses/quiz/{section_id}', [StudentController::class, 'quizSubmit'])->where('section_id','[0-9]+')->name('courses.quiz.post');


    Route::post('/courses/assignment_log/{log_id}/{assignment_id}/files', [StudentController::class, 'assignmentFilesUpload'])->where(['log_id'=>'[0-9]+','assignment_id'=>'[0-9]+'])->name('courses.assignment.files.upload');

    Route::get('/courses/assignment_log/{log_id}/{assignment_id}/file/{file}', [StudentController::class, 'displayAssignmentFile'])->where(['log_id'=>'[0-9]+','assignment_id'=>'[0-9]+'])->name('courses.assignment.file');
    Route::get('/courses/assignment_log/{log_id}/{assignment_id}/files', [StudentController::class, 'listAssignmentFolderContent'])->where(['log_id'=>'[0-9]+','assignment_id'=>'[0-9]+'])->name('courses.assignment.files');


    Route::delete('/courses/assignment_log/{log_id}/{assignment_id}/remove/file', [StudentController::class, 'removeAssignmentFile'])->where(['log_id'=>'[0-9]+','assignment_id'=>'[0-9]+'])->name('courses.assignment.file.remove');

    Route::post('/courses/assignment_log/{log_id}/submit', [StudentController::class, 'assignmentSubmit'])->where('section_id','[0-9]+')->name('courses.assignment.submit');

    Route::get('/courses/test/explanation/{section_id}', [StudentController::class, 'testExplanation'])->where('section_id','[0-9]+')->name('courses.test.explanation');



    Route::get('/courses/{course_id}/evaluation/{evaluation_id}', [EvaluationController::class, 'show'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('courses.evaluations.show');
    Route::post('/courses/{course_id}/evaluation/{evaluation_id}', [EvaluationController::class, 'post'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('courses.evaluations.post');


    Route::get('/courses/{course_id}/complete', [StudentController::class, 'complete'])->where(['course_id'=>'[0-9]+'])->name('courses.complete');


    Route::get('/courses', [StudentController::class, 'course_index'])->name('courses.index');

    Route::get('/dashboard', [StudentController::class, 'dashboard'])->name('student.dashboard');
    Route::get('/dashboard2', [StudentController::class, 'dashboard2'])->name('student.dashboard2');
    Route::get('/profile', [StudentController::class, 'profile_index'])->name('student.profile');
    Route::put('/profile', [StudentController::class, 'profile_update'])->name('student.profile.update');
    Route::put('/membership/{course_id}', [StudentController::class, 'membership_update'])->where(['course_id'=>'[0-9]+'])->name('student.membership.update');
    Route::get('/password', [StudentController::class, 'password_index'])->name('student.password');
    Route::put('/password', [StudentController::class, 'password_update'])->name('student.password.update');
    Route::get('/checkout/courses/{course_id}', [StudentController::class, 'checkout'])->where(['course_id'=>'[0-9]+'])->name('student.checkout');
    Route::post('/checkout/courses/{course_id}', [StudentController::class, 'purchase'])->where(['course_id'=>'[0-9]+'])->name('students.purchase');

    Route::get('/pay/order/{order_id}', [StudentController::class, 'pay'])->where(['order_id'=>'[0-9]+'])->name('students.pay');

    Route::get('/orders/{order_id}', [StudentController::class, 'order'])->where(['order_id'=>'[0-9]+'])->name('students.order');

    Route::get('/orders/{order_id}/cancel', [StudentController::class, 'cancel_order'])->where(['order_id'=>'[0-9]+'])->name('students.order.cancel');



    Route::get('/checkCoursePermission2/{course_id}', [StudentController::class, 'checkCoursePermission2'])->where(['course_id'=>'[0-9]+'])->name('checkCoursePermission2');

    Route::get('/certificate/{enrollment_id}', [EnrollmentController::class, 'certificate'])->where('enrollment_id', '[0-9]+')->name('certificate');



    Route::get('/courses/{course_slug}/discussion/private', [CommunicationController::class, 'private_communication_student'])->name('courses.discussion.private.student');

    Route::get('/courses/discussion/private/enrollments/{enrollment_id}', [CommunicationController::class, 'private_communication_by_enrollment'])->where('enrollment_id', '[0-9]+')->name('courses.discussion.private');

    Route::post('/courses/discussion/private/enrollments/{enrollment_id}', [CommunicationController::class, 'private_communication_store'])->where('enrollment_id', '[0-9]+')->name('courses.discussion.private.post');


    Route::get('/courses/discussion/private/{discussion_id}', [CommunicationController::class, 'private_communication_replies'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.private.replies');
    Route::post('/courses/discussion/private/{discussion_id}', [CommunicationController::class, 'private_communication_replie_store'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.private.reply.post');
    Route::get('/delete/discussion/private/reply/{reply_id}', [CommunicationController::class, 'private_communication_replie_destroy'])->where(['reply_id'=>'[0-9]+'])->name('courses.discussion.private.reply.delete');
    Route::get('/reply/{reply_id}', [CommunicationController::class, 'getReply'])->where(['reply_id'=>'[0-9]+'])->name('courses.discussion.reply');


    Route::get('/delete/discussion/private/{discussion_id}', [CommunicationController::class, 'private_communication_destroy'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.private.delete');

    Route::get('/courses/discussion/enrollments/{enrollment_id}', [CommunicationController::class, 'communication_by_enrollment'])->where('enrollment_id', '[0-9]+')->name('courses.discussion.students.posts');

    Route::get('/courses/{course_slug}/discussion/public/{discussion_id}', [DiscussionController::class, 'discussionComments'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.public.comments');
    Route::post('/courses/{course_slug}/discussion/public/{discussion_id}', [DiscussionController::class, 'commentStore'])->where(['discussion_id'=>'[0-9]+'])->name('courses.discussion.public.comment.post');
    Route::get('/delete/discussion/public/comment/{comment_id}', [DiscussionController::class, 'commentDestroy'])->where(['comment_id'=>'[0-9]+'])->name('courses.discussion.public.comment.delete');


    Route::get('/messages', [MessageController::class, 'student_index'])->name('student.messages');
    Route::get('/messages/{message_id}', [MessageController::class, 'student_edit'])->name('student.messages.edit');
    Route::get('/messages/{message_id}/delete', [MessageController::class, 'student_destroy'])->name('student.messages.delete');

});




Route::prefix('portal')->group(function () {


    Route::get('/', [DashboardController::class, 'index'])->name('admin.home');

    Route::get('/sys', [DashboardController::class, 'sys'])->name('admin.sys');

    Route::get('/login', function () {
        if(Auth::check()){
            return redirect()->route('admin.dashboard');
        }
        return view('backend.login');
    })->name('admin.login');

    // Route::get('/dashboard', function () {
    //     return view('backend.dashboard.index');
    // })->middleware('auth.admin')->name('admin.dashboard');




    Route::group(['middleware' => 'auth.super'], function () {

        Route::get('/migrate', [DashboardController::class, 'migrate'])->name('admin.migrate');
        Route::get('/broadcast', [StudentController::class, 'broadcast'])->name('admin.broadcast');

        Route::get('/emailtest', [StudentController::class, 'emailtest'])->name('admin.emailtest');


        Route::get('/users', [AccountController::class, 'index'])->name('admin.users.index');
        Route::get('/users/create', [AccountController::class, 'create'])->name('admin.users.create');
        Route::post('/users', [AccountController::class, 'store'])->name('admin.users.store');
        Route::get('/users/edit/{uid}', [AccountController::class, 'edit'])->where('uid', '[0-9]+')->name('admin.users.edit');
        Route::put('/users/{uid}', [AccountController::class, 'update'])->where('uid', '[0-9]+')->name('admin.users.update');
        Route::delete('/users/{uid}', [AccountController::class, 'destroy'])->where('uid', '[0-9]+')->name('admin.users.delete');
        Route::delete('/users', [AccountController::class, 'destroyMany'])->name('admin.users.delete.many');

        Route::post('/users/{uid}/confirmation', [AccountController::class, 'resendConfirmationCode'])->where('uid', '[0-9]+')->name('admin.users.confirmation.send');


        Route::get('/requests', [EnrollmentController::class, 'requests'])->name('admin.students.requests');
        Route::get('/requests/edit/{enrollment_id}', [EnrollmentController::class, 'request_edit'])->where('enrollment_id', '[0-9]+')->name('admin.students.requests.edit');
        Route::put('/requests/{enrollment_id}', [EnrollmentController::class, 'request_approval'])->where('enrollment_id', '[0-9]+')->name('admin.students.requests.approval');
        Route::delete('/requests', [EnrollmentController::class, 'destroyManyRequests'])->name('admin.requests.delete.many');

        Route::get('/students', [StudentController::class, 'index'])->name('admin.students.index');
        Route::get('/students/create', [StudentController::class, 'create'])->name('admin.students.create');
        Route::get('/students/import', [StudentController::class, 'import'])->name('admin.students.import');
        Route::post('/students/import', [StudentController::class, 'import_post'])->name('admin.students.import.post');
        Route::post('/students/import/database', [StudentController::class, 'import_students'])->name('admin.students.import.database');
        Route::get('/students/sysimport', [StudentController::class, 'sys_data_import'])->name('admin.students.sys_data_import');
        Route::post('/students/sysimport', [StudentController::class, 'sys_data_import_post'])->name('admin.students.sys_data_import.post');
        Route::post('/students/sysimport/database', [StudentController::class, 'sys_data_import_students'])->name('admin.students.sys_data_import.database');
        Route::get('/students/edit/{sid}', [StudentController::class, 'edit'])->where('sid', '[0-9]+')->name('admin.students.edit');
        Route::put('/students/{sid}', [StudentController::class, 'update'])->where('sid', '[0-9]+')->name('admin.students.update');
        Route::delete('/students', [StudentController::class, 'destroyMany'])->name('admin.students.delete.many');
        Route::post('/students/{sid}/confirmation', [StudentController::class, 'resendConfirmationCode'])->where('sid', '[0-9]+')->name('admin.students.confirmation.send');
        Route::get('/students/{sid}/enrollment', [StudentController::class, 'showEnrollment'])->where('sid', '[0-9]+')->name('admin.students.enrollment');


        Route::get('/students/export/{course_id?}', [StudentController::class, 'export_students'])->where('course_id', '[0-9]+')->name('admin.students.export');

        Route::post('/students/search', [StudentController::class, 'search_students'])->name('admin.students.search');


        Route::get('/courses/{course_id}/enrollments', [CourseController::class, 'students'])->where('course_id', '[0-9]+')->name('admin.courses.students');
        Route::get('/courses/{course_id}/enrollments/edit/{enrollment_id}', [CourseController::class, 'students_edit'])->where(['course_id'=>'[0-9]+','enrollment_id'=>'[0-9]+'])->name('admin.courses.students.edit');


        Route::put('/enrollments/{enrollment_id}/certificate', [EnrollmentController::class, 'generate_certificate'])->where('enrollment_id', '[0-9]+')->name('admin.students.certificate.generate');




        Route::post('/courses/{course_id}/evaluation', [EvaluationController::class, 'store'])->where('course_id', '[0-9]+')->name('admin.evaluations.store');
        Route::get('/courses/{course_id}/evaluation/edit/{evaluation_id}', [EvaluationController::class, 'edit'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('admin.evaluations.edit');
        Route::put('/courses/{course_id}/evaluation/{evaluation_id}', [EvaluationController::class, 'update'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('admin.evaluations.update');
        Route::delete('/courses/{course_id}/evaluation/{evaluation_id}', [EvaluationController::class, 'destroy'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('admin.evaluations.delete');


        Route::post('/courses/{course_id}/evaluation/{evaluation_id}/questions', [EvaluationController::class, 'storeQuestion'])->where(['course_id'=>'[0-9]+','evaluation_id'=>'[0-9]+'])->name('admin.questions.store');
        Route::put('/courses/evaluation/questions/{question_id}', [EvaluationController::class, 'updateQuestionOptions'])->where('question_id', '[0-9]+')->name('admin.questions.update');
        Route::post('/courses/evaluation/{evaluation_id}/questions/order', [EvaluationController::class, 'updateQuestionPositions'])->where(['evaluation_id'=>'[0-9]+'])->name('admin.questions.order.update');
        Route::delete('/courses/evaluation/questions/{question_id}', [EvaluationController::class, 'destroyQuestion'])->where(['question_id'=>'[0-9]+'])->name('admin.questions.delete');


        Route::get('/evaluation/responses', [EvaluationController::class, 'responses'])->name('admin.evaluations.responses');
        Route::get('/evaluation/responses/edit/{response_id}', [EvaluationController::class, 'responses_edit'])->where(['response_id'=>'[0-9]+'])->name('admin.evaluations.responses.edit');
        Route::delete('/evaluation/responses', [EvaluationController::class, 'destroyManyResponses'])->name('admin.evaluations.responses.delete.many');


        Route::get('/courses', [CourseController::class, 'index'])->name('admin.courses.index');
        Route::get('/courses/create', [CourseController::class, 'create'])->name('admin.courses.create');
        Route::post('/courses', [CourseController::class, 'store'])->name('admin.courses.store');
        Route::get('/courses/edit/{course_id}', [CourseController::class, 'edit'])->where('course_id', '[0-9]+')->name('admin.courses.edit');
        Route::put('/courses/{course_id}', [CourseController::class, 'update'])->where('course_id', '[0-9]+')->name('admin.courses.update');
        Route::delete('/courses/{course_id}', [CourseController::class, 'destroy'])->where('course_id', '[0-9]+')->name('admin.courses.delete');
        Route::delete('/courses', [CourseController::class, 'destroyMany'])->name('admin.courses.delete.many');





        Route::post('/courses/{course_id}/modules', [ModuleController::class, 'store'])->where('course_id', '[0-9]+')->name('admin.modules.store');
        Route::get('/courses/{course_id}/modules/edit/{module_id}', [ModuleController::class, 'edit'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.edit');
        Route::put('/courses/{course_id}/modules/{module_id}', [ModuleController::class, 'update'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.update');
        Route::post('/courses/{course_id}/modules/order', [ModuleController::class, 'updatePositions'])->where('course_id', '[0-9]+')->name('admin.modules.order.update');
        Route::delete('/courses/{course_id}/modules/{module_id}', [ModuleController::class, 'destroy'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.delete');





        Route::post('/courses/{course_id}/modules/{module_id}/sections', [SectionController::class, 'store'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.sections.store');
        Route::get('/courses/{course_id}/modules/{module_id}/sections/edit/{section_id}', [SectionController::class, 'edit'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.edit');
        Route::put('/courses/{course_id}/modules/{module_id}/sections/{section_id}', [SectionController::class, 'update'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.update');
        Route::post('/courses/{course_id}/modules/{module_id}/sections/order', [SectionController::class, 'updatePositions'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.sections.order.update');
        Route::delete('/courses/{course_id}/modules/{module_id}/sections/{section_id}', [SectionController::class, 'destroy'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.delete');
        Route::get('/courses/modules/sections/pages', [SectionController::class, 'getPageTemplate'])->name('admin.sections.page.template');

        Route::get('/courses/{course_id}/modules/{module_id}/sections/{section_id}/image', [SectionController::class, 'listImageFolderContent'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.image.file');
        Route::get('/courses/{course_id}/modules/{module_id}/sections/{section_id}/pdf', [SectionController::class, 'listPDFFolderContent'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.pdf.file');


        Route::post('/courses/{course_id}/modules/{module_id}/sections/{section_id}/upload/image', [SectionController::class, 'uploadImage'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.image.upload');
        Route::post('/courses/{course_id}/modules/{module_id}/sections/{section_id}/upload/pdf', [SectionController::class, 'uploadPDF'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.pdf.upload');

        Route::delete('/courses/{course_id}/modules/{module_id}/sections/{section_id}/remove/image', [SectionController::class, 'removeImage'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.image.remove');
        Route::delete('/courses/{course_id}/modules/{module_id}/sections/{section_id}/remove/pdf', [SectionController::class, 'removePDF'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.pdf.remove');


        Route::post('/courses/{course_id}/modules/{module_id}/sections/{section_id}/tests', [TestController::class, 'store'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.tests.store');
        Route::put('/courses/modules/sections/tests/{test_id}', [TestController::class, 'updateOptions'])->where('test_id', '[0-9]+')->name('admin.tests.update');
        Route::post('/courses/modules/sections/{section_id}/tests/order', [TestController::class, 'updatePositions'])->where(['section_id'=>'[0-9]+'])->name('admin.tests.order.update');
        Route::delete('/courses/modules/sections/tests/{test_id}', [TestController::class, 'destroy'])->where(['test_id'=>'[0-9]+'])->name('admin.tests.delete');


        Route::delete('/courses/assignment/score/{log_id}/reset', [AssignmentController::class, 'resetAssignment'])->where(['log_id'=>'[0-9]+'])->name('admin.courses.assignment.score.reset');

        Route::delete('/courses/quiz/score/{log_id}/reset', [TestController::class, 'resetTest'])->where(['log_id'=>'[0-9]+'])->name('admin.courses.quiz.score.reset');


        Route::post('/upload/course/cover/{course_id}', [CourseController::class, 'uploadCover'])->where('course_id', '[0-9]+')->name('admin.courses.cover.upload');
        Route::delete('/remove/course/cover/{course_id}', [CourseController::class, 'removeCover'])->where('course_id', '[0-9]+')->name('admin.courses.cover.remove');
        Route::get('/course/cover/{course_id}', [CourseController::class, 'showCover'])->where('course_id', '[0-9]+')->name('admin.courses.cover.show');


        Route::post('/upload/courses/{course_id}/modules/{module_id}/thumbnail', [ModuleController::class, 'uploadThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.thumbnail.upload');
        Route::delete('/upload/courses/{course_id}/modules/{module_id}/thumbnail', [ModuleController::class, 'removeThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.thumbnail.remove');
        Route::get('/courses/{course_id}/modules/{module_id}/thumbnail', [ModuleController::class, 'showThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+'])->name('admin.modules.thumbnail.show');

        Route::post('/upload/courses/{course_id}/modules/{module_id}/sections/{section_id}/thumbnail', [SectionController::class, 'uploadThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.thumbnail.upload');
        Route::delete('/upload/courses/{course_id}/modules/{module_id}/sections/{section_id}/thumbnail', [SectionController::class, 'removeThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.thumbnail.remove');
        Route::get('/courses/{course_id}/modules/{module_id}/sections/{section_id}/thumbnail', [SectionController::class, 'showThumbnail'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.sections.thumbnail.show');


        Route::get('/login/reset', [AccountController::class, 'reset'])->name('admin.login.reset');
        Route::post('/login/reset', [AccountController::class, 'resetPost'])->name('admin.login.reset.post');
        Route::get('/login/reset/{uid}/{reset_token}', [AccountController::class, 'resetPassword'])->where('uid', '[0-9]+')->name('admin.login.reset.password');
        Route::post('/login/reset/{uid}/{reset_token}', [AccountController::class, 'resetPasswordPost'])->where('uid', '[0-9]+')->name('admin.login.reset.password.post');


    });

    Route::group(['middleware' => 'auth.admin'], function () {


        Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('admin.dashboard');

        Route::get('/profile', [AccountController::class, 'profile'])->name('admin.profile');
        Route::put('/profile', [AccountController::class, 'profileUpdate'])->name('admin.profile.update');

        Route::post('/courses/{course_id}/modules/{module_id}/sections/{section_id}/assignments', [AssignmentController::class, 'store'])->where(['course_id'=>'[0-9]+','module_id'=>'[0-9]+','section_id'=>'[0-9]+'])->name('admin.assignments.store');
        Route::put('/courses/modules/sections/assignments/{assignment_id}', [AssignmentController::class, 'update'])->where('assignment_id', '[0-9]+')->name('admin.assignments.update');
        Route::delete('/courses/modules/sections/assignments/{assignment_id}', [AssignmentController::class, 'destroy'])->where(['assignment_id'=>'[0-9]+'])->name('admin.assignments.delete');


        Route::get('/marking/assignments', [AssignmentController::class, 'assignments'])->name('admin.marking.assignments');
        Route::get('/marking/students', [AssignmentController::class, 'students'])->name('admin.marking.students');
        Route::get('/marking/courses', [AssignmentController::class, 'markingCourses'])->name('admin.marking.courses');
        Route::get('/marking/courses/{course_id}', [AssignmentController::class, 'assignmentsByCourse'])->where(['course_id'=>'[0-9]+'])->name('admin.marking.courses.assignments');
        Route::get('/marking/students/{student_id}', [AssignmentController::class, 'assignmentsByStudent'])->where(['student_id'=>'[0-9]+'])->name('admin.marking.courses.students');
        Route::get('/marking/courses/grading/{log_id}', [AssignmentController::class, 'gradingPage'])->where(['log_id'=>'[0-9]+'])->name('admin.marking.courses.grading.page');

        Route::get('/marking/courses/grading/{log_id}/{assignment_id}/files', [AssignmentController::class, 'listAssignmentFolderContent'])->where(['log_id'=>'[0-9]+','assignment_id'=>'[0-9]+'])->name('admin.courses.assignment.files');


        Route::put('/marking/courses/grading/{log_id}/start', [AssignmentController::class, 'startGrading'])->where(['log_id'=>'[0-9]+'])->name('admin.marking.courses.grading.start');
        Route::put('/marking/courses/grading/{log_id}/reset', [AssignmentController::class, 'resetGrading'])->where(['log_id'=>'[0-9]+'])->name('admin.marking.courses.grading.reset');
        Route::put('/marking/courses/grading/{log_id}/submit', [AssignmentController::class, 'submitGrading'])->where(['log_id'=>'[0-9]+'])->name('admin.marking.courses.grading.submit');



        Route::get('/messages', [MessageController::class, 'index'])->name('admin.messages');
        Route::get('/messages/{message_id}', [MessageController::class, 'edit'])->name('admin.messages.edit');
        Route::get('/messages/{message_id}/delete', [MessageController::class, 'destroy'])->name('admin.messages.delete');

        Route::get('/communication/courses', [CommunicationController::class, 'discussionCourses'])->name('admin.communication.courses');

        Route::get('/communication/courses/{course_id}/students', [CommunicationController::class, 'students'])->where('course_id', '[0-9]+')->name('admin.communication.students');
        Route::get('/communication/courses/{course_id}/privates', [CommunicationController::class, 'privates'])->where('course_id', '[0-9]+')->name('admin.communication.privates');


        Route::get('/logout', [AccountController::class, 'adminLogout'])->name('admin.logout');




        Route::post('/upload/avatar/{uid}', [AccountController::class, 'uploadAvatar'])->where('uid', '[0-9]+')->name('admin.avatar.upload');
        Route::delete('/remove/avatar/{uid}', [AccountController::class, 'removeAvatar'])->where('uid', '[0-9]+')->name('admin.avatar.remove');
        Route::get('/avatar/{uid}', [AccountController::class, 'showAvatar'])->where('uid', '[0-9]+')->name('admin.avatar.show');
    });

    Route::post('/login', [AccountController::class, 'adminLogin'])->name('admin.login.post');




});


Route::get('/account/verify/{confirmation_code}', [AccountController::class,'confirm'])->name('account.verify');

Route::get('/avatar/{uid}', [AccountController::class, 'showAvatar'])->where('uid', '[0-9]+')->name('user.avatar.show');

Route::get('/file/section/{section_id}/{type}/{file}', [SectionController::class, 'displaySectionFile'])->where('section_id', '[0-9]+')->name('sections.file.path');

Route::get('/payment/{order_id}', [PayPalPaymentController::class, 'handlePayment'])->where(['order_id'=>'[0-9]+'])->name('payment.make');


Route::get('cancel-payment', [PayPalPaymentController::class, 'paymentCancel'])->name('payment.cancel');
Route::get('payment-success', [PayPalPaymentController::class, 'paymentSuccess'])->name('payment.success');
