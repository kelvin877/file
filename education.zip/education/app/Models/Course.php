<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'course_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'course_name',
        'course_slug',
        'course_price',
        'course_ceu_fee',
        'course_member_discount',
        'course_description',
        'course_instructor_id',
        'course_category',
        'course_duration',
        'course_status',
        'course_marking_criteria',
        'course_marking_quiz_threshold',
        'course_marking_assignment_threshold',
        'course_marking_combined_threshold',
        'course_marking_method'
    ];

    public function modules()
    {
        return $this->hasMany(Module::class, 'module_course_id', 'course_id');
    }

    public function enrollments(){

        return $this->hasMany(Enrollment::class, 'enrollment_course_id', 'course_id');
    }


    public function evaluation(){

        return $this->hasOne(Evaluation::class, 'evaluation_course_id', 'course_id');
    }


    public function discussions(){

        return $this->hasMany(Discussion::class, 'discussion_course_id', 'course_id');
    }

    public function private_discussions(){

        return $this->hasMany(PrivateDiscussion::class, 'discussion_course_id', 'course_id');
    }

    public function instructor(){


        return $this->belongsTo(User::class,'course_instructor_id','id');

        
    }
    
    public function course_name_on_certificate(){
        
        $pos = strrpos($this->course_name, ' -');
        if ($pos === false){
            return $this->course_name;
        }else{
            
            $name = substr($this->course_name, 0, $pos);
            //$name = $name ."\n". substr($this->course_name, $pos+2);
        }
        
        return $name;
    }
    
     public function certificate_template(){
        
        $pos = strrpos($this->course_name, ' -');
        if ($pos === false){
            return $this->course_slug;
        }else{            
            $name = substr($this->course_slug, 0, $pos);
            
        }
        
        return $name;
    }



    
}
