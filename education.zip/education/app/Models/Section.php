<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Casts\Json;

class Section extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'section_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'section_name',
        'section_prefix',
        'section_description',
        'section_explanation',
        'section_module_id',
        'section_position',
        'section_type',
        'section_content',
        'section_status'
    ];


    protected $casts = [
        'section_content'  => Json::class,
    ];

    public function module()
    {
        return $this->belongsTo(Module::class, 'section_module_id', 'module_id');
    }

    public function tests()
    {
        return $this->hasMany(Test::class, 'test_section_id', 'section_id');
    }


    public function assignments()
    {
        return $this->hasMany(Assignment::class, 'assignment_section_id', 'section_id');
    }

    public function logViews(){
        return $this->hasMany(LogView::class, 'log_section_id', 'section_id');
    }

    public function logQuizzes(){
        return $this->hasMany(LogQuiz::class, 'log_test_section_id', 'section_id');
    }

    public function logAssignments(){
        return $this->hasMany(LogAssignment::class, 'log_assignment_section_id', 'section_id');
    }



    
}
