<?php

namespace App\Models;

use App\Casts\Json;
use Illuminate\Database\Eloquent\Model;

class LogQuiz extends Model
{

    protected $table = 'logs_quiz';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'log_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'log_test_section_id',
        'log_student_id',
        'quiz_score',
        'quiz_questions',
        'quiz_options',
        'quiz_answers',
        'quiz_selections',
        'status',
    ];


    protected $casts = [
        'quiz_questions'      => Json::class,
        'quiz_options'        => Json::class,
        'quiz_answers'        => Json::class,
        'quiz_selections'     => Json::class,

    ];

    public function section(){
        return $this->belongsTo(Section::class, 'log_test_section_id', 'section_id');
    }

    public function student(){
        return $this->belongsTo(Student::class, 'log_student_id', 'student_id');
    }

    public function score(){
        return $this->quiz_score;
    }





}
