<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Casts\Json;

class Assignment extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'assignment_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'assignment_section_id',
        'assignment_question',
        'assignment_notes',
        'assignment_type',
        'assignment_position',
        'assignment_status'
    ];


    protected $casts = [
        'assignment_notes'  => Json::class,
    ];

    public function section()
    {
        return $this->belongsTo(Section::class, 'assignment_section_id', 'section_id');
    }



    
}
