<?php

namespace App\Models;

use App\Casts\Json;
use Illuminate\Database\Eloquent\Model;

class PrivateDiscussion extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'discussion_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'discussion_title',
        'discussion_course_id',
        'discussion_student_id',
        'discussion_user_id',
        'discussion_tags',
        'discussion_reference_id',
        'discussion_enrollment_id'
    ];

    protected $casts = [
        'discussion_tags' => Json::class,
    ];


    public function course(){
        return $this->belongsTo(Course::class,'discussion_course_id','course_id');
    }

    public function student(){
        return $this->belongsTo(Student::class,'discussion_student_id','student_id');
    }

    public function user(){
        return $this->belongsTo(User::class,'discussion_user_id','id');
    }


    public function replies(){

        return $this->hasMany(Reply::class, 'reply_discussion_id', 'discussion_id');
    }


    public function account(){

        if($this->discussion_user_id!=null){
            return $this->belongsTo(User::class,'discussion_user_id','id');
        }
        elseif($this->discussion_student_id!=null){
            return $this->belongsTo(Student::class,'discussion_student_id','student_id');
        }
        

        return null;

    }




    
}
