<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'module_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'module_name',
        'module_prefix',
        'module_description',
        'module_course_id',
        'module_position',
        'module_status'
    ];

    public function course()
    {
        return $this->belongsTo(Course::class, 'module_course_id', 'course_id');
    }

    public function sections()
    {
        return $this->hasMany(Section::class, 'section_module_id', 'module_id');
    }



    
}
