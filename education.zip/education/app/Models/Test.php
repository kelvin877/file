<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Casts\Json;

class Test extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'test_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'test_question',
        'test_options',
        'test_answer',
        'test_section_id',
        'test_position',
        'test_type',
        'test_status'
    ];


    protected $casts = [
        'test_options'  => Json::class,
    ];

    public function section()
    {
        return $this->belongsTo(Section::class, 'test_section_id', 'section_id');
    }



    
}
