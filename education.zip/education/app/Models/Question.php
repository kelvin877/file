<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Carbon\Carbon;
    use App\Casts\Json;

	class Question extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'question_id';

		protected $table = 'questions';

		protected $fillable = array('question_evaluation_id','question_name','question_options','question_type','question_position');

        protected $casts = [
            'question_options'  => Json::class,
        ];


        public function evaluation(){
			return $this->belongsTo(Evaluation::class, 'question_evaluation_id', 'evaluation_id');
		}


		
	

	}

