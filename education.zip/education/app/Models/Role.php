<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;

	class Role extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'role_id';

		protected $table = 'role';

		protected $fillable = array('role_id','role_name');
	
		public function users(){
			return $this->hasMany('App\User','user_role_id','role_id');
		}
	}

