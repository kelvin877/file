<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Carbon\Carbon;

	class Enrollment extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'enrollment_id';

		protected $table = 'enrollment';

		protected $fillable = array('enrollment_student_id','enrollment_course_id','enrollment_order_id','enrollment_course_duration','enrollment_start_date','enrollment_expiry_date','enrollment_pause_date','enrollment_quiz_progress','enrollment_quiz_score','enrollment_assignment_progress','enrollment_assignment_score','enrollment_progress','enrollment_score','enrollment_graduation_date','enrollment_graduation_score','enrollment_last_reminder','enrollment_status','enrollment_certificate','enrollment_ceu');

		public function order(){
			return $this->belongsTo(Order::class, 'enrollment_order_id', 'order_id');
		}

		public function course(){
			return $this->belongsTo(Course::class, 'enrollment_course_id', 'course_id');
		}

		public function student(){
			return $this->belongsTo(Student::class, 'enrollment_student_id', 'student_id');
		}


		public function response(){

			return $this->hasOne(Response::class, 'response_enrollment_id', 'enrollment_id');
		}
	

	}

