<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;

	class Order extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'order_id';

		protected $table = 'order';

		protected $fillable = array('order_amount','order_tax','order_subtotal','order_status','order_payment_method','order_paypal_token','order_paypal_paid_date','order_paypal_notes');

		public function enrollment()
		{
			return $this->hasOne(Enrollment::class, 'enrollment_order_id', 'order_id');
		}
	

	}

