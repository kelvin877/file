<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'message_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'message_from_type',
        'message_from_id',
        'message_to_type',
        'message_to_id',
        'message_content',
        'message_reference_id',
        'message_tags',
        'message_read'
    ];

    public function sender(){

        if($this->message_from_type=='STUDENT'){
            return $this->belongsTo(Student::class,'message_from_id','student_id');
        }
        elseif($this->message_from_type=='USER'){
            return $this->belongsTo(User::class,'message_from_id','id');
        }

        return null;
    }

    public function receiver(){

        if($this->message_to_type=='STUDENT'){
            return $this->belongsTo(Student::class,'message_to_id','student_id');
        }
        elseif($this->message_to_type=='USER'){
            return $this->belongsTo(User::class,'message_to_id','id');
        }

        return null;
    }





    
}
