<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'comment_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'comment_content',
        'comment_discussion_id',
        'comment_student_id',
        'comment_user_id'
    ];

    public function discussion(){
        return $this->belongsTo(Discussion::class,'comment_discussion_id','discussion_id');
    }

    public function student(){
        return $this->belongsTo(Student::class,'comment_student_id','student_id');
    }

    public function user(){
        return $this->belongsTo(User::class,'comment_user_id','id');
    }


    public function account(){

        if($this->comment_student_id!=null){
            return $this->belongsTo(Student::class,'comment_student_id','student_id');
        }
        elseif($this->comment_discussion_id!=null){
            return $this->belongsTo(User::class,'comment_user_id','id');
        }

        return null;

    }




    
}
