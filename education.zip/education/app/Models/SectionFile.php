<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SectionFile extends Model
{

    public $file_location;
    public $file_name;
    public $file_download_link;
    public $file_type;
    public $file_link;

    public function getName(){
    
        return basename($this->file_name, ".".$this->file_type);
    }

    public function getFullName(){
    
        return $this->file_name;
    }

    public function getFileLink(){

        return $this->file_link;
    }

    public function getDownloadLink(){

        return $this->file_download_link;
    }



    
}
