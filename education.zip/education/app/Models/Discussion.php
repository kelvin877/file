<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Discussion extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'discussion_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'discussion_title',
        'discussion_course_id',
        'discussion_student_id',
        'discussion_user_id'
    ];


    public function course(){
        return $this->belongsTo(Course::class,'discussion_course_id','course_id');
    }

    public function student(){
        return $this->belongsTo(Student::class,'discussion_student_id','student_id');
    }

    public function user(){
        return $this->belongsTo(User::class,'discussion_user_id','id');
    }


    public function comments(){

        return $this->hasMany(Comment::class, 'comment_discussion_id', 'discussion_id');
    }

    public function account(){

        if($this->discussion_student_id!=null){
            return $this->belongsTo(Student::class,'discussion_student_id','student_id');
        }
        elseif($this->discussion_user_id!=null){
            return $this->belongsTo(User::class,'discussion_user_id','id');
        }

        return null;

    }




    
}
