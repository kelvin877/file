<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Carbon\Carbon;

	class Evaluation extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'evaluation_id';

		protected $table = 'evaluations';

		protected $fillable = array('evaluation_course_id','evaluation_name','evaluation_description','evaluation_status');


        public function course(){
			return $this->belongsTo(Course::class, 'evaluation_course_id', 'course_id');
		}


        public function questions(){

            return $this->hasMany(Question::class, 'question_evaluation_id', 'evaluation_id');
        }


		public function responses(){

            return $this->hasMany(Response::class, 'response_evaluation_id', 'evaluation_id');
        }

		
	

	}

