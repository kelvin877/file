<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Illuminate\Foundation\Auth\User as Authenticatable;
	use Illuminate\Support\Facades\Storage;

	class Student extends Authenticatable
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'student_id';

		protected $table = 'students';

		protected $fillable = array('student_first_name','student_last_name','student_email','student_password','is_member','student_member_number','student_title','student_organization','student_address','student_city','student_state','student_country','student_zip','student_phone','student_cellphone','student_notes','student_confirmation_code','student_status','student_reset_token','student_reset_token_expiry_date');
	
	
		public function isAdmin()
		{
			return false;
		}
		
		public function isUser()
		{
			 return false;
		}

		public function getEmail()
		{
			return $this->student_email;
		}
	
	
		public function isInstructor()
		{
			 return false;
		}
	
	
		public function isBackendUser()
		{
			 return false;
		}

		public function isStudent()
		{
			 return true;
		}



		public function getAuthPassword(){
			return $this->student_password;
		}

		public function getFullName(){
			return $this->student_first_name.' '.$this->student_last_name;
		}


		public function getRoleName(){
			return 'Student';
		}

		public function enrollments(){
			return $this->hasMany(Enrollment::class, 'enrollment_student_id', 'student_id');
		}


		public function discussions(){
			return $this->hasMany(Discussion::class, 'discussion_student_id', 'student_id');
		}


		public function comments(){
			return $this->hasMany(Comment::class, 'comment_student_id', 'student_id');
		}


		public function logViews(){
			return $this->hasMany(LogView::class, 'log_student_id', 'student_id');
		}

		public function logQuizzes(){
			return $this->hasMany(LogQuiz::class, 'log_student_id', 'student_id');
		}

		public function logAssignments(){
			return $this->hasMany(LogAssignment::class, 'log_student_id', 'student_id');
		}

		public function avatarUrl(){

			if (Storage::exists('student_avatar/'.$this->student_id.'.jpg')){
				return route('student.avatar.show', ['student_id' => $this->student_id]).'?'.time();
			}
			else{
				return asset('images/avatar.png');
			}
			
		}




	}

