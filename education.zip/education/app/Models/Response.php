<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Carbon\Carbon;
    use App\Casts\Json;

	class Response extends Model
	{
		/**
		 * The table associated with the model.
		 *
		 * @var string
		 */
		protected $primaryKey = 'response_id';

		protected $table = 'responses';

		protected $fillable = array('response_evaluation_id','response_enrollment_id','response_read','response_content');

        protected $casts = [
            'response_content'  => Json::class,
        ];


        public function evaluation(){
			return $this->belongsTo(Evaluation::class, 'response_evaluation_id', 'evaluation_id');
		}


        public function enrollment(){
			return $this->belongsTo(Enrollment::class, 'response_enrollment_id', 'enrollment_id');
		}

		
	

	}

