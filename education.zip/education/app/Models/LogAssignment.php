<?php

namespace App\Models;

use App\Casts\Json;
use Illuminate\Database\Eloquent\Model;

class LogAssignment extends Model
{

    protected $table = 'logs_assignment';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'log_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'log_assignment_section_id',
        'log_student_id',
        'assignment_score',
        'assignment_questions',
        'assignment_answers',
        'assignment_comments',
        'assignment_marking_comments',
        'assignment_marking_user_id',
        'assignment_status',
        'assignment_updated_date',
        'assignment_marking_date'
    ];


    protected $casts = [
        'assignment_questions'      => Json::class,
        'assignment_answers'        => Json::class,
    ];

    public function section(){
        return $this->belongsTo(Section::class, 'log_assignment_section_id', 'section_id');
    }

    public function getCourse(){

        $section = $this->section;
        
        return $section->module->course;
    }

    public function student(){
        return $this->belongsTo(Student::class, 'log_student_id', 'student_id');
    }

    public function score(){
        return $this->assignment_score;
    }




    
}
