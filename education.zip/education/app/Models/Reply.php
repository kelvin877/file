<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reply extends Model
{

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'reply_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'reply_content',
        'reply_discussion_id',
        'reply_student_id',
        'reply_user_id',
        'reply_tags',
        'reply_reference_id'
    ];

    public function discussion(){
        return $this->belongsTo(PrivateDiscussion::class,'reply_discussion_id','discussion_id');
    }

    public function student(){
        return $this->belongsTo(Student::class,'reply_student_id','student_id');
    }

    public function user(){
        return $this->belongsTo(User::class,'reply_user_id','id');
    }


    public function account(){

        if($this->reply_student_id!=null){
            return $this->belongsTo(Student::class,'reply_student_id','student_id');
        }
        elseif($this->reply_discussion_id!=null){
            return $this->belongsTo(User::class,'reply_user_id','id');
        }

        return null;

    }




    
}
