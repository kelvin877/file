<?php

namespace App\Models;

use App\Casts\Json;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Storage;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_role_id',
        'name',
        'first_name',
        'last_name',
        'email',
        'email_verified_at',
        'password',
        'social_media',
        'profile',
        'last_login',
        'active',
        'confirmed',
        'confirmation_code',
        'reset_token',
        'reset_token_expiry_date'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'social_media'      => Json::class,
    ];

    public static $rules = array(
        'user_role_id'              => 'required',
        'name'                      => 'required',
        'first_name'                => 'required',
        'last_name'                 => 'required',
        'email'                     => 'required|email|unique:users,user_email',
        'email_verified_at'         => '',
        'password'                  => 'required|min:8',
        'password_confirm'		    => 'required|same:user_login_password', 
        'profile'                   => '',
        'social_media'              => '',
        'last_login'                => '',
        'active'                    => '',
        'confirmed'                 => '',
        'confirmation_code'         => '',
        'reset_token'               => '',
        'reset_token_expiry_date'   => '',
    );

    public static $profileRules = array(       
        'name'                  => 'required',
        'first_name'            => 'required',
        'last_name'             => 'required',
        'profile'               => '',
        'social_media'          => '',
    );


    public static $labels = array(
        'user_role_id'              => 'User Role',
        'name'                      => 'Name',
        'first_name'                => 'First Name',
        'last_name'                 => 'Last name',
        'email'                     => 'Email',
        'email_verified_at'         => 'Email Verified Date',
        'password'                  => 'Password',
        'password_confirm'		    => 'Pasword Confirm', 
        'profile'                   => 'Profile',
        'social_media'              => 'Social Media',
        'last_login'                => 'Last Login Time',
        'active'                    => 'Active',
        'confirmed'                 => 'Confirmed',
        'confirmation_code'         => 'Confirmation Code',
        'reset_token'               => 'Reset Token',
        'reset_token_expiry_date'   => 'Reset Token Expiry Date',
    );

    public function role(){
        return $this->belongsTo(Role::class,'user_role_id','role_id');
    }

    public function getRole(){

        $role = $this->role;
        
        return $role->role_name;
    }

    public function getRoleName(){

        $role = $this->role;
        
        return $role->role_name;
    }

    public function isSuper()
    {
        return $this->role->role_name == 'Administrator';
    }

    public function isAdmin()
    {
        return $this->role->role_name == 'Administrator';
    }
    
    public function isUser()
    {
         return $this->role->role_name == 'User';
    }


    public function isInstructor()
    {
         return $this->role->role_name == 'Instructor';
    }


    public function isBackendUser()
    {
         return $this->role->role_name == 'Administrator' || $this->role->role_name == 'Instructor';
    }

    public function isStudent()
    {
        return false;
    }

    public function getFullName(){
	  return $this->first_name.' '.$this->last_name;
	}

    public function getEmail()
    {
        return $this->email;
    }

    public function discussions(){

        return $this->hasMany(Discussion::class, 'discussion_user_id', 'id');
    }


    public function comments(){

        return $this->hasMany(Comment::class, 'comment_user_id', 'id');
    }


    public function courses(){

        return $this->hasMany(Course::class, 'course_instructor_id', 'id');
    }

    public function avatarUrl(){

        if (Storage::exists('avatar/'.$this->id.'.jpg')){
            return route('user.avatar.show', ['uid' => $this->id]).'?'.time();
        }
        else{
            return asset('images/avatar.png');
        }
        
    }
}
