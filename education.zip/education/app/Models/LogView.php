<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogView extends Model
{

    protected $table = 'logs_view';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'log_id';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'log_student_id',
        'log_section_id',
        'log_views'
    ];



    public function section(){
        return $this->belongsTo(Section::class, 'log_section_id', 'section_id');
    }

    public function student(){
        return $this->belongsTo(Student::class, 'log_student_id', 'student_id');
    }




    
}
