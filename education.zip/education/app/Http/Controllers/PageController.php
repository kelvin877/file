<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use Carbon\Carbon;

class PageController extends Controller
{
    //
    public function __construct()
    {
        
        
    }

    public function index(){

        return view('frontend.pages.index');
    }

    public function ceu(){

        return view('frontend.pages.ceu');

    }

    public function terms(){

        return view('frontend.pages.terms');

    }

    public function policy(){

        return view('frontend.pages.policy');

    }
}
