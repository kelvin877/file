<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use App\Models\Assignment;
use App\Models\LogAssignment;
use App\Models\Student;
use Carbon\Carbon;
use Helpers;

class AssignmentController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => []]);
        
    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}

    

	public function index(Request $request,$section_id){


	}

	public function create(){


	}

	public function store(Request $request,$course_id,$module_id,$section_id){


		if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
			$request->merge(['assignment_status'=>'PUBLIC']);
		}
		else{
			$request->merge(['assignment_status'=>'PRIVATE']);
		}

		$request->merge(['assignment_section_id'=>$section_id]);


		$max_position = Assignment::where('assignment_section_id', $section_id)->max('assignment_position');

		if($max_position == null){
			$max_position = 0;
		}

		$request->merge(['assignment_position'=>$max_position+1]);


		$validator = Validator::make($request->all(), [
			'assignment_question'			=> 'required',
			'assignment_section_id'			=> 'required',
			'assignment_status'				=> 'required',
			'assignment_notes'				=> '',
			'assignment_type'				=> 'required',
			'assignment_position'			=> 'required',
		]);

		if ($validator->fails()) {

			return response()->json([
				'status' => 'failure',
				'errors' => $validator
				]);
        }
		else{

			$section = Section::find($section_id);

			if($section!=null){


				if($section->assignments()->count()==0){

					$assignment = $section->assignments()->create([
						'assignment_question'		=> $request->input('assignment_question'),
						'assignment_status'			=> $request->input('assignment_status'),
						'assignment_type'			=> $request->input('assignment_type'),
						'assignment_position'		=> $request->input('assignment_position'),
					]);

					
					// $assignment = Assignment::create([
					// 	'assignment_question'		=> $request->input('assignment_question'),
					// 	'assignment_section_id'		=> $request->input('assignment_section_id'),
					// 	'assignment_status'			=> $request->input('assignment_status'),
					// 	'assignment_type'			=> $request->input('assignment_type'),
					// 	'assignment_position'		=> $request->input('assignment_position'),
					// ]);
		
		
					$assignments = Assignment::where('assignment_section_id',$section_id)->orderBy('assignment_position')->get();
					$response = '';
		
					foreach($assignments as $assignment){
						$response .= view('backend.courses.blocks.assignment',['assignment' => $assignment])->render();
					}
				
					
					return response()->json([
						'status' => 'success',
						'response' => $response
						]);



				}

				return response()->json([
					'status' => 'failure',
					'message' => 'Only one quation is allowed in a assignment'
					]);

				
				



			}


			
		}
	}

	public function show($module_id){

	}

	public function edit($course_id,$module_id,$section_id,$assignment_id){
		

	}

	public function update(Request $request,$assignment_id){


		$assignment = Assignment::find($assignment_id);

		if($assignment != null){

			$validator = Validator::make($request->all(), [
				'assignment_question'			=> 'required',
				'assignment_status'				=> '',
				'assignment_notes'				=> '',
				'assignment_type'				=> '',
			]);
	
			if ($validator->fails()) {
				
				return response()->json([
					'status' => 'failure',
					'errors' => $validator
				]);
			}
			else{

				$assignment->update([
					'assignment_question'	=> $request->input('assignment_question'),
				]);
				
			}

			$assignments = Assignment::where('assignment_section_id',$assignment->section->section_id)->orderBy('assignment_position')->get();
			$response = '';

			foreach($assignments as $assignment){
				$response .= view('backend.courses.blocks.assignment',['assignment' => $assignment])->render();
			}
		
			
			return response()->json([
				'status' => 'success',
				'response' => $response
				]);
		}

		
	}

	public function destroy(Request $request,$assignment_id){

		$assignment = Assignment::find($assignment_id);

		if($assignment!=null){

			$section_id = $assignment->assignment_section_id;

			Assignment::destroy($assignment_id);
	
			$assignments = Assignment::where('assignment_section_id',$section_id)->orderBy('assignment_position')->get();
			$response = '';
	
			foreach($assignments as $assignment){
				$response .= view('backend.courses.blocks.assignment',['assignment' => $assignment])->render();
			}
	
			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted assignment.',
				'response' => $response
			]);
		}
		
	}



	public function updatePositions(Request $request,$section_id){

		$ids = explode(',',$request->input('ids'));

		if(count($ids)>0){
			$count = 0;
			foreach($ids as $index=>$id){
				$assignment = Assignment::find($id);
				if($assignment!=null && $assignment->assignment_section_id==$section_id){
					$count++;
					$assignment->assignment_position = $count;
					$assignment->save();
				}

			}
		}

		$assignments = Assignment::where('assignment_section_id',$section_id)->orderBy('assignment_position')->get();
		$response = '';

		foreach($assignments as $assignment){
			$response .= view('backend.courses.blocks.assignment',['assignment' => $assignment])->render();
		}
	
		
		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

		
	}


	

	public function getAssignmentTemplate(Request $request){

		$response = view('backend.courses.blocks.assignment')->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);
	}


	public function markingCourses(Request $request){

		$user = Auth::user();

		$courses = $user->courses;

		return view('backend.marking.courses')
				->with('courses',$courses);

	}

	public function assignmentsByCourse(Request $request,$course_id){

		$course = Course::find($course_id);

		if($course!=null){

			if(Helpers::hasAssignmentPermission($course_id)){

				$modules = $course->modules;
				$sections = [];				

				foreach($modules as $index=>$module){
					$sections = array_merge($sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());
				}


				$logs_assignment = LogAssignment::whereNotNull('assignment_status')->where('assignment_status','<>','IN_PROGRESS')->whereIn('log_assignment_section_id', $sections)->orderBy('assignment_status')->orderBy('assignment_updated_date','DESC')->get();

				return view('backend.marking.assignments')
					->with('course',$course)
					->with('logs_assignment',$logs_assignment);

			}

			
		}

	}


	public function assignmentsByStudent(Request $request,$student_id){

		$student = Student::find($student_id);

		$user = Auth::user();

		$courses = $user->courses;

		$assignments = collect([]);

		foreach($courses as $course){

            $modules = $course->modules;
            $sections = [];
            
            foreach($modules as $index=>$module){
                $sections = array_merge($sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());
            }

			$logs_assignment = LogAssignment::where('log_student_id',$student->student_id)->whereNotNull('assignment_status')->where('assignment_status','<>','IN_PROGRESS')->whereIn('log_assignment_section_id', $sections)->orderBy('assignment_status')->orderBy('assignment_updated_date','DESC')->get();
			

			$assignments = $assignments->merge($logs_assignment);

        }

		return view('backend.marking.assignments')
					->with('logs_assignment',$assignments);

	}

	public function assignments(Request $request){

		$user = Auth::user();

		$courses = $user->courses;

		if($user->role->role_name == 'Administrator'){
			$courses = Course::all();
		}

		$assignments = collect([]);

		foreach($courses as $course){

            $modules = $course->modules;
            $sections = [];
            
            foreach($modules as $index=>$module){
                $sections = array_merge($sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());
            }

			$logs_assignment = LogAssignment::whereNotNull('assignment_status')->where('assignment_status','<>','IN_PROGRESS')->whereIn('log_assignment_section_id', $sections)->orderBy('assignment_status')->orderBy('assignment_updated_date','DESC')->get();
			

			$assignments = $assignments->merge($logs_assignment);

        }

		return view('backend.marking.assignments')
					->with('logs_assignment',$assignments);

	}


	public function students(Request $request){

		$user = Auth::user();

		$courses = $user->courses;

		$sections = [];

		foreach($courses as $course){

			$modules = $course->modules;
            
            foreach($modules as $index=>$module){
                $sections = array_merge($sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());
            }

			
		}

		

		$students = collect([]);

		foreach($courses as $course){

           
			$enrollments = $course->enrollments;
			

			foreach($enrollments as $enrollment){

				$student = $enrollment->student;


				if($student->logAssignments->where('assignment_status','<>','IN_PROGRESS')->whereIn('log_assignment_section_id',$sections)->count()>0){
					$students = $students->merge(collect([$student]));

				}

			}

        }

		$students = $students->sortBy('student_first_name')->unique();

		return view('backend.marking.students')
					->with('students',$students);


	}


	public function gradingPage(Request $request,$log_id){

		$log_assignment = LogAssignment::find($log_id);

		if($log_assignment!=null){

			$student = $log_assignment->student;
			$course = $log_assignment->section->module->course;

			if(Auth::user()->role->role_name == 'Instructor'){
				return view('backend.marking.grading')
				->with('log_assignment',$log_assignment)
				->with('student',$student)
				->with('course',$course);
			}
			else{
				return view('backend.marking.detail')
				->with('log_assignment',$log_assignment)
				->with('student',$student)
				->with('course',$course);
			}

			
		}

	}


	public function listAssignmentFolderContent(Request $request,$log_id,$assignment_id){
		
		$files = Storage::files('assignment_log/'.$log_id.'/'.$assignment_id);
		$filesArray = array();
		
		foreach($files as $file){
			
			$tempFile = array();
			$tempFile['file_location'] = $file;
			$tempFile['file_name'] = basename($file);
			$tempFile['file_extension'] = pathinfo($file)['extension'];
			$tempFile['file_type'] = pathinfo($file)['extension'];
			$tempFile['file_log_id'] = $log_id;
            $tempFile['file_assignment_id'] = $assignment_id;

			array_push($filesArray,$tempFile);
		}

		$response = view('backend.marking.blocks.file')->with('files', $filesArray)->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);
		
	}

	public function startGrading(Request $request,$log_id){

		$back_url = null;

		if ($request->has('back_url') && !empty($request->input('back_url'))) {
			$back_url = $request->input('back_url');
		}

		$log_assignment = LogAssignment::find($log_id);

		if($log_assignment!=null){

			$course = $log_assignment->section->module->course;

			if(Helpers::hasAssignmentPermission($course->course_id)){

				$log_assignment->assignment_status='IN_MARKING';
				$log_assignment->save();

				return back()->withInput()->with('message','Marking has been started.')->with('back_url',$back_url);

			}



		}



	}


	public function submitGrading(Request $request,$log_id){

		$back_url = null;

		if ($request->has('back_url') && !empty($request->input('back_url'))) {
			$back_url = $request->input('back_url');
		}
		
		$log_assignment = LogAssignment::find($log_id);

		if($log_assignment!=null){

			$course = $log_assignment->getCourse();

			if(Helpers::hasAssignmentPermission($course->course_id)){

				$request->merge(['assignment_score'=>intval($request->input('assignment_score'))]);

				$log_assignment->assignment_marking_comments=$request->input('assignment_marking_comments');
				$log_assignment->assignment_score=$request->input('assignment_score');
				$log_assignment->assignment_status='COMPLETE';
				$log_assignment->save();

                if($log_assignment->student!=null){

                    $email = $log_assignment->student->student_email;
                    $lead = 'Dear '.$log_assignment->student->getFullName().',';
                    $content = '<p>Your assignment on '.$course->course_name.' Module ['.$log_assignment->section->module->module_position.'] - ['.$log_assignment->section->module->module_name.'] has been graded at ['.Carbon::now()->format('Y/m/d H:i:s').'].</p>';
                    $content .= '<p>The ICAA Education team</p>';
                    $subject = 'Assignment Grading';
                    
            
                    try {
            
                        Mail::to($email)->bcc(config('setting.general_bcc'))->send(new SystemEmail($lead,$content,$subject));
            
                    } catch(\Exception $e) {
            
            
                    }
                }


				if(Helpers::setStudentCourseStat($log_assignment->log_student_id,$course->course_id)){

				}
				else{
					return back()->withInput()->with('error','Score has been submitted, but fail to update the course statistics')->with('back_url',$back_url);
				}

				return back()->withInput()->with('message','Score has been submitted.')->with('back_url',$back_url);

			}



		}



	}

	public function resetGrading(Request $request,$log_id){

		$back_url = null;

		if ($request->has('back_url') && !empty($request->input('back_url'))) {
			$back_url = $request->input('back_url');
		}
		
		$log_assignment = LogAssignment::find($log_id);

		if($log_assignment!=null){

			$course = $log_assignment->section->module->course;

			if(Helpers::hasAssignmentPermission($course->course_id)){


				$log_assignment->assignment_marking_comments=null;
				$log_assignment->assignment_score=null;
				$log_assignment->assignment_status='IN_PROGRESS';
				$log_assignment->save();
				
				if(Helpers::setStudentCourseStat($log_assignment->log_student_id,$course->course_id)){
					return redirect()->route('admin.marking.assignments')->with('message','Assignment has been resetted.');
				}
				else{
					return redirect()->route('admin.marking.assignments')->with('error','Score has been submitted, but fail to update the course statistics');
				}

				

			}



		}



	}

	public function resetAssignment(Request $request,$log_id){

		$log_assignment = LogAssignment::find($log_id);

		if($log_assignment!=null){

			$course = $log_assignment->section->module->course;

			if(Helpers::hasAssignmentPermission($course->course_id)){


				$log_assignment->assignment_marking_comments=null;
				$log_assignment->assignment_score=null;
				$log_assignment->assignment_status='IN_PROGRESS';
				$log_assignment->save();

				$enrollment_student_id = $log_assignment->log_student_id;
				$course_id = $course->course_id;

				Helpers::setStudentCourseStat($enrollment_student_id,$course_id);

				$logs_assignment = LogAssignment::select()
				->where('log_student_id',$enrollment_student_id)
				->where('assignment_status','COMPLETE')
				->join('sections', function ($join) use ($course_id)  {
					$join->on('sections.section_id', 'logs_assignment.log_assignment_section_id')
							->join('modules',function($join) use ($course_id) {
							$join->on('modules.module_id','sections.section_module_id')
									->where('modules.module_course_id',$course_id);
						});
				}) 
				->orderBy('assignment_updated_date','DESC')
				->get();


				$response = '';

				foreach($logs_assignment as $log_assignment){
					$response .= view('backend.courses.blocks.score-assignment',['log_assignment' => $log_assignment])->render();
				}

				return response()->json([
					'status' 	=> 'success',
					'message'	=> 'Assignment has been reset',
					'response' 	=> $response
				]);

			}

		}

	}
	
}