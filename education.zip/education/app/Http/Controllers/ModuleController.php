<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\Role;
use App\Models\User;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use Carbon\Carbon;

class ModuleController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => []]);
        
    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}

    

	public function index(Request $request,$course_id){


	}

	public function create(){


	}

	public function store(Request $request,$course_id){


		if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
			$request->merge(['module_status'=>'PUBLIC']);
		}
		else{
			$request->merge(['module_status'=>'PRIVATE']);
		}

		$request->merge(['module_course_id'=>$course_id]);


		$max_position = Module::where('module_course_id', $course_id)->max('module_position');

		if($max_position == null){
			$max_position = 0;
		}

		$request->merge(['module_position'=>$max_position+1]);

		$validator = Validator::make($request->all(), [
			'module_name'				=> 'required|max:255',
			'module_course_id'			=> 'required',
			'module_status'				=> 'required',
			'module_position'			=> 'required',
		]);

		if ($validator->fails()) {

			return response()->json([
				'status' => 'failure',
				'errors' => $validator
				]);
        }
		else{
			
			$module = Module::create([
				'module_name'				=> $request->input('module_name'),
				'module_course_id'			=> $request->input('module_course_id'),
				'module_status'				=> $request->input('module_status'),
				'module_position'			=> $request->input('module_position'),
			]);


			$modules = Module::where('module_course_id',$course_id)->orderBy('module_position')->get();
			$response = '';

			foreach($modules as $module){
				$response .= view('backend.courses.blocks.module',['module' => $module])->render();
			}
		
			
			return response()->json([
			    'status' => 'success',
			    'response' => $response
				]);
		}
	}

	public function show($module_id){

	}

	public function edit($course_id,$module_id){
		
		$module = Module::find($module_id);

		$sections = Section::where('section_module_id',$module_id)->orderBy('section_position')->get();

		$types = config('setting.section_type');

		if($module != null){

			return view('backend.courses.modules.edit')
				->with('module',$module)
				->with('sections',$sections)
				->with('types',$types);
		}
	}

	public function update(Request $request,$course_id,$module_id){

		$module = Module::find($module_id);

		if($module != null){

			if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
				$request->merge(['module_status'=>'PUBLIC']);
			}
			else{
				$request->merge(['module_status'=>'PRIVATE']);
			}

			$validator = Validator::make($request->all(), [
				'module_name'				=> 'required|max:255',
				'module_prefix'				=> 'nullable',
				'module_status'				=> 'required',
				'module_description'		=> 'nullable',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.modules.edit',['course_id'=>$module->module_course_id,'module_id'=>$module->module_id])
							->withErrors($validator)
							->withInput();
			}
			else{

				$module->update([
					'module_name'				=> $request->input('module_name'),
					'module_prefix'				=> $request->input('module_prefix'),
					'module_status'				=> $request->input('module_status'),
					'module_description'		=> $request->input('module_description'),
				]);
				
			}

			return redirect()->route('admin.courses.edit',['course_id'=>$module->module_course_id,'module_id'=>$module->module_id]);
		}

		
	}

	public function destroy($course_id,$module_id){

		$module = Module::find($module_id);

		if($module!=null && $module->module_course_id==$course_id){

			Module::destroy($module_id);

			$modules = Module::where('module_course_id',$course_id)->orderBy('module_position')->get();
			$response = '';
	
			foreach($modules as $module){
				$response .= view('backend.courses.blocks.module',['module' => $module])->render();
			}
	
			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted module.',
				'response' => $response
			]);
		}

		return response()->json([
			'status' => 'failure',
			'message' => 'Cannot delete module.'
		]);

		
	}
	
	public function destroyMany(Request $request){

		$ids = explode(",",$request->input('ids'));

		Module::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted modules.',
		]);
	}


	public function updatePositions(Request $request,$course_id){

		$ids = explode(',',$request->input('ids'));

		if(count($ids)>0){
			$count = 0;
			foreach($ids as $index=>$id){
				$module = Module::find($id);
				if($module!=null && $module->module_course_id==$course_id){
					$count++;
					$module->module_position = $count;
					$module->save();
				}

			}
		}

		$modules = Module::where('module_course_id',$course_id)->orderBy('module_position')->get();

		$response = '';

		foreach($modules as $module){
			$response .= view('backend.courses.blocks.module',['module' => $module])->render();
		}
		
			
		return response()->json([
			'status' => 'success',
			'response' => $response
			]);

		
	}



	public function showThumbnail(Request $request,$course_id,$module_id){
	
	
	    if(Storage::exists('course/'.$course_id.'/module/'.$module_id.'/thumbnail.jpg')){
				
			return response()->file(storage_path('app/course/'.$course_id.'/module/'.$module_id.'/thumbnail.jpg'),['Content-Type'=>'image/jpeg']);
		
		}
		else{
		
			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}
	    
	    
    }




	public function uploadThumbnail(Request $request,$course_id,$module_id){
		
		if($this->hasPermission()){

			$response = $request->input('cover-file');
		
			$response = json_decode($response, true);
			
			$field =  $response['output']['field'];
			
			if (request()->hasFile($field)) {
				
				$file = request()->file($field)->storeAs(
					'course/'.$course_id.'/module/'.$module_id, 'thumbnail.jpg'
				);
				
				return response()->json([
					'status' => 'success',
					'name' => 'thumbnail.jpg',
					'path' => $file
				]);
				
			}
		}

		

        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);
		

	}
	
	public function removeThumbnail(Request $request,$course_id,$module_id){
		
		if($this->hasPermission()){
			
			if(Storage::exists('course/'.$course_id.'/module/'.$module_id.'/thumbnail.jpg')){
					
				Storage::delete('course/'.$course_id.'/module/'.$module_id.'/thumbnail.jpg');

				return response()->json([
			    'status' => 'success',
			    'name' => 'thumbnail.jpg'
				]);
			
			}
			else{
				
				return response()->json([
			    'status' => 'failure',
			    'message' => 'Cover does not exist'
				]);
			}

		}
		else{
			
			return response()->json([
			    'status' => 'failure',
			    'message' => 'You do not have permission to delete this cover'
			]);
		}
	}


	
}