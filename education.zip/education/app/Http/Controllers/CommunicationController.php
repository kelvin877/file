<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Enrollment;
use App\Models\Order;
use App\Models\Student;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use App\Models\SectionFile;
use App\Models\Test;
use App\Models\Discussion;
use App\Models\PrivateDiscussion;
use App\Models\Comment;
use App\Models\Reply;
use App\Models\Message;
use Carbon\Carbon;
use Helpers;

class CommunicationController extends Controller
{
    //
    public function __construct()
    {
        
        
    }

    public function index(Request $request,$course_slug){

		$course = Course::where('course_slug',$course_slug)->first();

		

		if($course!=null){

			$discussions = $course->discussions()->orderBy('created_at','desc')->paginate(20);


			return view('frontend.courses.discussions.index')
					->with('course',$course)
					->with('course_slug',$course_slug)
					->with('discussions',$discussions);
		}

		
	}

	public function create(){



	}

	public function store(Request $request,$course_slug){

		$course = Course::where('course_slug',$course_slug)->first();

		if($course!=null){


			$request->merge(['discussion_course_id'=>$course->course_id]);

			if(Auth::guard('student')->check()){
				$request->merge(['discussion_student_id'=>Auth::guard('student')->user()->student_id]);
			}
			elseif(Auth::check()){
				$request->merge(['discussion_user_id'=>Auth::user()->id]);
			}
			
			$validator = Validator::make($request->all(), [
				'discussion_title'          	=> 'required',
				'discussion_course_id'			=> 'required',
        		'discussion_student_id'			=> '',
        		'discussion_user_id'			=> ''
			]);
	
			if ($validator->fails()) {
				return redirect()->route('courses.discussion',['course_slug'=>$course_slug])
							->withErrors($validator)
							->withInput();
			}
			else{
				
				
				$discussion = Discussion::create($request->all());

				
				
	
				
				return redirect()->route('courses.discussion',['course_slug'=>$course_slug])->with('message','A new topic has been created!');
			}

		}

	}

	public function discussionComments(Request $request,$course_slug,$discussion_id){

		$course = Course::where('course_slug',$course_slug)->first();

		$discussion = Discussion::find($discussion_id);

		


		if($course!=null && $discussion!=null && $course->course_id==$discussion->course->course_id){

			$comments = $discussion->comments()->orderBy('created_at','desc')->get();

			return view('frontend.courses.discussions.comments')
					->with('course',$course)
					->with('course_slug',$course_slug)
					->with('discussion',$discussion)
					->with('comments',$comments);
		}

	}

	public function commentStore(Request $request,$course_slug,$discussion_id){

		$course = Course::where('course_slug',$course_slug)->first();

		

		if($course!=null && $discussion!=null && $course->course_id==$discussion->course->course_id){

			$discussion = Discussion::find($discussion_id);

			
			$request->merge(['comment_discussion_id'=>$discussion_id]);

			if(Auth::guard('student')->check()){
				$request->merge(['comment_student_id'=>Auth::guard('student')->user()->student_id]);
			}
			elseif(Auth::check()){
				$request->merge(['comment_user_id'=>Auth::user()->id]);
			}



			
			$validator = Validator::make($request->all(), [
				'comment_content'          	=> 'required',
				'comment_discussion_id'		=> 'required',
        		'comment_student_id'		=> '',
        		'comment_user_id'			=> ''
			]);
	
			if ($validator->fails()) {
				return redirect()->route('courses.discussion.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])
							->withErrors($validator)
							->withInput();
			}
			else{


				if($request->has('quote_value') && $request->input('quote_value')!='' && $request->input('quote_value')!=null){


					$cid = intval($request->input('quote_value'));
	
					$comment = Comment::find($cid);
	
					if($comment!=null){
	
	
						$quote = '<blockquote><p>'.$comment->account->getFullName().' ['.$comment->created_at.'] </p>'.$comment->comment_content.'</blockquote><br/><br/>';
						$request->merge(['comment_content'=>$quote.$request->input('comment_content')]);
	
						
					}
				}
				
				
				Comment::create($request->all());


				$css = '<style>hr{border-top: 1px dashed #8c8b8b;border-bottom: 1px dashed #fff;}blockquote{margin: 1em 0;background: #eee;padding: 1em;border-radius: 1em;}</style>';


				if($discussion->discussion_user_id!=null){

					$user = $discussion->account;
					$email = $user->getEmail();;
					$lead = 'Hi '.$user->getFullName().',';
					$content = '<p>Your topic from course ['.$course->course_name.'] has a new comment.</p>';
					$content .= '<p>&nbsp;</p><hr/><p>'.$request->input('comment_content').'</p><hr/><p>&nbsp;</p>';
					$content .= '<p>Regards,<br/>ICAA Education</p>';
					$content = $css.$content;
					$subject = 'Your topic has a new comment.';


					try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
		
					} catch(\Exception $e) {

					}

				}
				elseif($discussion->discussion_student_id!=null){


					$student = $discussion->account;
					$email = $student->student_email;
					$lead = 'Hi '.$student->student_first_name.' '.$student->student_last_name.',';
					$content = '<p>Your topic from course ['.$course->course_name.'] has a new comment.</p>';
					$content .= '<p>&nbsp;</p><hr/><p>'.$request->input('comment_content').'</p><hr/><p>&nbsp;</p>';
					$content .= '<p>Regards,<br/>ICAA Education</p>';
					$content = $css.$content;
					$subject = 'Your topic has a new comment.';
	
					try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
		
					} catch(\Exception $e) {

						
					}

					
				}


				

				
	
				
				return redirect()->route('courses.discussion.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])->with('message','A new comment has been created!');
			}



		}

	}

	public function getComment(Request $request,$comment_id){

		$comment = Comment::find($comment_id);


		if($comment!=null){


			return response()->json([
				'status' => 'success',
				'content' => view('frontend.courses.blocks.comment-block')->with('comment',$comment)->render(),
			]);



		}

	}

	public function show(Request $request,$discussion_id){

	}

	public function edit(Request $request,$discussion_id){
		

	}

	public function update(Request $request,$discussion_id){


		
	}


	public function destroy(Request $request,$discussion_id){


		$discussion = Discussion::find($discussion_id);

		if($discussion!=null){

			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$discussion->discussion_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$discussion->course->course_instructor_id)){

				$discussion->delete();

				return back()
					->with('message','A discussion topic has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this topic!');

			}

			

			

		}		


		return back()
				->with('error','Fail to remove this topic!');



	}

	public function commentDestroy(Request $request,$comment_id){


		

		$comment = Comment::find($comment_id);

		if($comment!=null){


			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$comment->comment_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$comment->discussion->course->course_instructor_id)){

				$comment->delete();

				return back()
					->with('message','A comment has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this comment!');

			}


		}		

		return back()
				->with('error','Fail to remove this comment!');


	}


	public function discussionCourses(Request $request){

		$user = Auth::user();

		$courses = $user->courses;

		if(Auth::check() && Auth::user()->isAdmin()){
			$courses = Course::all();
		}

		return view('backend.communication.courses')
				->with('courses',$courses);

	}

	public function students(Request $request,$course_id){

		$user = Auth::user();

		$courses = $user->courses;

		if(Auth::check() && Auth::user()->isAdmin()){
			$courses = Course::all();
		}

		$course = Course::find($course_id);

		if($course != null && in_array($course_id,$courses->pluck('course_id')->toArray())){


			$enrollments = $course->enrollments;

			return view('backend.communication.students')
				->with('course',$course)
				->with('enrollments',$enrollments);


		}
		else{

			return 'error';
		}


	}

	public function privates(Request $request,$course_id){


		$user = Auth::user();

		$courses = $user->courses;

		if(Auth::check() && Auth::user()->isAdmin()){
			$courses = Course::all();
		}

		$course = Course::find($course_id);

		if($course != null && in_array($course_id,$courses->pluck('course_id')->toArray())){

			$discussions = $course->private_discussions->sortByDesc('created_at');

			$enrollments = $course->enrollments;

			return view('backend.communication.private')
				->with('course',$course)
				->with('enrollments',$enrollments)
				->with('discussions',$discussions);


		}
		else{

			return 'error';
		}

	}

	public function communication_by_enrollment(Request $request,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment!=null){

			$course = $enrollment->course;

			$student = $enrollment->student;

			

			$discussion_ids = $course->discussions->pluck('discussion_id')->toArray();


			$discussions = Discussion::Where('discussion_student_id',$student->student_id)->Where('discussion_course_id',$course->course_id)->orderBy('created_at','DESC')->get();

			$comments = Comment::Where('comment_student_id',$student->student_id)->whereIn('comment_discussion_id',$discussion_ids)->orderBy('created_at','DESC')->get();

			
			return view('frontend.courses.discussions.student')
			->with('course',$course)
			->with('student',$student)
			->with('discussions',$discussions)
			->with('comments',$comments);
		}

	}

	public function private_communication_by_enrollment(Request $request,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment!=null){

			if(!Helpers::checkEnrollmentPermission($enrollment_id)){
				return 'error';
			}

			$course = $enrollment->course;

			$modules = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->orderBy('module_position')->get();

			$student = $enrollment->student;


			$discussions = PrivateDiscussion::Where('discussion_student_id',$student->student_id)->Where('discussion_course_id',$course->course_id)->orderBy('created_at','DESC')->paginate(20);

			
			return view('frontend.courses.discussions.private')
			->with('student',$student)
			->with('course',$course)
			->with('modules',$modules)
			->with('discussions',$discussions);
		}

	}

	public function private_communication_store(Request $request,$enrollment_id){


		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment!=null){

			$course = $enrollment->course;

			$student = $enrollment->student;
			$instructor = $course->instructor;

			$request->merge(['discussion_course_id'=>$course->course_id]);
			$request->merge(['discussion_enrollment_id'=>$enrollment_id]);

			$message_from_type = null;
			$message_from_id = null;
			$message_to_type = null;
			$message_to_id = null;
			$user = null;


			if(Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$student->student_id){
				$request->merge(['discussion_student_id'=>$student->student_id]);
				$message_from_type = "STUDENT";
				$message_from_id = Auth::guard('student')->user()->student_id;
				$message_to_type = "USER";
				$message_to_id = $course->course_instructor_id;
				$user = $instructor;
			}
			elseif(Auth::check()){
				$request->merge(['discussion_user_id'=>Auth::user()->id]);
				$request->merge(['discussion_student_id'=>$student->student_id]);
				$message_from_type = "USER";
				$message_from_id = Auth::user()->id;
				$message_to_type = "STUDENT";
				$message_to_id = $student->student_id;
				$user = $student;
			}

			$validator = Validator::make($request->all(), [
				'discussion_title'          	=> 'required',
				'discussion_course_id'			=> 'required',
        		'discussion_student_id'			=> 'required',
        		'discussion_user_id'			=> ''
			]);
	
			if ($validator->fails()) {
				return redirect()->route('courses.discussion.private',['enrollment_id'=>$enrollment_id])
							->withErrors($validator)
							->withInput();
			}
			else{
				
				
				$discussion = PrivateDiscussion::create($request->all());

				$url = route('courses.discussion.private.replies',['discussion_id'=>$discussion->discussion_id]);

				$notification_content = $request->input('discussion_title').'<br><br><a href="'.$url.'" target="_blank">'.$url.'</a>';

				if($message_from_type!=null && $message_from_id!=null && $message_to_type!=null && $message_to_id!=null){
					$message = Message::create([
						'message_from_type' 	=> $message_from_type,
						'message_from_id' 		=> $message_from_id,
						'message_to_type' 		=> $message_to_type,
						'message_to_id' 		=> $message_to_id,
						'message_content' 		=> $notification_content,
						'message_reference_id' 	=> null,
						'message_tags' 			=> $request->has('discussion_tags')&&$request->input('discussion_tags')!=null&&is_array($request->input('discussion_tags'))?implode(',',$request->input('discussion_tags')):null,
						'message_read' 			=> 'NO',
					]);
				}


				$css = '<style>hr{border-top: 1px dashed #8c8b8b;border-bottom: 1px dashed #fff;}blockquote{margin: 1em 0;background: #eee;padding: 1em;border-radius: 1em;}</style>';


				$email = $user->getEmail();
				$lead = 'Hi '.$user->getFullName().',';
				$content = '<p>Private discussion board ['.$student->getFullName().'] from course ['.$course->course_name.'] has a new topic.</p>';
				$content .= '<p>&nbsp;</p><hr/><p>'.$notification_content.'</p><hr/><p>&nbsp;</p>';
				$content .= '<p>Regards,<br/>ICAA Education</p>';
				$content = $css.$content;
				$subject = 'Your have a new private discussion topic.';


				try {

					Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
	
				} catch(\Exception $e) {

				}

				
				
	
				
				return redirect()->route('courses.discussion.private',['enrollment_id'=>$enrollment_id])->with('message','A new topic has been created!');
			}

			
		}
		

	}

	public function private_communication_destroy(Request $request,$discussion_id){

		$discussion = PrivateDiscussion::find($discussion_id);

		if($discussion!=null){

			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$discussion->discussion_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$discussion->course->course_instructor_id)){

				$discussion->delete();

				return back()
					->with('message','A discussion topic has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this topic!');

			}

			

			

		}		


		return back()
				->with('error','Fail to remove this topic!');


	}
	
	public function private_communication_replies(Request $request,$discussion_id){

		

		$discussion = PrivateDiscussion::find($discussion_id);

		


		if($discussion!=null){

			$replies = $discussion->replies()->orderBy('created_at','desc')->get();

			return view('frontend.courses.discussions.replies')
					->with('discussion',$discussion)
					->with('replies',$replies);
		}

	}

	public function private_communication_replie_store(Request $request,$discussion_id){

		$discussion = PrivateDiscussion::find($discussion_id);

		$course = $discussion!=null?$discussion->course:null;

		if($course!=null && $discussion!=null){

			
			$student = $discussion->student;
			$instructor = $course->instructor;

			
			$request->merge(['reply_discussion_id'=>$discussion_id]);

			$message_from_type = null;
			$message_from_id = null;
			$message_to_type = null;
			$message_to_id = null;
			$user = null;

			if(Auth::guard('student')->check()){
				$request->merge(['reply_student_id'=>Auth::guard('student')->user()->student_id]);
				$message_from_type = "STUDENT";
				$message_from_id = Auth::guard('student')->user()->student_id;
				$message_to_type = "USER";
				$message_to_id = $course->course_instructor_id;
				$user = $instructor;
			}
			elseif(Auth::check()){
				$request->merge(['reply_user_id'=>Auth::user()->id]);
				$message_from_type = "USER";
				$message_from_id = Auth::user()->id;
				$message_to_type = "STUDENT";
				$message_to_id = $student->student_id;
				$user = $student;
			}

			
			$validator = Validator::make($request->all(), [
				'reply_content'         => 'required',
				'reply_discussion_id'	=> 'required',
        		'reply_student_id'		=> '',
        		'reply_user_id'			=> ''
			]);
	
			if ($validator->fails()) {
				return redirect()->route('courses.discussion.private.replies',['discussion_id'=>$discussion_id])
							->withErrors($validator)
							->withInput();
			}
			else{


				if($request->has('quote_value') && $request->input('quote_value')!='' && $request->input('quote_value')!=null){


					$rid = intval($request->input('quote_value'));
	
					$reply = Reply::find($rid);
	
					if($reply!=null){
	
	
						$quote = '<blockquote><p>'.$reply->account->getFullName().' ['.$reply->created_at.'] </p>'.$reply->reply_content.'</blockquote><br/><br/>';
						$request->merge(['reply_content'=>$quote.$request->input('reply_content')]);
	
						
					}
				}
				
				Reply::create($request->all());

				$url = route('courses.discussion.private.replies',['discussion_id'=>$discussion->discussion_id]);

				$notification_content = $request->input('reply_content').'<br><br><a href="'.$url.'" target="_blank">'.$url.'</a>';

				if($message_from_type!=null && $message_from_id!=null && $message_to_type!=null && $message_to_id!=null){
					$message = Message::create([
						'message_from_type' 	=> $message_from_type,
						'message_from_id' 		=> $message_from_id,
						'message_to_type' 		=> $message_to_type,
						'message_to_id' 		=> $message_to_id,
						'message_content' 		=> $notification_content,
						'message_reference_id' 	=> null,
						'message_tags' 			=> null,
						'message_read' 			=> 'NO',
					]);
				}


				$css = '<style>hr{border-top: 1px dashed #8c8b8b;border-bottom: 1px dashed #fff;}blockquote{margin: 1em 0;background: #eee;padding: 1em;border-radius: 1em;}</style>';


				$email = $user->getEmail();
				$lead = 'Hi '.$user->getFullName().',';
				$content = '<p>Private discussion board ['.$student->getFullName().'] from course ['.$course->course_name.'] has a new reply.</p>';
				$content .= '<p>&nbsp;</p><hr/><p>'.$notification_content.'</p><hr/><p>&nbsp;</p>';
				$content .= '<p>Regards,<br/>ICAA Education</p>';
				$content = $css.$content;
				$subject = 'Your have a new private discussion reply.';


				try {

					Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
	
				} catch(\Exception $e) {

				}
				
				return redirect()->route('courses.discussion.private.replies',['discussion_id'=>$discussion_id])->with('message','A new message has been created!');
			}



		}

	}

	public function getReply(Request $request,$reply_id){

		$reply = Reply::find($reply_id);


		if($reply!=null){


			return response()->json([
				'status' => 'success',
				'content' => view('frontend.courses.blocks.reply-block')->with('reply',$reply)->render(),
			]);



		}

	}

	public function private_communication_replie_destroy(Request $request,$reply_id){


		$reply = Reply::find($reply_id);

		if($reply!=null){


			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$reply->reply_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$reply->discussion->course->course_instructor_id)){

				$reply->delete();

				return back()
					->with('message','A comment has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this comment!');

			}


		}		

		return back()
				->with('error','Fail to remove this comment!');

	}

	public function private_communication_student(Request $request,$course_slug){

		$course = Course::where('course_slug',$course_slug)->first();

        if($course!=null){

			if(Auth::check()){

			}
			elseif(Auth::guard('student')->check()){

				$student = Auth::guard('student')->user();
	
	
				$enrollment = $student->enrollments()
								->where('enrollment_course_id',$course->course_id)
								->where(function ($query) {
									$query->where('enrollment_status','IN_PROGRESS')
										  ->orWhere('enrollment_status','COMPLETE');
								})
								->orderBy('updated_at','desc')->get()->first();
	
				if($enrollment!=null){
	
					return redirect()->route('courses.discussion.private',['enrollment_id'=>$enrollment->enrollment_id]);
	
				}
			
			}
           
        }

		

		return redirect()->route('courses.summary',['course_slug'=>$course_slug])->with('message','You do not have permission');
		

	}




}
