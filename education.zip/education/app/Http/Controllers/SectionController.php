<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\Role;
use App\Models\User;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use Carbon\Carbon;
use Image;

class SectionController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => ['displaySectionFile']]);

    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}



	public function index(Request $request,$module_id){


	}

	public function create(){


	}

	public function store(Request $request,$course_id,$module_id){


		if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
			$request->merge(['section_status'=>'PUBLIC']);
		}
		else{
			$request->merge(['section_status'=>'PRIVATE']);
		}

		$request->merge(['section_module_id'=>$module_id]);


		$max_position = Section::where('section_module_id', $module_id)->max('section_position');

		if($max_position == null){
			$max_position = 0;
		}

		$request->merge(['section_position'=>$max_position+1]);

		$validator = Validator::make($request->all(), [
			'section_name'				=> 'required|max:255',
			'section_module_id'			=> 'required',
			'section_status'			=> 'required',
			'section_type'				=> 'required',
			'section_position'			=> 'required',
		]);

		if ($validator->fails()) {

			return response()->json([
				'status' => 'failure',
				'errors' => $validator
				]);
        }
		else{

			$section = Section::create([
				'section_name'				=> $request->input('section_name'),
				'section_module_id'			=> $request->input('section_module_id'),
				'section_status'			=> $request->input('section_status'),
				'section_type'				=> $request->input('section_type'),
				'section_position'			=> $request->input('section_position'),
			]);


			$sections = Section::where('section_module_id',$module_id)->orderBy('section_position')->get();
			$response = '';

			foreach($sections as $section){
				$response .= view('backend.courses.blocks.section',['section' => $section])->render();
			}


			return response()->json([
			    'status' => 'success',
			    'response' => $response
				]);
		}
	}

	public function show($module_id){

	}

	public function edit($course_id,$module_id,$section_id){

		$section = Section::find($section_id);

		if($section != null){

			switch($section->section_type){
				case 'CONTENT':
					return view('backend.courses.sections.edit')
					->with('section',$section);
					break;
				case 'PRETEST':
					return view('backend.courses.pretests.edit')
					->with('section',$section);
					break;
				case 'QUIZ':
					return view('backend.courses.quizzes.edit')
					->with('section',$section);
					break;
        case 'RETAKE_QUIZ':
          return view('backend.courses.retake.edit')
          ->with('section',$section);
				case 'INTRODUCTION':
					return view('backend.courses.introductions.edit')
					->with('section',$section);
					break;
				case 'TABLE_OF_CONTENT':
					return view('backend.courses.tableofcontent.edit')
					->with('section',$section);
				case 'ASSIGNMENT':
					return view('backend.courses.assignments.edit')
					->with('section',$section);
					break;
				default:
					break;
			}


		}
	}

	public function update(Request $request,$course_id,$module_id,$section_id){


		$section = Section::find($section_id);

		if($section != null){

			if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
				$request->merge(['section_status'=>'PUBLIC']);
			}
			else{
				$request->merge(['section_status'=>'PRIVATE']);
			}

			if($request->has('content') && is_array($request->input('content')) ){
				$request->merge(['section_content'=>$request->input('content')]);
			}
			else{
				$request->merge(['section_content'=>array()]);
			}

			$validator = Validator::make($request->all(), [
				'section_name'				=> 'required|max:255',
				'section_prefix'			=> 'nullable',
				'section_status'			=> 'required',
				'section_content'			=> 'nullable',
				'section_description'		=> 'nullable',
				'section_explanation'		=> 'nullable',
			]);

			if ($validator->fails()) {

				return redirect()->route('admin.sections.edit',['course_id'=>$section->module->module_course_id,'module_id'=>$section->section_module_id,'section_id'=>$section->section_id])
							->withErrors($validator)
							->withInput();
			}
			else{

				$section->update([
					'section_name'				=> $request->input('section_name'),
					'section_prefix'			=> $request->input('section_prefix'),
					'section_status'			=> $request->input('section_status'),
					'section_content'			=> $request->input('section_content'),
					'section_description'		=> $request->input('section_description'),
					'section_explanation'		=> $request->input('section_explanation'),
				]);

			}

			return redirect()->route('admin.modules.edit',['course_id'=>$section->module->module_course_id,'module_id'=>$section->section_module_id]);
		}


	}

	public function destroy($course_id,$module_id,$section_id){

		$section = Section::find($section_id);

		if($section!=null){
			Section::destroy($section_id);

			$sections = Section::where('section_module_id',$module_id)->orderBy('section_position')->get();
			$response = '';

			foreach($sections as $section){
				$response .= view('backend.courses.blocks.section',['section' => $section])->render();
			}

			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted module.',
				'response' => $response
			]);
		}


	}

	public function destroyMany(Request $request){

		$ids = explode(",",$request->input('ids'));

		Module::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted modules.',
		]);
	}


	public function updatePositions(Request $request,$course_id,$module_id){

		$ids = explode(',',$request->input('ids'));

		if(count($ids)>0){
			$count = 0;
			foreach($ids as $index=>$id){
				$section = Section::find($id);
				if($section!=null && $section->section_module_id==$module_id){
					$count++;
					$section->section_position = $count;
					$section->save();
				}

			}
		}

		$sections = Section::where('section_module_id',$module_id)->orderBy('section_position')->get();
		$response = '';

		foreach($sections as $section){
			$response .= view('backend.courses.blocks.section',['section' => $section])->render();
		}


		return response()->json([
			'status' => 'success',
			'response' => $response
		]);


	}

	public function getPageTemplate(Request $request){

		$response = view('backend.courses.blocks.page')->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);
	}


	public function showThumbnail(Request $request,$course_id,$module_id,$section_id){


	    if(Storage::exists('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg')){

			return response()->file(storage_path('app/course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg'),['Content-Type'=>'image/jpeg']);

		}
		else{

			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}


    }




	public function uploadThumbnail(Request $request,$course_id,$module_id,$section_id){

		if($this->hasPermission()){

			$response = $request->input('cover-file');

			$response = json_decode($response, true);

			$field =  $response['output']['field'];

			if (request()->hasFile($field)) {

				$file = request()->file($field)->storeAs(
					'course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id, 'thumbnail.jpg'
				);

				return response()->json([
					'status' => 'success',
					'name' => $course_id.'.jpg',
					'path' => $file
				]);

			}
		}



        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);


	}

	public function removeThumbnail(Request $request,$course_id,$module_id,$section_id){

		if($this->hasPermission()){

			if(Storage::exists('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg')){

				Storage::delete('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg');

				return response()->json([
			    'status' => 'success',
			    'name' => $course_id.'.jpg'
				]);

			}
			else{

				return response()->json([
			    'status' => 'failure',
			    'message' => 'Cover does not exist'
				]);
			}

		}
		else{

			return response()->json([
			    'status' => 'failure',
			    'message' => 'You do not have permission to delete this cover'
			]);
		}
	}

	public function uploadImage(Request $request,$course_id,$module_id,$section_id){


		$section = Section::find($section_id);

		if($section!=null){

			$path = $request->file('file')->storeAs(
				'course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/image', $request->file('file')->getClientOriginalName()
			);

			$img = Image::make(Storage::path($path));

			$img->resize(800, null, function ($constraint) {
				$constraint->aspectRatio();
				$constraint->upsize();
			});

			$img->save();

			return response()->json([
				'status' => 'success',
				'name' => $request->file('file')->getClientOriginalName(),
				'path' => Storage::path($path)
			]);
		}


        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);


	}

	public function uploadPDF(Request $request,$course_id,$module_id,$section_id){


		$section = Section::find($section_id);

		if($section!=null){

			$path = $request->file('file')->storeAs(
				'course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/pdf', $request->file('file')->getClientOriginalName()
			);


			return response()->json([
				'status' => 'success',
				'name' => $request->file('file')->getClientOriginalName(),
				'path' => $path
			]);
		}


        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);


	}

	public function removeImage(Request $request,$course_id,$module_id,$section_id){

		$section = Section::find($section_id);

		if($section!=null){

			$file = $request->input('filename');

			$response = Storage::delete('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/image/'.$file)?'success':'failure';
			return response()->json([
				'status' => $response
			]);


		}

		return response()->json([
			'status' => 'failure',
			'message' => 'fail to remove image'
		]);

	}

	public function removePDF(Request $request,$course_id,$module_id,$section_id){

		$section = Section::find($section_id);

		if($section!=null){

			$file = $request->input('filename');

			$response = Storage::delete('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/pdf/'.$file)?'success':'failure';
			return response()->json([
				'status' => $response
			]);


		}

		return response()->json([
			'status' => 'failure',
			'message' => 'fail to remove pdf'
		]);

	}

	public function listImageFolderContent(Request $request,$course_id,$module_id,$section_id){

		$files = Storage::files('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/image');
		$filesArray = array();

		foreach($files as $file){

			$tempFile = array();
			$tempFile['file_location'] = $file;
			$tempFile['file_name'] = basename($file);
			$tempFile['file_extension'] = pathinfo($file)['extension'];
			$tempFile['file_type'] = 'image';
			$tempFile['file_section_id'] = $section_id;

			array_push($filesArray,$tempFile);
		}


		$response = view('backend.courses.blocks.file')->with('files', $filesArray)->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

	}

	public function listPDFFolderContent(Request $request,$course_id,$module_id,$section_id){

		$files = Storage::files('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/pdf');
		$filesArray = array();

		foreach($files as $file){

			$tempFile = array();
			$tempFile['file_location'] = $file;
			$tempFile['file_name'] = basename($file);
			$tempFile['file_extension'] = pathinfo($file)['extension'];
			$tempFile['file_type'] = 'pdf';
			$tempFile['file_section_id'] = $section_id;

			array_push($filesArray,$tempFile);
		}

		$response = view('backend.courses.blocks.file')->with('files', $filesArray)->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

	}

	public function displaySectionFile(Request $request,$section_id,$type,$file){

		$section = Section::find($section_id);

		if($section!=null){

			$course_id = $section->module->module_course_id;
			$module_id = $section->section_module_id;

			$pathToFile = Storage::path('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/'.$type.'/'.$file);

			return response()->file($pathToFile);

		}



	}

}
