<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Enrollment;
use App\Models\Order;
use App\Models\Student;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use App\Models\SectionFile;
use App\Models\Test;
use Carbon\Carbon;
use PDF;
use Helpers;

class EnrollmentController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth.admin',['except' => ['certificate']]);
        
    }

    public function index(){


	}

	public function create(){



	}

	public function store(Request $request){



	}

	public function show($enrollment_id){

	}

	public function edit($enrollment_id){
		

	}

	public function update(Request $request,$enrollment_id){



		
	}

	public function destroy($enrollment_id){


	}
	
	public function destroyMany(Request $request){

		$ids = explode(",",$request->input('ids'));

		Enrollment::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted enrollment records.',
		]);
	}


	public function request_edit(Request $request,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment != null){
			return view('backend.enrollment.edit')
				->with('enrollment',$enrollment);
		}


	}

	public function request_approval(Request $request,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment != null){

			$student = $enrollment->student;
			$course = $enrollment->course;

			$enrollment->enrollment_course_duration = $course->course_duration;
			$enrollment->enrollment_start_date = Carbon::now();
			$enrollment->enrollment_expiry_date = Carbon::now()->addDays($enrollment->enrollment_course_duration);
			
			$enrollment->enrollment_status = 'IN_PROGRESS';
			$enrollment->save();

			$order = $enrollment->order;
			$order->order_status = 'PAID';
			$order->save();


			$student = $enrollment->student;
			$student->student_status = 'APPROVED';
			$student->save();

			$course_name = $course->course_name;



			
			$email = $student->student_email;
			$lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
			$content = '<p>We are pleased to inform you that you are now able to access the '.$course_name.'.</p>';
			$content .= '<p>To start now, click here. <a href="https://education.icaa.cc/login">https://education.icaa.cc/login</a></p>';
			$content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
			$content .= '<p>All the best,</p>';
			$content .= '<p>The ICAA Education team</p>';
			$subject = 'Step 3: Start your ICAA certificate course now';

			try {

				Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

			} catch(\Exception $e) {

				
			}

			return redirect()->route('admin.students.requests')->with('message','A request has been approved.');
		}
	}

	public function requests(){

		$enrollments = Enrollment::where('enrollment_status','PENDING')->get();

		if($enrollments!=null){

			return view('backend.enrollment.requests')
				->with('enrollments',$enrollments);
		}


	}

	
	public function destroyManyRequests(Request $request){

		$ids = explode(",",$request->input('ids'));

		Enrollment::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted requests.',
		]);


	}

	public function generate_certificate(Request $request,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);

		if($enrollment != null){

			$student = $enrollment->student;
			$course = $enrollment->course;


			$enrollment->enrollment_graduation_date = Carbon::now();
			$enrollment->enrollment_graduation_score = $enrollment->enrollment_quiz_score;
			$enrollment->enrollment_status = 'COMPLETE';
			$enrollment->save();

		

			$course_name = $course->course_name;

			
			$email = $student->student_email;
			$lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
			$content = '<p>Congratulations on completing '.$course_name.' course work. As one of an elite group invested in advancing the aging and wellness profession, you have learned valuable skills and knowledge that will support your wellness endeavors.</p>';
			$content .= '<p>We trust that this accomplishment has been personally and professionally challenging and fulfilling, and you and your organization should be proud.</p>';
			$content .= '<p>Attached is the '.$course_name.' Certificate. To highlight your commitment to professional development we have enclosed, for your use, the course graduation logo and support materials.</p>';
			$content .= '<p>Please note that you can audit this course at any time.</p>';
			$content .= '<p>Thank you for your commitment to our industry, and congratulations once again.</p>';
			$content .= '<p>Sincerely,</p>';
			$content .= '<p>Colin Milner<br>CEO<br>International Council on Active Aging<br><a href="mailto:colinmilner@icaa.cc">colinmilner@icaa.cc</a><br><a href="https://www.icaa.cc">www.icaa.cc</a><br>866-335-97776</p>';
			$subject = $course_name.' Completion';

			//$viewfile = 'frontend.courses.certificate-template.'.$enrollment->course->course_slug;
			$viewfile = 'frontend.courses.certificate-template.'.$enrollment->course->certificate_template();
			
			if (!View::exists($viewfile)) {
				$viewfile = 'frontend.courses.certificate-pdf';
			}

			$pdf = PDF::loadView($viewfile, ['enrollment'=>$enrollment])->setPaper([0, 0, 905, 1190], 'landscape');

			try {

				$systemEmail = new SystemEmail($lead,$content,$subject);
				$systemEmail->attachData($pdf->output(), "certificate.pdf");

				$slug = $course->course_slug;

				if(Storage::exists('attachments/'.$slug)){

					$files = Storage::files('attachments/'.$slug);

					foreach ($files as $file){
						$systemEmail->attachFromStorage($file);
					}         

				}
				
				Mail::to($email)->bcc(config('setting.general_bcc'))->send($systemEmail);

			} catch(\Exception $e) {

			}

			return back()->with('message','An email with certificate attached has been sent to student');
		}
	}


	public function certificate(Request $request,$enrollment_id){

        $enrollment = Enrollment::find($enrollment_id);

		//$viewfile = 'frontend.courses.certificate-template.'.$enrollment->course->course_slug;
		$viewfile = 'frontend.courses.certificate-template.'.$enrollment->course->certificate_template();

		if (!View::exists($viewfile)) {
			$viewfile = 'frontend.courses.certificate-pdf';
		}

        if($enrollment!=null){

			$pdf = PDF::loadView($viewfile, ['enrollment'=>$enrollment])->setPaper([0, 0, 905, 1190], 'landscape');
			return $pdf->download($enrollment->course->course_name.' - Certificate - '.$enrollment->student->getFullName().'.pdf');

			// return view($viewfile)
            //         ->with('enrollment',$enrollment);
            
            if($enrollment->enrollment_graduation_date!=null && $enrollment->enrollment_status=='COMPLETE'){
                
                $pdf = PDF::loadView($viewfile, ['enrollment'=>$enrollment])->setPaper([0, 0, 905, 1190], 'landscape');
                return $pdf->download($enrollment->course->course_name.' - Certificate - '.$enrollment->student->getFullName().'.pdf');

            }
            else{

            }

            

        }

        

    }



}
