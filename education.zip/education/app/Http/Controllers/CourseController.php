<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\Role;
use App\Models\User;
use App\Models\Course;
use App\Models\Module;
use App\Models\Enrollment;
use App\Models\LogQuiz;
use App\Models\LogAssignment;
use Carbon\Carbon;

class CourseController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => []]);
        
    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}

    

	public function index(){

		$courses = Course::paginate(10);

		return view('backend.courses.index')
				->with('courses',$courses);
	}

	public function create(){


		$categories = config('setting.course_category');

		return view('backend.courses.create')
				->with('categories',$categories);
	}

	public function store(Request $request){


		if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
			$request->merge(['course_status'=>'PUBLIC']);
		}
		else{
			$request->merge(['course_status'=>'PRIVATE']);
		}

		$validator = Validator::make($request->all(), [
			'course_name'				=> 'required|max:255',
			'course_description'		=> 'nullable',
			'course_category'			=> 'required|max:255',
			'course_status'				=> 'required',
		]);

		if ($validator->fails()) {
            return redirect()->route('admin.courses.create')
                        ->withErrors($validator)
                        ->withInput();
        }
		else{
			
			$course = Course::create([
				'course_name'				=> $request->input('course_name'),
				'course_description'		=> $request->input('course_description'),
				'course_category'			=> $request->input('course_category'),
				'course_status'				=> $request->input('course_status'),
				'course_slug' 				=> Str::slug($request->input('course_name'), '-'),
			]);
			
			
			
			return redirect()->route('admin.courses.edit',['course_id'=>$course->course_id])->with('message','Course has been created! You can also fill in the detail below.');
		}
	}

	public function show($course_id){

	}

	public function edit($course_id){
		
		$course = Course::find($course_id);

		$modules = Module::where('module_course_id',$course_id)->orderBy('module_position')->get();

		$instructors = User::whereHas(
			'role', function($q){
				$q->where('role_name', 'Instructor');
			}
		)->get();


		if($course != null){

			$evaluation = $course->evaluation;

			$categories = config('setting.course_category');

			return view('backend.courses.edit')
				->with('course',$course)
				->with('categories',$categories)
				->with('modules',$modules)
				->with('instructors',$instructors)
				->with('evaluation',$evaluation);
		}
	}

	public function update(Request $request,$course_id){

		$course = Course::find($course_id);

		if($course != null){

			if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
				$request->merge(['course_status'=>'PUBLIC']);
			}
			else{
				$request->merge(['course_status'=>'PRIVATE']);
			}

			$request->merge(['course_member_discount'=>intval($request->input('course_member_discount'))]);

			$request->merge(['course_marking_criteria'=>implode(',', $request->input('course_marking_criteria'))]);
			$request->merge(['course_marking_quiz_threshold'=>intval($request->input('course_marking_quiz_threshold'))]);
			$request->merge(['course_marking_assignment_threshold'=>intval($request->input('course_marking_assignment_threshold'))]);
			$request->merge(['course_marking_combined_threshold'=>intval($request->input('course_marking_combined_threshold'))]);

			$validator = Validator::make($request->all(), [
				'course_name'							=> 'required|max:255',
				'course_slug'							=> 'nullable',
				'course_instructor_id'					=> 'nullable',
				'course_price'							=> 'nullable|regex:/^\d+(\.\d{1,2})?$/',
				'course_ceu_fee'						=> 'nullable|regex:/^\d+(\.\d{1,2})?$/',
				'course_member_discount'				=> 'nullable|integer|between:0,100',
				'course_description'					=> 'nullable',
				'course_category'						=> 'required|max:255',
				'course_duration'						=> 'nullable|integer|between:1,999999',
				'course_status'							=> 'required',
				'course_marking_criteria'				=> 'nullable',
				'course_marking_quiz_threshold'			=> 'nullable',
				'course_marking_assignment_threshold'	=> 'nullable',
				'course_marking_combined_threshold'		=> 'nullable',
				'course_marking_method'					=> 'nullable',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.courses.edit',['course_id'=>$course->course_id])
							->withErrors($validator)
							->withInput();
			}
			else{

				$course->update([
					'course_name'							=> $request->input('course_name'),
					'course_slug'							=> $request->input('course_slug'),
					'course_instructor_id'					=> $request->input('course_instructor_id'),
					'course_price'							=> $request->input('course_price'),
					'course_ceu_fee'						=> $request->input('course_ceu_fee'),
					'course_member_discount'				=> $request->input('course_member_discount'),
					'course_description'					=> $request->input('course_description'),
					'course_category'						=> $request->input('course_category'),
					'course_duration'						=> $request->input('course_duration'),
					'course_status'							=> $request->input('course_status'),
					'course_marking_criteria'				=> $request->input('course_marking_criteria'),
					'course_marking_quiz_threshold'			=> $request->input('course_marking_quiz_threshold'),
					'course_marking_assignment_threshold'	=> $request->input('course_marking_assignment_threshold'),
					'course_marking_combined_threshold'		=> $request->input('course_marking_combined_threshold'),
					'course_marking_method'					=> $request->input('course_marking_method'),
				]);
				
			}

			return redirect()->route('admin.courses.index');
		}

		
	}

	public function destroy($course_id){

		Course::destroy($course_id);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted course.',
		]);
	}
	
	public function destroyMany(Request $request){

		$ids = explode(",",$request->input('ids'));

		Course::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted courses.',
		]);
	}

	public function showCover(Request $request,$course_id){
	
	
	    if(Storage::exists('course/'.$course_id.'/cover/1.jpg')){
				
			return response()->file(storage_path('app/course/'.$course_id.'/cover/1.jpg'),['Content-Type'=>'image/jpeg']);
		
		}
		else{
		
			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}
	    
	    
    }




	public function uploadCover(Request $request,$course_id){
		
		if($this->hasPermission()){

			$response = $request->input('cover-file');
		
			$response = json_decode($response, true);
			
			$field =  $response['output']['field'];
			
			if (request()->hasFile($field)) {
				
				$file = request()->file($field)->storeAs(
					'course/'.$course_id.'/cover', '1.jpg'
				);
				
				return response()->json([
					'status' => 'success',
					'name' => $course_id.'.jpg',
					'path' => $file
				]);
				
			}
		}

		

        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);
		

	}
	
	public function removeCover(Request $request,$course_id){
		
		if($this->hasPermission()){
			
			if(Storage::exists('course/'.$course_id.'/cover/1.jpg')){
					
				Storage::delete('course/'.$course_id.'/cover/1.jpg');

				return response()->json([
			    'status' => 'success',
			    'name' => $course_id.'.jpg'
				]);
			
			}
			else{
				
				return response()->json([
			    'status' => 'failure',
			    'message' => 'Cover does not exist'
				]);
			}

		}
		else{
			
			return response()->json([
			    'status' => 'failure',
			    'message' => 'You do not have permission to delete this cover'
			]);
		}
	}

	public function students(Request $request,$course_id){

		$course = Course::find($course_id);

		if($course != null){


			$enrollments = $course->enrollments;

			return view('backend.courses.enrollments.index')
				->with('course',$course)
				->with('enrollments',$enrollments);
		}


	}


	public function students_edit(Request $request,$course_id,$enrollment_id){

		$enrollment = Enrollment::find($enrollment_id);
		$course = Course::find($course_id);

		if($enrollment != null && $course != null && $enrollment->enrollment_course_id == $course_id){

			$enrollment_student_id = $enrollment->enrollment_student_id;

			$logs_quiz = LogQuiz::select()
			->where('log_student_id',$enrollment_student_id)
			->join('sections', function ($join) use ($course_id) {
				$join->on('sections.section_id', 'logs_quiz.log_test_section_id')
						->join('modules',function($join) use ($course_id) {
						$join->on('modules.module_id','sections.section_module_id')
								->where('modules.module_course_id',$course_id);
					});
			}) 
			->get();

			$logs_assignment = LogAssignment::select()
			->where('log_student_id',$enrollment_student_id)
			->where('assignment_status','COMPLETE')
			->whereNotNull('assignment_score')
			->join('sections', function ($join) use ($course_id)  {
				$join->on('sections.section_id', 'logs_assignment.log_assignment_section_id')
						->join('modules',function($join) use ($course_id) {
						$join->on('modules.module_id','sections.section_module_id')
								->where('modules.module_course_id',$course_id);
					});
			}) 
			->get();
			
			return view('backend.courses.enrollments.edit')
				->with('enrollment',$enrollment)
				->with('logs_quiz',$logs_quiz)
				->with('logs_assignment',$logs_assignment);
		}


	}


	
}