<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Student;
use App\Models\Order;
use App\Models\Enrollment;
use App\Models\Module;
use App\Models\Section;
use App\Models\Course;
use App\Models\LogQuiz;
use App\Models\Discussion;
use App\Models\PrivateDiscussion;
use App\Models\Comment;
use App\Models\Reply;
use App\Models\Message;
use Carbon\Carbon;
use Helpers;

class MessageController extends Controller
{
    //
    public function __construct()
    {
        
    }

    public function index(Request $request)
    {
        
        $unread_messages = Helpers::getPortalNotifications('NO');
        $read_messages = Helpers::getPortalNotifications('YES');

        return view('backend.communication.messages')
                ->with('unread_messages',$unread_messages)
                ->with('read_messages',$read_messages);
    }

    public function edit(Request $request,$message_id){

        $message = Message::find($message_id);

        if($message!=null){
            if($message->message_read == 'NO'){
                $message->message_read = 'YES';
                $message->save();
            }

            if(Auth::check() && $message->message_to_type=='USER' && Auth::user()->id==$message->message_to_id){
                return view('backend.communication.message')
                ->with('message',$message);
            }
            
        }

        

    }

    public function destroy(Request $request,$message_id){

        $message = Message::find($message_id);

        if($message!=null){
           
            if((Auth::check() && Auth::user()->isAdmin()) || (Auth::check() && $message->message_to_type=='USER' && Auth::user()->id==$message->message_to_id) || (Auth::guard('student')->check() && $message->message_to_type=='STUDENT' && Auth::guard('student')->user()->student_id==$message->message_to_id)){

				$message->delete();


                return redirect()->route('admin.messages')
                    ->with('message','A message has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this message!');

			}

            
            
        }


    }

    public function student_index(Request $request)
    {

        if(Auth::check()){
            return redirect()->route('admin.messages');
        }

        $messages = Helpers::getPortalNotifications();

        return view('frontend.courses.discussions.messages')
                ->with('messages',$messages);
    }


    public function student_edit(Request $request,$message_id){

        $message = Message::find($message_id);

        if($message!=null){

            if(Auth::check()){
                return redirect()->route('admin.messages.edit',['message_id'=>$message_id]);
            }

            if($message->message_read == 'NO'){
                $message->message_read = 'YES';
                $message->save();
            }
            
            if(Auth::guard('student')->check() && $message->message_to_type=='STUDENT' && Auth::guard('student')->user()->student_id==$message->message_to_id){
                return view('frontend.courses.discussions.message')
                ->with('message',$message);
            }

            
        }

        

    }

    public function student_destroy(Request $request,$message_id){

        $message = Message::find($message_id);

        if($message!=null){
           
            if((Auth::check() && Auth::user()->isAdmin()) || (Auth::check() && $message->message_to_type=='USER' && Auth::user()->id==$message->message_to_id) || (Auth::guard('student')->check() && $message->message_to_type=='STUDENT' && Auth::guard('student')->user()->student_id==$message->message_to_id)){

				$message->delete();


                return redirect()->route('student.messages')
                    ->with('message','A message has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this message!');

			}

            
            
        }


    }



    
    
}
