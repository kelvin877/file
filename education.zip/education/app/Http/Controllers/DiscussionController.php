<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Enrollment;
use App\Models\Order;
use App\Models\Student;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use App\Models\SectionFile;
use App\Models\Test;
use App\Models\Discussion;
use App\Models\Comment;
use Carbon\Carbon;

class DiscussionController extends Controller
{
    //
    public function __construct()
    {
        
        
    }

    public function index(Request $request,$course_slug){

		$course = Course::where('course_slug',$course_slug)->first();

		

		if($course!=null){

			$modules = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->orderBy('module_position')->get();

			$discussions = $course->discussions()->orderBy('created_at','desc')->paginate(20);
			//  $discussions = $course->discussions()->orderBy('created_at','desc')->paginate(25);  // set to 100 on April 27, 2023


			return view('frontend.courses.discussions.index')
					->with('course',$course)
					->with('course_slug',$course_slug)
					->with('modules',$modules)
					->with('discussions',$discussions);
		}

		
	}

	public function create(){



	}

	public function store(Request $request,$course_slug){

		$course = Course::where('course_slug',$course_slug)->first();

		if($course!=null){


			$request->merge(['discussion_course_id'=>$course->course_id]);

			if(Auth::guard('student')->check()){
				$request->merge(['discussion_student_id'=>Auth::guard('student')->user()->student_id]);
			}
			elseif(Auth::check()){
				$request->merge(['discussion_user_id'=>Auth::user()->id]);
			}
			
			$validator = Validator::make($request->all(), [
				'discussion_title'          	=> 'required',
				'discussion_course_id'			=> 'required',
        		'discussion_student_id'			=> '',
        		'discussion_user_id'			=> ''
			]);
	
			if ($validator->fails()) {
				return redirect()->route('courses.discussion',['course_slug'=>$course_slug])
							->withErrors($validator)
							->withInput();
			}
			else{

				$discussion_tags = $request->has('discussion_tags')&&$request->input('discussion_tags')!=null&&is_array($request->input('discussion_tags'))?implode(' | ',$request->input('discussion_tags')):null;
				
				if($discussion_tags!=null){
					$request->merge(['discussion_title'=>'[ '.$discussion_tags.' ] '.$request->input('discussion_title')]);
				}
				
				$discussion = Discussion::create($request->all());
				
	
				
				return redirect()->route('courses.discussion',['course_slug'=>$course_slug])->with('message','A new topic has been created!');
			}

		}

	}

	public function discussionComments(Request $request,$course_slug,$discussion_id){

		$course = Course::where('course_slug',$course_slug)->first();

		
		$discussion = Discussion::find($discussion_id);
		

		if($course!=null && $discussion!=null && $course->course_id==$discussion->course->course_id){

			

			$comments = $discussion->comments()->orderBy('created_at','desc')->get();

			if(Route::currentRouteName()=='courses.discussion.public.comments'){

				$enrollment = $discussion->student->enrollments()
				->where('enrollment_course_id',$course->course_id)
				->where(function ($query) {
					$query->where('enrollment_status','IN_PROGRESS')
						->orWhere('enrollment_status','COMPLETE');
				})
				->orderBy('updated_at','desc')->get()->first();

				return view('frontend.courses.discussions.comments')
						->with('enrollment',$enrollment)
						->with('course',$course)
						->with('course_slug',$course_slug)
						->with('discussion',$discussion)
						->with('comments',$comments);

			}

			return view('frontend.courses.discussions.comments')
						->with('course',$course)
						->with('course_slug',$course_slug)
						->with('discussion',$discussion)
						->with('comments',$comments);

			
		}

	}

	public function commentStore(Request $request,$course_slug,$discussion_id){

		$course = Course::where('course_slug',$course_slug)->first();

		$discussion = Discussion::find($discussion_id);

		if($course!=null && $discussion!=null && $course->course_id==$discussion->course->course_id){
			
			$request->merge(['comment_discussion_id'=>$discussion_id]);

			if(Auth::guard('student')->check()){
				$request->merge(['comment_student_id'=>Auth::guard('student')->user()->student_id]);
			}
			elseif(Auth::check()){
				$request->merge(['comment_user_id'=>Auth::user()->id]);
			}



			
			$validator = Validator::make($request->all(), [
				'comment_content'          	=> 'required',
				'comment_discussion_id'		=> 'required',
        		'comment_student_id'		=> '',
        		'comment_user_id'			=> ''
			]);
	
			if ($validator->fails()) {

				if(Route::currentRouteName()=='courses.discussion.public.comment.post'){
					return redirect()->route('courses.discussion.public.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])
					->withErrors($validator)
					->withInput();
				}


				return redirect()->route('courses.discussion.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])
							->withErrors($validator)
							->withInput();
			}
			else{


				if($request->has('quote_value') && $request->input('quote_value')!='' && $request->input('quote_value')!=null){


					$cid = intval($request->input('quote_value'));
	
					$comment = Comment::find($cid);
	
					if($comment!=null){
	
	
						$quote = '<blockquote><p>'.$comment->account->getFullName().' ['.$comment->created_at.'] </p>'.$comment->comment_content.'</blockquote><br/><br/>';
						$request->merge(['comment_content'=>$quote.$request->input('comment_content')]);
	
						
					}
				}
				
				
				Comment::create($request->all());


				$css = '<style>hr{border-top: 1px dashed #8c8b8b;border-bottom: 1px dashed #fff;}blockquote{margin: 1em 0;background: #eee;padding: 1em;border-radius: 1em;}</style>';


				if($discussion->discussion_user_id!=null){

					$user = $discussion->account;
					$email = $user->getEmail();
					$lead = 'Hi '.$user->getFullName().',';
					$content = '<p>Your topic from course ['.$course->course_name.'] has a new comment.</p>';
					$content .= '<p>&nbsp;</p><hr/><p>'.$request->input('comment_content').'</p><hr/><p>&nbsp;</p>';
					$content .= '<p>Regards,<br/>ICAA Education</p>';
					$content = $css.$content;
					$subject = 'Your topic has a new comment.';


					try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
		
					} catch(\Exception $e) {

					}

				}
				elseif($discussion->discussion_student_id!=null){


					$student = $discussion->account;
					$email = $student->getEmail();
					$lead = 'Hi '.$student->getFullName().',';
					$content = '<p>Your topic from course ['.$course->course_name.'] has a new comment.</p>';
					$content .= '<p>&nbsp;</p><hr/><p>'.$request->input('comment_content').'</p><hr/><p>&nbsp;</p>';
					$content .= '<p>Regards,<br/>ICAA Education</p>';
					$content = $css.$content;
					$subject = 'Your topic has a new comment.';
	
					try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
		
					} catch(\Exception $e) {

						
					}

					
				}


				
				if(Route::currentRouteName()=='courses.discussion.public.comment.post'){
					return redirect()->route('courses.discussion.public.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])->with('message','A new comment has been created!');
				}
				
	
				
				return redirect()->route('courses.discussion.comments',['course_slug'=>$course_slug,'discussion_id'=>$discussion_id])->with('message','A new comment has been created!');
			}



		}

	}

	public function getComment(Request $request,$comment_id){

		$comment = Comment::find($comment_id);


		if($comment!=null){


			return response()->json([
				'status' => 'success',
				'content' => view('frontend.courses.blocks.comment-block')->with('comment',$comment)->render(),
			]);



		}

	}

	public function show(Request $request,$discussion_id){

	}

	public function edit(Request $request,$discussion_id){
		

	}

	public function update(Request $request,$discussion_id){


		
	}


	public function destroy(Request $request,$discussion_id){


		$discussion = Discussion::find($discussion_id);

		if($discussion!=null){

			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$discussion->discussion_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$discussion->course->course_instructor_id)){

				$discussion->delete();

				return back()
					->with('message','A discussion topic has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this topic!');

			}

			

			

		}		


		return back()
				->with('error','Fail to remove this topic!');



	}

	public function commentDestroy(Request $request,$comment_id){


		

		$comment = Comment::find($comment_id);

		if($comment!=null){


			if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$comment->comment_student_id) || (Auth::check() && Auth::user()->isInstructor() && Auth::user()->id==$comment->discussion->course->course_instructor_id)){

				$comment->delete();

				return back()
					->with('message','A comment has been removed!');

			}
			else{
				return back()
				->with('error','You do not have permission to remove this comment!');

			}


		}		

		return back()
				->with('error','Fail to remove this comment!');


	}
	




}
