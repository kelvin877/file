<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\Role;
use App\Models\User;
use App\Models\Course;
use App\Models\Module;
use App\Models\Section;
use App\Models\Test;
use App\Models\LogQuiz;
use Carbon\Carbon;
use Helpers;

class TestController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => []]);

    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}



	public function index(Request $request,$section_id){


	}

	public function create(){


	}

	public function store(Request $request,$course_id,$module_id,$section_id){


		if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
			$request->merge(['test_status'=>'PUBLIC']);
		}
		else{
			$request->merge(['test_status'=>'PRIVATE']);
		}

		$request->merge(['test_section_id'=>$section_id]);


		$max_position = Test::where('test_section_id', $section_id)->max('test_position');

		if($max_position == null){
			$max_position = 0;
		}

		$request->merge(['test_position'=>$max_position+1]);


		$validator = Validator::make($request->all(), [
			'test_question'				=> 'required|max:255',
			'test_section_id'			=> 'required',
			'test_status'				=> 'required',
			'test_type'					=> 'required',
			'test_position'				=> 'required',
		]);

		if ($validator->fails()) {

			return response()->json([
				'status' => 'failure',
				'errors' => $validator
				]);
        }
		else{

			$test = Test::create([
				'test_question'				=> $request->input('test_question'),
				'test_section_id'			=> $request->input('test_section_id'),
				'test_status'				=> $request->input('test_status'),
				'test_type'					=> $request->input('test_type'),
				'test_position'				=> $request->input('test_position'),
			]);


			$tests = Test::where('test_section_id',$section_id)->orderBy('test_position')->get();
			$response = '';

			foreach($tests as $question){
				$response .= view('backend.courses.blocks.question',['question' => $question])->render();
			}


			return response()->json([
			    'status' => 'success',
			    'response' => $response
				]);
		}
	}

	public function show($module_id){

	}

	public function edit($course_id,$module_id,$section_id,$test_id){


	}

	public function update(Request $request,$course_id,$module_id,$section_id,$test_id){


		$test = Test::find($test_id);

		if($test != null){

			if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
				$request->merge(['test_status'=>'PUBLIC']);
			}
			else{
				$request->merge(['test_status'=>'PRIVATE']);
			}

			if($request->has('test_options') && is_array($request->input('test_options')) ){
				$request->merge(['test_options'=>$request->input('test_options')]);
			}
			else{
				$request->merge(['test_options'=>array()]);
			}

			$validator = Validator::make($request->all(), [
				'test_question'				=> 'required|max:255',
				'test_options'				=> 'required',
				'test_status'				=> 'required',
				'test_type'					=> 'required',
			]);

			if ($validator->fails()) {

				return '';
			}
			else{

				$test->update([
					'test_question'			=> $request->input('test_question'),
					'test_options'			=> $request->input('test_options'),
					'test_status'			=> $request->input('test_status'),
					'test_type'				=> $request->input('test_type'),
				]);

			}

			return '';
		}


	}

	public function destroy(Request $request,$test_id){

		$test = Test::find($test_id);

		if($test!=null){

			$section_id = $test->test_section_id;

			Test::destroy($test_id);

			$tests = Test::where('test_section_id',$section_id)->orderBy('test_position')->get();
			$response = '';

			foreach($tests as $question){
				$response .= view('backend.courses.blocks.question',['question' => $question])->render();
			}

			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted test.',
				'response' => $response
			]);
		}

	}



	public function updatePositions(Request $request,$section_id){

		$ids = explode(',',$request->input('ids'));

		if(count($ids)>0){
			$count = 0;
			foreach($ids as $index=>$id){
				$test = Test::find($id);
				if($test!=null && $test->test_section_id==$section_id){
					$count++;
					$test->test_position = $count;
					$test->save();
				}

			}
		}

		$tests = Test::where('test_section_id',$section_id)->orderBy('test_position')->get();
		$response = '';

		foreach($tests as $question){
			$response .= view('backend.courses.blocks.question',['question' => $question])->render();
		}


		return response()->json([
			'status' => 'success',
			'response' => $response
		]);


	}


	public function updateOptions(Request $request,$test_id){


		$test = Test::find($test_id);

		if($test!=null){

			$test_options = json_decode($request->input('test_options'));
			$test->test_options = $test_options;
			$test->save();
		}

		$response = '';

		foreach($test->test_options as $index=>$option){
			$response .= view('backend.courses.blocks.question-option',['option' => $option,'index' => $index,'test_id'=>$test->test_id])->render();
		}

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);


	}

	public function getQuestionTemplate(Request $request){

		$response = view('backend.courses.blocks.question')->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);
	}


	public function resetTest(Request $request,$log_id){

		$log_quiz = LogQuiz::find($log_id);

		if($log_quiz!=null){

			$course = $log_quiz->section->module->course;
			$course_id = $course->course_id;
			$student_id = $log_quiz->log_student_id;

			//$log_quiz->delete();

      $log_quiz->is_retake = 'Y';
      $log_quiz->save();

			Helpers::setStudentCourseStat($student_id,$course_id);

			$logs_quiz = LogQuiz::select()
			->where('log_student_id',$student_id)
			->join('sections', function ($join) use ($course_id) {
				$join->on('sections.section_id', 'logs_quiz.log_test_section_id')
						->join('modules',function($join) use ($course_id) {
						$join->on('modules.module_id','sections.section_module_id')
								->where('modules.module_course_id',$course_id);
					});
			})
			->get();

			$response = '';

			foreach($logs_quiz as $log_quiz){
				$response .= view('backend.courses.blocks.score-quiz',['log_quiz' => $log_quiz])->render();
			}

			return response()->json([
				'status' 	=> 'success',
				'message'	=> 'Assignment has been reset',
				'response' 	=> $response
			]);

		}

	}

}
