<?php


namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\PayPal as PayPalClient;

use Illuminate\Support\Facades\Mail;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Enrollment;
use App\Models\Order;
use App\Models\Student;
use App\Models\Course;
use Carbon\Carbon;

class PayPalPaymentController extends Controller
{
    public function handlePayment(Request $request,$order_id)
    {

		$order = Order::find($order_id);

		if($order!=null && $order->order_status == 'PENDING'){

			$provider = new PayPalClient;

			$provider = \PayPal::setProvider();
			$provider->setApiCredentials(config('paypal'));
			$provider->setAccessToken($provider->getAccessToken());

			$order_paypal = $provider->createOrder([
				"intent"=> "CAPTURE",
				"purchase_units"=> [
					0 => [
						"reference_id" => 'Order#: '. $order_id,
						"amount"=> [
							"currency_code"=> "USD",
							"value"=> $order->order_subtotal
						]
					]
				],
				'application_context' => [
					'cancel_url' => route('payment.cancel'),
					'return_url' => route('payment.success'),
				]
			]);

			$order->order_paypal_token = $order_paypal['id'];
			$order->save();

			return redirect($order_paypal['links'][1]['href'])->send();

		}

	
    }
   
    public function paymentCancel(Request $request)
    {
		if($request->has('token')){

			$token = $request->input('token');

			$order = Order::where('order_paypal_token',$token)->first();

			if($order!=null){

				$order->delete();

				return redirect()->route('student.dashboard')->with('error','Your payment has been declined.');
			}
		}


		return redirect()->route('student.dashboard')->with('error','Payment error!');

		
    }
  
    public function paymentSuccess(Request $request)
    {

		if($request->has('token') && $request->has('PayerID')){
			
			$token = $request->input('token');
			$PayerID = $request->input('PayerID');

			$order = Order::where('order_paypal_token',$token)->first();


			


			if($order!=null){

				$provider = new PayPalClient;

				$provider = \PayPal::setProvider();
				$provider->setApiCredentials(config('paypal'));
				$provider->setAccessToken($provider->getAccessToken());

				$paypal = $provider->capturePaymentOrder($token);

				if($paypal['status']=='COMPLETED'){
					
					$order->order_paypal_token = null;
					$order->order_paypal_paid_date = Carbon::now();
					$order->order_paypal_notes = 'token='.$token.'&PayerID='.$PayerID;
					$order->order_status = 'PAID';
					$order->save();


					$email = config('setting.admin_email');
					$lead = 'Dear '.config('setting.admin_name').',';
					$content = '<p>You got a new course approval request from ICAA Education.</p>';
					$content .= '<p>The ICAA Education team</p>';
					$subject = 'You got a new course approval request from ICAA Education';
					
			
					try {
			
						Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));
			
					} catch(\Exception $e) {
			
			
					}

					return redirect()->route('student.dashboard')->with('message','Payment Confirmed!');
				}

				
				return redirect()->route('student.dashboard')->with('error','Payment error!');
				
			}
		}



    }
}
