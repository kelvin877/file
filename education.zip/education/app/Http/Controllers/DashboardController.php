<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Student;
use App\Models\Order;
use App\Models\Enrollment;
use App\Models\Module;
use App\Models\Section;
use App\Models\Course;
use App\Models\LogQuiz;
use Carbon\Carbon;
use Helpers;

class DashboardController extends Controller
{
    //
    public function __construct()
    {
        
        $this->middleware('auth.admin',['except' => []]);
    }

    public function index(){

        // return view('frontend.pages.index');

        if(Auth::check()){
            return redirect()->route('admin.dashboard');
        }
        return view('backend.login');
    }

    public function dashboard(){


        if(Auth::user()->getRole()=='Administrator'){

            $total_lifetime = Order::where('order_status','PAID')->sum('order_amount');

            $total_this_month = Order::whereMonth('created_at', '=', Carbon::now()->month)->where('order_status','PAID')->sum('order_amount');

            $student_count_this_month = Student::whereMonth('created_at', '=', Carbon::now()->month)->count();


            $history = Order::selectRaw('year(created_at) year, month(created_at) month, sum(order_amount) data')
                    ->where('created_at', '>', (new \Carbon\Carbon)->submonths(12) )
                    ->where('order_status','PAID')
                    ->groupBy('year', 'month')
                    ->orderBy('year')
                    ->get();
            
            $top_course = Enrollment::selectRaw('enrollment_course_id course_id, count(*) count')
                        ->groupBy('course_id')
                        ->orderBy('count','desc')
                        ->limit(1)
                        ->first();

            if($top_course==null){

                $top_course = Course::all()->first();
            }



            $course = Course::find($top_course->course_id);

            $history_chart_label = [];
            $history_chart_data = [];

            for ($i = 11; $i >= 0; $i--){
                // $months[] = date("Y-n", strtotime("-$i months"));
                // $history_chart[date("Y", strtotime("-$i months"))][date("n", strtotime("-$i months"))] = ['label'=>date("Y-M", strtotime("-$i months")),'count'=>'0.00'];
                $history_chart_label[] = date("M", strtotime("-$i months"));
                
                $contains = $history->search(function ($item, $key) use ($i) {
                    return $item->year == intval(date("Y", strtotime("-$i months"))) && $item->month == intval(date("n", strtotime("-$i months")));
                });

                if($contains!==false){
                    $history_chart_data[] = $history[$contains]['data'];
                }else{
                    $history_chart_data[] = '0.00';
                }

            }


            return view('backend.dashboard.index')
                    ->with('total_lifetime',$total_lifetime)
                    ->with('total_this_month',$total_this_month)
                    ->with('student_count_this_month',$student_count_this_month)
                    ->with('history_chart_label',$history_chart_label)
                    ->with('history_chart_data',$history_chart_data)
                    ->with('course',$course);

        }
        elseif(Auth::user()->getRole()=='Instructor'){


            $messages = Helpers::getPortalNotifications('NO');
            
            return view('backend.dashboard.instructor')
                    ->with('messages',$messages);
        }

        
    }

    public function sys(){

        return Helpers::getPortalNotifications();
    }

    public function migrate(){

        return Helpers::setCourseStatFull();

        
    }
    
    
}
