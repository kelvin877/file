<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Enrollment;
use App\Models\Order;
use App\Models\Student;
use App\Models\Course;
use App\Models\Evaluation;
use App\Models\Question;
use App\Models\Response;
use Carbon\Carbon;
use PDF;
use Helpers;

class EvaluationController extends Controller
{

    public function __construct()
    {
        
    }

    public function show(Request $request,$course_id,$evaluation_id){

        $evaluation = Evaluation::find($evaluation_id);

		if($evaluation!=null && $evaluation->evaluation_status=='PUBLIC' && $evaluation->evaluation_course_id==$course_id){

            $course = $evaluation->course;

			if(Auth::guard('student')->check()){
				$enrollment = Enrollment::where('enrollment_student_id',Auth::guard('student')->user()->student_id)
				->where('enrollment_course_id',$course_id)
				// ->where('enrollment_status','IN_PROGRESS')
				->orderBy('created_at','DESC')
				->first();

				if($enrollment!=null && $enrollment->response!=null){
					
					
					//check if the course is passed and ready to generate certificate, added by Mandy on Dec 22, 2022
					$enrollment1 = Enrollment::where('enrollment_student_id',Auth::guard('student')->user()->student_id)
					->where('enrollment_course_id',$course_id)
					->where('enrollment_status','IN_PROGRESS')
					->orderBy('created_at','DESC')
					->first();
					if($enrollment1->enrollment_status=='IN_PROGRESS' && Helpers::checkPassOrFail($enrollment1->enrollment_id)){
						$email = config('setting.admin_email');
						$lead = 'Dear '.config('setting.admin_name').',';
						$content = '<p>You got a student just completed and passed the course. Thank you!</p>';
						$content .= '<p>The ICAA Education team</p>';
						$subject = 'You got a student just completed the evaluation';										
						try {				
							Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));
							//Mail::to($email)->send(new SystemEmail($lead,$content,$subject));							
						} catch(\Exception $e) {								
						}
					}



					return view('frontend.courses.complete')
							->with('course',$course);
				}
			}

			

            return view('frontend.courses.evaluation')
				->with('course',$course)
				->with('evaluation',$evaluation);
            
        }

        return abort(404);

    }



    public function post(Request $request,$course_id,$evaluation_id){

        $evaluation = Evaluation::find($evaluation_id);

		if($evaluation!=null && $evaluation->evaluation_course_id==$course_id){

            $course = $evaluation->course;

            $evaluation_response = array();

            $enrollment = Enrollment::where('enrollment_student_id',Auth::guard('student')->user()->student_id)
            ->where('enrollment_course_id',$course_id)
            ->where('enrollment_status','IN_PROGRESS')
            ->orderBy('created_at','DESC')
            ->first();


            if($enrollment!=null){

                if($request->has('evaluation')){
                    $evaluation_response = $request->input('evaluation');
                }

                if($enrollment->response!=null){

                    return redirect()->route('student.dashboard')
                    ->with('error','You have already submitted an evaluation form before.');

                }
                else{

                    $response = Response::create([
                        'response_evaluation_id'    => $evaluation_id,
                        'response_enrollment_id'    => $enrollment->enrollment_id,
                        'response_content'		    => $evaluation_response,
                    ]);
                }
    
    
            }else{

                return redirect()->route('student.dashboard')
                ->with('error','You can not submit an evaluation form after graduation.');

            }


			$email = config('setting.admin_email');
			$lead = 'Dear '.config('setting.admin_name').',';
			$content = '<p>You got a student just completed the evaluation. Thank you!</p>';
			$content .= '<p>The ICAA Education team</p>';
			$subject = 'You got a student just completed the evaluation';
			
	
			try {
	
				Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));
	
			} catch(\Exception $e) {
	
	
			}

            
            return redirect()->route('student.dashboard')
                    ->with('message','Thank you for your feedback.');
        
            
        }

        return abort(404);

    }


    //
    public function store(Request $request,$course_id){

        $course = Course::find($course_id);

        if($course!=null){

            $evaluation = $course->evaluation;

            if($evaluation==null){

                if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
                    $request->merge(['evaluation_status'=>'PUBLIC']);
                }
                else{
                    $request->merge(['evaluation_status'=>'PRIVATE']);
                }
        
                $request->merge(['evaluation_course_id'=>$course_id]);
        
        
                $validator = Validator::make($request->all(), [
                    'evaluation_name'		    => 'required|max:255',
                ]);
        
                if ($validator->fails()) {
        
                    return response()->json([
                        'status' => 'failure',
                        'errors' => $validator
                        ]);
                }
                else{
                    
                    $evaluation = Evaluation::create([
                        'evaluation_name'				=> $request->input('evaluation_name'),
                        'evaluation_course_id'		    => $request->input('evaluation_course_id'),
                        'evaluation_status'		        => $request->input('evaluation_status'),
                    ]);
        
        
        
                    $response = view('backend.courses.blocks.evaluation',['evaluation' => $evaluation])->render();
                    
                    
                    return response()->json([
                        'status' => 'success',
                        'response' => $response
                        ]);
                }

            }
            else{
                return response()->json([
                    'status' => 'failure',
                    'message' => 'Not able to create evaluation form'
                    ]);
            }

        }


		
	}


    public function edit(Request $request,$course_id,$evaluation_id){
		
		$evaluation = Evaluation::find($evaluation_id);


		if($evaluation != null){

			$course = $evaluation->course;


			return view('backend.courses.evaluation.edit')
				->with('course',$course)
				->with('evaluation',$evaluation);
		}
	}

	public function update(Request $request,$course_id,$evaluation_id){

		$evaluation = Evaluation::find($evaluation_id);

		if($evaluation != null){

            $course = $evaluation->course;

			if($request->has('published-toggle')&&$request->input('published-toggle')=='PUBLIC'){
				$request->merge(['evaluation_status'=>'PUBLIC']);
			}
			else{
				$request->merge(['evaluation_status'=>'PRIVATE']);
			}

			$validator = Validator::make($request->all(), [
				'evaluation_name'				=> 'required|max:255',
				'evaluation_description'		=> 'nullable',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.evaluations.update',['course_id'=>$course->course_id,'evaluation_id'=>$evaluation->evaluation_id])
							->withErrors($validator)
							->withInput();
			}
			else{

				$evaluation->update([
					'evaluation_name'			=> $request->input('evaluation_name'),
					'evaluation_description'	=> $request->input('evaluation_description'),
					'evaluation_status'		    => $request->input('evaluation_status'),
				]);
				
			}

			return redirect()->route('admin.courses.edit',['course_id'=>$course->course_id]);
		}

		
	}


    public function destroy($course_id,$evaluation_id){

		$evaluation = Evaluation::find($evaluation_id);

		if($evaluation!=null && $evaluation->evaluation_course_id==$course_id){

			Evaluation::destroy($evaluation_id);
	
			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted evaluation form.'
			]);
		}

		return response()->json([
			'status' => 'failure',
			'message' => 'Cannot delete evaluation form.'
		]);

		
	}
	
	public function destroyMany(Request $request){

		$ids = explode(",",$request->input('ids'));

		Evaluation::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted evaluation forms.'
		]);
	}


    public function storeQuestion(Request $request,$course_id,$evaluation_id){


		$request->merge(['question_evaluation_id'=>$evaluation_id]);


		$max_position = Question::where('question_evaluation_id', $evaluation_id)->max('question_position');

		if($max_position == null){
			$max_position = 0;
		}

		$request->merge(['question_position'=>$max_position+1]);


		$validator = Validator::make($request->all(), [
            'question_evaluation_id'=> 'required',
			'question_name'	    => 'required',
			'question_type'			=> 'required',
			'question_position'	    => 'required',
		]);

		if ($validator->fails()) {

			return response()->json([
				'status' => 'failure',
				'errors' => $validator
				]);
        }
		else{
			
			$question = Question::create([
				'question_evaluation_id'	=> $request->input('question_evaluation_id'),
				'question_name'	    => $request->input('question_name'),
				'question_type'			=> $request->input('question_type'),
				'question_position'	    => $request->input('question_position'),
			]);


			$questions = Question::where('question_evaluation_id',$evaluation_id)->orderBy('question_position')->get();
			$response = '';

			foreach($questions as $question){
				$response .= view('backend.courses.blocks.evaluation-question',['question' => $question])->render();
			}
		
			
			return response()->json([
			    'status' => 'success',
			    'response' => $response
				]);
		}

    }


    public function updateQuestionOptions(Request $request,$question_id){


        $question = Question::find($question_id);

		if($question!=null){

			$question_options = json_decode($request->input('question_options'));
			$question->question_options = $question_options;
			$question->save();
		}

		$response = '';

		foreach($question->question_options as $index=>$option){
			$response .= view('backend.courses.blocks.evaluation-question-option',['option' => $option,'index' => $index,'question_id'=>$question->question_id])->render();
		}
		
		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

    }

    public function updateQuestionPositions(Request $request,$evaluation_id){

        $ids = explode(',',$request->input('ids'));

		if(count($ids)>0){
			$count = 0;
			foreach($ids as $index=>$id){
				$question = Question::find($id);
				if($question!=null && $question->question_evaluation_id==$evaluation_id){
					$count++;
					$question->question_position = $count;
					$question->save();
				}

			}
		}

		$questions = Question::where('question_evaluation_id',$evaluation_id)->orderBy('question_position')->get();
		$response = '';

		foreach($questions as $question){
			$response .= view('backend.courses.blocks.evaluation-question',['question' => $question])->render();
		}
	
		
		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

    }

    public function destroyQuestion(Request $request,$question_id){

        $question = Question::find($question_id);

		if($question!=null){

			$evaluation_id = $question->question_evaluation_id;

			Question::destroy($question_id);
	
			$questions = Question::where('question_evaluation_id',$evaluation_id)->orderBy('question_position')->get();
			$response = '';
	
			foreach($questions as $question){
				$response .= view('backend.courses.blocks.evaluation-question',['question' => $question])->render();
			}
	
			return response()->json([
				'status' => 'success',
				'message' => 'Successfully deleted test.',
				'response' => $response
			]);
		}

    }


	public function responses(Request $request){

		$responses = Response::whereNotNull('response_content')->orderBy('created_at','desc')->paginate(10);

		if($responses!=null){

			return view('backend.enrollment.evaluation.index')
				->with('responses',$responses);
		}



	}

	public function responses_edit(Request $request,$response_id){

		$response = Response::find($response_id);

		if($response!=null){

			return view('backend.enrollment.evaluation.edit')
				->with('response',$response);
		}

	}

	public function destroyManyResponses(Request $request){


		$ids = explode(",",$request->input('ids'));

		Response::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted responses.',
		]);

	}



}
