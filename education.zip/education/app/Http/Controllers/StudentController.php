<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Mail\SystemEmail;
use App\Models\Role;
use App\Models\User;
use App\Models\Student;
use App\Models\Order;
use App\Models\Enrollment;
use App\Models\Module;
use App\Models\Section;
use App\Models\Course;
use App\Models\Assignment;
use App\Models\LogQuiz;
use App\Models\LogView;
use App\Models\LogAssignment;
use Carbon\Carbon;
use App\Imports\StudentsImport;
use App\Exports\StudentsExport;
use Excel;
use PDF;
use Helpers;
use Image;

class StudentController extends Controller
{
    //
    public function __construct()
    {


    }

    public function index(){

        $students = Student::paginate(10);

		return view('backend.students.index')
				->with('students',$students);
    }


    public function dashboard2(){

        $courses = Course::where('course_status','PUBLIC')->get();

        $orders = null;

        if(Auth::guard('student')->check()){
            $orders = Auth::guard('student')->user()->enrollments()->with('order')->where('enrollment_status','PENDING')->get()->pluck('order')->where('order_status','PENDING')->where('order_payment_method','PayPal');
        }



		return view('frontend.dashboard.index')
                ->with('courses',$courses)
                ->with('orders',$orders);
    }

    public function dashboard(){


        //return Auth::guard('student')->user()->logViews;

        $courses = Course::where('course_status','PUBLIC')->get();

        $orders = null;

        if(Auth::guard('student')->check()){
            $orders = Auth::guard('student')->user()->enrollments()->with('order')->where('enrollment_status','PENDING')->get()->pluck('order')->where('order_status','PENDING')->where('order_payment_method','PayPal');
        }



		return view('frontend.dashboard.index')
                ->with('courses',$courses)
                ->with('orders',$orders);
    }


    public function checkout(Request $request,$course_id){



        if(in_array($course_id,Auth::guard('student')->user()->enrollments()->pluck('enrollment_course_id')->all())){

            return redirect()->route('student.dashboard')
            ->with('error', 'Checkout error!');
        }
        else{

            $course = Course::find($course_id);

            return view('frontend.registration.checkout')
                ->with('course',$course);
        }


    }

    public function purchase(Request $request,$course_id){


        if($request->input('agree_payment')==null){

            return redirect()->route('student.checkout',['course_id'=>$course_id])
                        ->with('error','Please check the acknowledgement.')
                        ->withInput();
        }


        $course = Course::find($course_id);

        if($course!=null){

            if (Auth::guard('student')->check())
			{

                $enrollment = Enrollment::where('enrollment_course_id',$course_id)->where('enrollment_student_id',Auth::guard('student')->user()->student_id)->get();

                if($enrollment!=null && $enrollment->count()>0){
                    return redirect()->route('student.dashboard')
                    ->with('message', 'This course has already been purchased and is waiting for approval.');
                }

                $amount = floatval($course->course_price);
                $ceu = 'NO';

                if(Auth::guard('student')->user()->is_member=='YES' && $course->course_member_discount!=null){

                    $amount -= round(($course->course_member_discount*$course->course_price)/100,2);
                }

                if($course->course_ceu_fee!=null && $request->input('ceu_amount')=='YES'){

                    $amount += floatval($course->course_ceu_fee);
                    $ceu = 'YES';
                }



                if($amount>0){

                    if($request->input('payment')==null){

                        return redirect()->route('student.checkout',['course_id'=>$course_id])
                                    ->with('error','Please choose your payment method.')
                                    ->withInput();
                    }

                    $order = Order::create([
                        'order_amount'            => $amount,
                        'order_tax'               => 0,
                        'order_subtotal'          => $amount,
                        'order_payment_method'    => $request->input('payment'),
                        'order_status'            => 'PENDING'
                    ]);


                    $enrollment = Enrollment::create([
                        'enrollment_student_id'         => Auth::guard('student')->user()->student_id,
                        'enrollment_course_id'          => $course_id,
                        'enrollment_order_id'           => $order->order_id,
                        'enrollment_status'             => 'PENDING',
                        'enrollment_certificate'        => 'PENDING',
                        'enrollment_ceu'                => $ceu

                    ]);


                    if($request->input('payment')=='PayPal'){

                        return redirect()->route('payment.make',['order_id'=>$order->order_id]);
                    }


                }else{

                    $order = Order::create([
                        'order_amount'            => 0,
                        'order_tax'               => 0,
                        'order_subtotal'          => 0,
                        'order_payment_method'    => 'Free',
                        'order_status'            => 'PAID'
                    ]);


                    $enrollment = Enrollment::create([
                        'enrollment_student_id'         => Auth::guard('student')->user()->student_id,
                        'enrollment_course_id'          => $course_id,
                        'enrollment_order_id'           => $order->order_id,
                        'enrollment_status'             => 'PENDING',
                        'enrollment_certificate'        => 'PENDING',
                        'enrollment_ceu'                => $ceu

                    ]);

                }


                $email = config('setting.admin_email');
                $lead = 'Dear '.config('setting.admin_name').',';
                $content = '<p>You got a new course approval request from ICAA Education.</p>';
                //$content .= '<p><blockquote><b>Name: </b>'.Auth::guard('student')->user()->getFullName().'<br/><b>Email: </b>'.Auth::guard('student')->user()->student_email.'<br/><b>Course: </b>'.$course->course_name.'<br/><b>Payment Method: </b>'.$request->input('payment').'</blockquote></p>';
                $content .= '<p>The ICAA Education team</p>';
                $subject = 'You got a new course approval request from ICAA Education';


                try {

                    Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));

                } catch(\Exception $e) {


                }


                return redirect()->route('student.dashboard')
        		->with('message', 'This course has already been purchased and is waiting for approval. Next step, you will receive an approval email from ICAA Education.');


			}


        }
    }


    public function pay(Request $request,$order_id){


        $order = Order::find($order_id);

        if($order!=null){

            return redirect()->route('payment.make',['order_id'=>$order->order_id]);
        }


    }

    public function order(Request $request,$order_id){

        $order = Order::find($order_id);

        return $order->enrollment;

    }

    public function cancel_order(Request $request,$order_id){

        $order = Order::find($order_id);

        if($order!=null){

            if(Auth::check() || (Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$order->enrollment->enrollment_student_id)){

                $order->delete();

                return back()->with('error','Your payment has been canceled.');


            }
            else{

                return back()->with('error','You do not have permission to cancel this order.');

            }



        }

    }

    public function registration_index(){


        if(Auth::check()){

    		Auth::logout();
    	}


        if(Auth::guard('student')->check()){

    		Auth::guard('student')->logout();
    	}

        $courses = Course::all();

        return view('frontend.registration.index')
                ->with('courses',$courses);

    }



    public function profile_index(){

        $student = null;

        if(Auth::guard('student')->check()){

    		$student = Auth::guard('student')->user();
    	}


        return view('frontend.profile.index')
                ->with('student',$student);

    }


    public function profile_update(Request $request){

        $validator = Validator::make($request->all(), [
			'student_first_name'            => 'required|max:255',
			'student_last_name'             => 'required|max:255',
			'student_title'                 => 'required',
			'student_organization'          => 'required',
			'student_address'               => 'required',
			'student_city'                  => 'required',
			'student_state'                 => 'required',
			'student_country'               => 'required',
            'student_zip'                   => 'required',
            'student_phone'                 => 'required',
            'student_cellphone'             => 'required',
		]);

		if ($validator->fails()) {
            return redirect()->route('student.profile')
                        ->withErrors($validator)
                        ->withInput();
        }
		else{

            if(Auth::guard('student')->check()){

                $student = Auth::guard('student')->user();
                $student->student_first_name = $request->input('student_first_name');
                $student->student_last_name = $request->input('student_last_name');
                $student->student_title = $request->input('student_title');
                $student->student_organization = $request->input('student_organization');
                $student->student_address = $request->input('student_address');
                $student->student_city = $request->input('student_city');
                $student->student_state = $request->input('student_state');
                $student->student_country = $request->input('student_country');
                $student->student_zip = $request->input('student_zip');
                $student->student_phone = $request->input('student_phone');
                $student->student_cellphone = $request->input('student_cellphone');
                $student->student_notes = $request->input('student_notes');
                $student->save();
            }

            return redirect()->route('student.dashboard')
            ->with('message', 'Profile has been changed successfully.');


		}

    }



    public function membership_update(Request $request,$course_id){



        $course = Course::find($course_id);

        if($course!=null){


            if($request->has('student_member_number')&&$request->input('student_member_number')!=''){
                $request->merge(['is_member'=>'YES']);
            }
            else{
                $request->merge(['is_member'=>'NO']);
            }

            $validator = Validator::make($request->all(), [
                'student_member_number'     => 'required|min:4',
            ]);

            if ($validator->fails()) {
                return redirect()->route('student.checkout',['course_id'=>$course_id])
                            ->withErrors($validator)
                            ->withInput();
            }
            else{

                if(Auth::guard('student')->check()){

                    $student = Auth::guard('student')->user();
                    $student->student_member_number = $request->input('student_member_number');
                    $student->is_member = $request->input('is_member');
                    $student->save();
                }

                return redirect()->route('student.checkout',['course_id'=>$course_id])
                ->with('message', 'Membership information has been changed successfully.');


            }


        }



    }



    public function password_index(){

        $student = null;

        if(Auth::guard('student')->check()){

    		$student = Auth::guard('student')->user();
    	}


        return view('frontend.profile.password')
                ->with('student',$student);

    }


    public function password_update(Request $request){


        $messages = [
            'student_password_confirm.same' => 'Your password and and confirmation password must match.'
        ];

        $validator = Validator::make($request->all(), [
			'student_password'              => 'required|min:8|max:20',
			'student_password_confirm'		=> 'required|same:student_password',
		],$messages);

		if ($validator->fails()) {
            return redirect()->route('student.password')
                        ->withErrors($validator)
                        ->withInput();
        }
		else{

            if(Auth::guard('student')->check()){




                $student = Auth::guard('student')->user();

                if(!Hash::check($request->input('student_password_current'), $student->student_password)){

                    return redirect()->route('student.password')
                    ->with('error', 'Fail to change password because the current password provided is not correct.');
                }

                $student->student_password = Hash::make($request->input('student_password'));
                $student->save();
            }

            return redirect()->route('student.dashboard')
            ->with('message', 'Password has been changed successfully.');


		}

    }



    public function showAvatar(Request $request,$student_id){


	    if(Storage::exists('student_avatar/'.$student_id.'.jpg')){

			return response()->file(storage_path('app/student_avatar/'.$student_id.'.jpg'),['Content-Type'=>'image/jpeg']);

		}
		else{

			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}


    }


	public function uploadAvatar(Request $request,$student_id){

		$response = $request->input('avatar-file');

		$response = json_decode($response, true);

		$field =  $response['output']['field'];

		if (request()->hasFile($field)) {

		    $file = request()->file($field)->storeAs(
			    'student_avatar', $student_id.'.jpg'
			);

			return response()->json([
			    'status' => 'success',
			    'name' => $student_id.'.jpg',
			    'path' => $file
			]);

		}

        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);


	}

	public function removeAvatar(Request $request,$student_id){

		$student = Student::find($student_id);


		if((Auth::check() && Auth::user()->isAdmin()) || (Auth::guard('student')->check() && $student->student_id==Auth::guard('student')->user()->student_id)){

			if(Storage::exists('student_avatar/'.$student_id.'.jpg')){

				Storage::delete('student_avatar/'.$student_id.'.jpg');
				return response()->json([
			    'status' => 'success',
			    'name' => $student_id.'.jpg'
				]);

			}
			else{

				return response()->json([
			    'status' => 'failure',
			    'message' => 'Avatar does not exist'
				]);
			}

		}
		else{

			return response()->json([
			    'status' => 'failure',
			    'message' => 'You do not have permission to delete this avatar'
			]);
		}
	}



    public function import(){

        return view('backend.students.import');
    }


    public function import_post(Request $request){



        $students = Excel::toArray(new StudentsImport, request()->file('excel_file'))[0];


        $request->session()->put('students', $students);



        return view('backend.students.import-table')
                ->with('students',$students);


    }


    public function import_students(Request $request){


        $students = $request->session()->get('students');
        $password = Str::random(8);

        $confirmation_code = Str::random(30);

        $course = null;


        if($request->has('add-to-course-check') && $request->input('add-to-course-check')=='YES' && $request->has('course')){


            $course = Course::find($request->input('course'));

        }

        $new_count = 0;
        $existing_count = 0;


        foreach($students as $index=>$istudent){

            $student = Student::where('student_email',trim($istudent['student_email']))->first();

            if($student!=null){
                $existing_count++;
                Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been updated.');
            }
            else{
                $student = Student::create([
                    'student_first_name'            => $istudent['student_first_name'],
                    'student_last_name'             => $istudent['student_last_name'],
                    'is_member'                     => $istudent['is_member'],
                    'student_member_number'         => $istudent['student_member_number'],
                    'student_email'                 => $istudent['student_email'],
                    'student_password'              => Hash::make($password),
                    'student_title'                 => $istudent['student_title'],
                    'student_organization'          => $istudent['student_organization'],
                    'student_address'               => $istudent['student_address'],
                    'student_city'                  => $istudent['student_city'],
                    'student_state'                 => $istudent['student_state'],
                    'student_country'               => $istudent['student_country'],
                    'student_zip'                   => $istudent['student_zip'],
                    'student_phone'                 => $istudent['student_phone'],
                    'student_cellphone'             => $istudent['student_cellphone'],
                    'student_confirmation_code'     => $confirmation_code
                ]);
                $new_count++;
                Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been created.');
            }


            if($course!=null){


                $enrollment = Enrollment::where('enrollment_student_id',$student->student_id)->where('enrollment_course_id',$course->course_id)->first();

                if($enrollment==null){

                    $order = Order::create([
                        'order_amount'            => 0,
                        'order_tax'               => 0,
                        'order_subtotal'          => 0,
                        'order_payment_method'    => 'IMPORT',
                        'order_status'            => 'PAID'
                    ]);


                    $enrollment = Enrollment::create([
                        'enrollment_student_id'         => $student->student_id,
                        'enrollment_course_id'          => $course->course_id,
                        'enrollment_order_id'           => $order->order_id,
                        'enrollment_status'             => 'IN_PROGRESS',
                        'enrollment_certificate'        => 'PENDING',
                        'enrollment_course_duration'    => $course->course_duration,
                        'enrollment_start_date'         => Carbon::now(),
                        'enrollment_expiry_date'        => Carbon::now()->addDays($course->course_duration)
                    ]);

                    Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been assigned to the course ['.$course->course_name.']');

                }

                $student->student_status = 'APPROVED';
			    $student->save();

            }


			$email = $istudent['student_email'];
            $lead = 'Dear '.$istudent['student_first_name'].' '.$istudent['student_last_name'].',';
            $url_label = 'CONFIRM YOUR ACCOUNT NOW';
            $url = route('students.verify', ['confirmation_code' => $confirmation_code]);
            $content = '<p>Please confirm your ICAA Education account information. </p>';
            $content .= '<p><b>USERNAME:</b> '.$istudent['student_email'].'<br /><b>PASSWORD:</b> '.$password.'</p>';
			$content .= '<p><a href="'.$url.'"><b>'.$url_label.'</b></a></p>';
			$content .= '<p>Please click the link above to confirm your account.</p>';
            $content .= '<p>Once you have confirmed your account, please select and enroll in your course.</p>';
            $content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
            $content .= '<p>All the best,</p>';
            $content .= '<p>The ICAA Education team</p>';
			$subject = 'Confirm your ICAA Education account';


            try {

                Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

            } catch(\Exception $e) {


                $student->delete();

            }

        }


        return redirect()->route('admin.students.index')
                ->with('message','Import Complete! New Import:'.$new_count.', Existing Update:'.$existing_count);

    }




    public function sys_data_import(){

        return view('backend.students.sys-data-import');
    }


    public function sys_data_import_post(Request $request){



        $students = Excel::toArray(new StudentsImport, request()->file('excel_file'))[0];


        $request->session()->put('students', $students);



        return view('backend.students.sys-data-import-table')
                ->with('students',$students);


    }


    public function sys_data_import_students(Request $request){


        $students = $request->session()->get('students');
        $password = 'icaaeducation2022';

        $course = null;


        if($request->has('add-to-course-check') && $request->input('add-to-course-check')=='YES' && $request->has('course')){


            $course = Course::find($request->input('course'));

        }

        $new_count = 0;
        $existing_count = 0;


        foreach($students as $index=>$istudent){

            $student = Student::where('student_email',trim($istudent['student_email']))->first();

            if($student!=null){
                $existing_count++;
                Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been updated.');
            }
            else{

                $student = Student::create([
                    'student_first_name'            => $istudent['student_first_name'],
                    'student_last_name'             => $istudent['student_last_name'],
                    'is_member'                     => $istudent['is_member'],
                    'student_member_number'         => $istudent['student_member_number'],
                    'student_email'                 => $istudent['student_email'],
                    'student_password'              => Hash::make($password),
                    'student_title'                 => $istudent['student_title'],
                    'student_organization'          => $istudent['student_organization'],
                    'student_address'               => $istudent['student_address'],
                    'student_city'                  => $istudent['student_city'],
                    'student_state'                 => $istudent['student_state'],
                    'student_country'               => $istudent['student_country'],
                    'student_zip'                   => $istudent['student_zip'],
                    'student_phone'                 => $istudent['student_phone'],
                    'student_cellphone'             => $istudent['student_cellphone']
                ]);
                $new_count++;
                Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been created.');

            }


            if($course!=null){



                $enrollment = Enrollment::where('enrollment_student_id',$student->student_id)->where('enrollment_course_id',$course->course_id)->first();

                if($enrollment==null){

                    $order = Order::create([
                        'order_amount'            => 0,
                        'order_tax'               => 0,
                        'order_subtotal'          => 0,
                        'order_payment_method'    => 'IMPORT',
                        'order_status'            => 'PAID'
                    ]);


                    $enrollment = Enrollment::create([
                        'enrollment_student_id'         => $student->student_id,
                        'enrollment_course_id'          => $course->course_id,
                        'enrollment_order_id'           => $order->order_id,
                        'enrollment_status'             => 'IN_PROGRESS',
                        'enrollment_certificate'        => 'PENDING',
                        'enrollment_course_duration'    => $course->course_duration,
                        'enrollment_start_date'         => Carbon::now(),
                        'enrollment_expiry_date'        => Carbon::now()->addDays($course->course_duration)
                    ]);

                    Log::info($istudent['student_first_name'].' '.$istudent['student_last_name'].' has been assigned to the course ['.$course->course_name.']');

                }

                $student->student_status = 'APPROVED';
			    $student->save();

            }

        }


        return redirect()->route('admin.students.index')
                ->with('message','Import Complete! New Import:'.$new_count.', Existing Update:'.$existing_count);

    }


    public function export_students(Request $request,$course_id=0){


        return Excel::download(new StudentsExport($course_id), 'students.xlsx');

    }

    public function search_students(Request $request){

        if ($request->has('keywords')) {
            $keywords = $request->input('keywords');
            $students = Student::where('student_first_name', 'LIKE', "%{$keywords}%")
                    ->orWhere('student_last_name', 'LIKE', "%{$keywords}%")
                    ->orWhere('student_email', 'LIKE', "%{$keywords}%")
                    ->orWhere('student_organization', 'LIKE', "%{$keywords}%")
                    ->orWhere(DB::raw("CONCAT(`student_first_name`, ' ', `student_last_name`)"),'LIKE', "%{$keywords}%")
                    ->orWhere(DB::raw("CONCAT(`student_last_name`, ' ', `student_first_name`)"),'LIKE', "%{$keywords}%")
                    ->get();

            return view('backend.students.search')
				->with('students',$students);
        }

    }


    public function create(){

		return view('backend.students.create');

	}


    public function store(Request $request){


        if(Auth::check()){

    		Auth::logout();
    	}


        if(Auth::guard('student')->check()){

    		Auth::guard('student')->logout();
    	}


        if($request->has('is_member')&&$request->input('is_member')=='YES'){
			$request->merge(['is_member'=>'YES']);
		}
		else{
			$request->merge(['is_member'=>'NO']);
		}


        $messages = [
            'student_email.unique' => 'This email address is already in use.',
            'student_password_confirm.same' => 'Your password and confirmation password must match.'
        ];


		$validator = Validator::make($request->all(), [
			'student_first_name'            => 'required|max:255',
			'student_last_name'             => 'required|max:255',
			'student_email'                 => 'required|email|unique:students,student_email|max:255',
			'student_password'              => 'required|min:8|max:20',
			'student_password_confirm'		=> 'required|same:student_password',
			'student_title'                 => 'required',
			'student_organization'          => 'required',
			'student_address'               => 'required',
			'student_city'                  => 'required',
			'student_state'                 => 'required',
			'student_country'               => 'required',
            'student_zip'                   => 'required',
            'student_phone'                 => 'required',
            'student_cellphone'             => 'required',
        ], $messages);

		if ($validator->fails()) {
            return redirect()->route('registration.index')
                        ->withErrors($validator)
                        ->withInput();
        }
		else{

			$confirmation_code = Str::random(30);

			$student = Student::create([
                'student_first_name'            => $request->input('student_first_name'),
                'student_last_name'             => $request->input('student_last_name'),
                'is_member'                     => $request->input('is_member'),
                'student_member_number'         => $request->input('student_member_number'),
                'student_email'                 => $request->input('student_email'),
                'student_password'              => Hash::make($request->input('student_password')),
                'student_title'                 => $request->input('student_title'),
                'student_organization'          => $request->input('student_organization'),
                'student_address'               => $request->input('student_address'),
                'student_city'                  => $request->input('student_city'),
                'student_state'                 => $request->input('student_state'),
                'student_country'               => $request->input('student_country'),
                'student_zip'                   => $request->input('student_zip'),
                'student_phone'                 => $request->input('student_phone'),
                'student_cellphone'             => $request->input('student_cellphone'),
                'student_confirmation_code'     => $confirmation_code
			]);

			$email = $request->input('student_email');
			$lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
            $url_label = 'CONFIRM YOUR ACCOUNT NOW';
            $url = route('students.verify', ['confirmation_code' => $confirmation_code]);
            $content = '<p>Please confirm your ICAA Education account information. </p>';
			$content .= '<p><a href="'.$url.'"><b>'.$url_label.'</b></a></p>';
            $content .= '<p><b>The verification link above will only be valid for 24 hours.</b> Simply click on the link to <b>verify your ICAA Education account</b>.</p>';
            $content .= '<p>Once you have verified your account <b>you will able to register for your course</b>.</p>';
            $content .= '<p><b>Please note that this link only works once</b>, and it will become invalid after your account gets verified. If you have already verified your account, please login on the ICAA Education site using your login email and password.</p>';
            $content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
            $content .= '<p>All the best,</p>';
            $content .= '<p>The ICAA Education team</p>';
			$subject = 'STEP 2: Confirm your ICAA Education account';



            try {

                Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

            } catch(\Exception $e) {


                $student->delete();
                $errorMessage = 'Email Server Error. Please Contact ica.cc. (Notes: ' . $e->getMessage().')' ;

				return redirect()->route('registration.index')
                        ->withInput()
                        ->with('error',$errorMessage );
						//->with('error','Fail to send the confirmation email. Please make sure you provide a valid email address and try again later.');

            }


			return redirect()->route('home')->with('message','Your application has been submitted for approval. You will receive a confirmation email shortly.');
		}
	}


    public function edit($sid){

		$student = Student::find($sid);

		if($student != null){
			return view('backend.students.edit')
				->with('student',$student);
		}
	}


    public function update(Request $request,$sid){

		$student = Student::find($sid);

		if($student != null){

			if($request->has('is_member')&&$request->input('is_member')=='YES'){
                $request->merge(['is_member'=>'YES']);
            }
            else{
                $request->merge(['is_member'=>'NO']);
            }


            $messages = [
                'student_email.unique' => 'This email address is already in use.',
                'student_password_confirm.same' => 'Your password and confirmation password must match.'
            ];

			$validator = Validator::make($request->all(), [
				'student_first_name'            => 'required|max:255',
                'student_last_name'             => 'required|max:255',
                'student_email'                 => 'required|email|unique:students,student_email,'.$sid.',student_id|max:255',
                'student_password'              => 'min:8|max:20',
                'student_password_confirm'		=> 'same:student_password',
                'student_title'                 => 'required',
                'student_organization'          => 'required',
                'student_address'               => 'required',
                'student_city'                  => 'required',
                'student_state'                 => 'required',
                'student_country'               => 'required',
                'student_zip'                   => 'required',
                'student_phone'                 => 'required',
                'student_cellphone'             => 'required',
            ],$messages);

			if ($validator->fails()) {

				return redirect()->route('admin.students.edit',['sid'=>$student->student_id])
							->withErrors($validator)
							->withInput();
			}
			else{

				$pass_input = $request->input('student_password');

				if(empty($pass_input)){

					$student->update([
						'student_first_name'            => $request->input('student_first_name'),
                        'student_last_name'             => $request->input('student_last_name'),
                        'is_member'                     => $request->input('is_member'),
                        'student_member_number'         => $request->input('student_member_number'),
                        'student_status'                => $request->input('student_status'),
                        'student_email'                 => $request->input('student_email'),
                        'student_title'                 => $request->input('student_title'),
                        'student_organization'          => $request->input('student_organization'),
                        'student_address'               => $request->input('student_address'),
                        'student_city'                  => $request->input('student_city'),
                        'student_state'                 => $request->input('student_state'),
                        'student_country'               => $request->input('student_country'),
                        'student_zip'                   => $request->input('student_zip'),
                        'student_phone'                 => $request->input('student_phone'),
                        'student_cellphone'             => $request->input('student_cellphone')
					]);

				}
				else{

					$student->update([
						'student_first_name'            => $request->input('student_first_name'),
                        'student_last_name'             => $request->input('student_last_name'),
                        'is_member'                     => $request->input('is_member'),
                        'student_member_number'         => $request->input('student_member_number'),
                        'student_status'                => $request->input('student_status'),
                        'student_email'                 => $request->input('student_email'),
                        'student_password'              => Hash::make($request->input('student_password')),
                        'student_title'                 => $request->input('student_title'),
                        'student_organization'          => $request->input('student_organization'),
                        'student_address'               => $request->input('student_address'),
                        'student_city'                  => $request->input('student_city'),
                        'student_state'                 => $request->input('student_state'),
                        'student_country'               => $request->input('student_country'),
                        'student_zip'                   => $request->input('student_zip'),
                        'student_phone'                 => $request->input('student_phone'),
                        'student_cellphone'             => $request->input('student_cellphone')
					]);

				}
			}

			return redirect()->route('admin.students.edit',['sid'=>$student->student_id])
						->with('message','Student has been updated successfully!');
		}


	}



    public function destroy(Request $request,$id){

		Student::destroy($id);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted student.',
		]);
	}

	public function destroyMany(Request $request){


		$ids = explode(",",$request->input('ids'));

		Student::destroy($ids);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted students.',
		]);
	}

    public function resendConfirmationCode(Request $request,$sid){

		$student = Student::find($sid);

		if($student != null){

			$confirmation_code = Str::random(30);

            $student->student_status = 'UNVERIFIED';
            $student->student_confirmation_code = $confirmation_code;
            $student->save();


            $email = $student->student_email;
            $lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
            $url_label = 'CONFIRM YOUR ACCOUNT NOW';
            $url = route('students.verify', ['confirmation_code' => $confirmation_code]);
            $content = '<p>Please confirm your ICAA Education account information. </p>';
			$content .= '<p><a href="'.$url.'"><b>'.$url_label.'</b></a></p>';
            $content .= '<p>Once you have confirmed your account, please select and enroll in your course.</p>';
            $content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
            $content .= '<p>All the best,</p>';
            $content .= '<p>The ICAA Education team</p>';
			$subject = 'Confirm your ICAA Education account';


			try {

                Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

            } catch(\Exception $e) {

                return response()->json([
                    'status' => 'failure',
                    'message' => 'Fail to resend confirmation code, please make sure you provid a valid email address.',
                ]);

            }


			return response()->json([
				'status' => 'success',
				'message' => 'Successfully resend confirmation code.',
			]);

		}

		return response()->json([
			'status' => 'failure',
			'message' => 'Fail to resend confirmation code.',
		]);


	}


    public function confirm(Request $request,$confirmation_code)
    {

        if(Auth::check()){

			Auth::logout();
		}


    	if(Auth::guard('student')->check()){

    		Auth::guard('student')->logout();
    	}

        if( ! $confirmation_code)
        {
            return redirect()->route('home')
        		->with('error', 'Verification code missing, we are not able to verify your account.');
        }

        $student = Student::where('student_confirmation_code',$confirmation_code)->first();

        if ( ! $student)
        {
            return redirect()->route('student.login')
        		->with('error', 'The verification code is no longer valid. If you have already verified your account, please login on the ICAA Education site using your login email and password.');
        }

        $student->student_status = 'PENDING';
        $student->student_confirmation_code = null;
        $student->save();

        Auth::guard('student')->login($student);


        // $email = $student->student_email;
        // $lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
        // $content = '<p>We are pleased to inform you that your ICAA Education account application has been approved.</p>';
        // $content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
        // $content .= '<p>All the best,</p>';
        // $content .= '<p>The ICAA Education team</p>';
        // $subject = 'Your ICAA Education account has been approved';

        // try {

        //     Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

        // } catch(\Exception $e) {


        // }


        return redirect()->route('student.dashboard')
        		->with('message', 'Your account has been confirmed, please select your courses.');
    }

    public function login(Request $request){


        return view('frontend.login');
    }



    public function studentLogin(Request $request){

        if(Auth::check()){

    		Auth::logout();
    	}

		if ( Auth::guard('student')->attempt(array('student_email' => $request->input('student_email'), 'password' => $request->input('student_password'))) )
		{

			if (Auth::guard('student')->check())
			{

					if(Auth::guard('student')->user()->student_status=='UNVERIFIED'){

						Auth::guard('student')->logout();
						return back()
							->with('error', 'Your email address has not been confirmed!');

					}elseif(Auth::guard('student')->user()->student_status=='ABANDONED'){

						Auth::guard('student')->logout();
						return back()
							->with('error', 'Your account is abandoned!');

					}



					return redirect()->route('student.dashboard')
                            ->with('message', 'Login successful!');


			}
			return 'not logged in';

		}else{

			return back()
        		->with('error', 'Your email / password combination was incorrect')
        		->withInput();

		}

	}

    public function studentLogout(){

        if(Auth::check()){

			Auth::logout();

		}


		if(Auth::guard('student')->check()){

			Auth::guard('student')->logout();
		}


        return redirect()->route('home');


	}

    public function course_index(){

        $courses = Course::where('course_status','PUBLIC')->get();

        $orders = null;

        if(Auth::guard('student')->check()){

            $orders = Auth::guard('student')->user()->enrollments()->with('order')->where('enrollment_status','PENDING')->get()->pluck('order')->where('order_status','PENDING')->where('order_payment_method','PayPal');
        }

		return view('frontend.courses.index')
                ->with('courses',$courses)
                ->with('orders',$orders);
    }

    public function course_description(Request $request,$course_slug){

        $course = Course::where('course_slug',$course_slug)->first();

        if($course!=null){
            $modules = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->orderBy('module_position')->get();

            if($modules != null){

                return view('frontend.courses.course')
                    ->with('course',$course)
                    ->with('course_slug',$course_slug)
                    ->with('modules',$modules);

            }
        }


    }

    public function course_summary(Request $request,$course_slug){

        $course = Course::where('course_slug',$course_slug)->first();



        $modules = $course->modules;
        $sections = [];
        $assignment_sections = [];

        $progress = 0;
        $average = 0;
        $assignment_average = 0;

        foreach($modules as $index=>$module){
            $sections = array_merge($sections,$module->sections()->where('section_type','QUIZ')->pluck('section_id')->toArray());
            $assignment_sections = array_merge($assignment_sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());
        }



        if(Auth::guard('student')->check()){

            $log_quiz = LogQuiz::where('log_student_id',Auth::guard('student')->user()->student_id)->whereIn('log_test_section_id', $sections)->get();
            $log_assignment = LogAssignment::where('log_student_id',Auth::guard('student')->user()->student_id)->whereIn('log_assignment_section_id', $assignment_sections)->whereNotNull('assignment_score')->get();




            if($log_quiz->count()>0){


                foreach($log_quiz as $quiz){

                  if($quiz->is_retake !='N'){
                    $average += $quiz->quiz_score;
                  }


                }

                $average = round($average/($log_quiz->count()*1.00));


                // if(count($sections)>0){

                //     $progress = round(($log_quiz->count()*100.00)/(count($sections)*1.00));
                // }

            }


            if($log_assignment->count()>0){


                foreach($log_assignment as $assignment){
                    $assignment_average += $assignment->assignment_score;
                }

                $assignment_average = round($assignment_average/($log_assignment->count()*1.00));


                // if(count($assignment_sections)>0){

                //     $progress = round(($log_assignment->count()*100.00)/(count($assignment_sections)*1.00));
                // }

            }



            if(count($sections)+count($assignment_sections)>0){

                $progress = round((($log_quiz->count()+$log_assignment->count())*100.00)/((count($sections) + count($assignment_sections))*1.00));
            }






        }




        if($course!=null && $this->checkCoursePermission($course->course_id)){
            $modules = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->orderBy('module_position')->get();




            if($modules != null && $course->course_id==$module->module_course_id){
              $allsection_id = Section::find($sections);

              //$pages = 0;






              //foreach($modules as $index=>$module){
                  //$sections = array_merge($sections,$module->sections()->where('section_type','QUIZ')->pluck('section_id')->toArray());
                  //$assignment_sections = array_merge($assignment_sections,$module->sections()->where('section_type','ASSIGNMENT')->pluck('section_id')->toArray());

                  $log_quiz = LogQuiz::where('log_student_id',Auth::guard('student')->user()->student_id)->whereIn('log_test_section_id', $sections)->get();
                  //$prevSectionID = Section::where('section_id',$course->course_id)->where('section_status','PUBLIC')->get();
                  //$allsection_id = Section::whereIn('section_id',$sections)->where('section_status','PUBLIC')->get();



                  return view('frontend.courses.modules.index')
                      ->with('course',$course)
                      ->with('course_slug',$course_slug)
                      ->with('modules',$modules)
                      ->with('progress',$progress)
                      ->with('log_quiz',$log_quiz)
                      ->with('allsection_id',$allsection_id)
                      //->with('section_id',$section_id)
                      ->with('average',$average)
                      ->with('assignment_average',$assignment_average);

              //}






            }
        }



        abort(404);
    }


    public function alumnis(Request $request){


            $students = Enrollment::with('student')->where('enrollment_status','COMPLETE')->get()->pluck('student')->unique();


            $grouped = $students->groupBy(function($item,$key) {
                return $item->student_last_name[0];     //treats the name string as an array
            })
            ->sortBy(function($item,$key){      //sorts A-Z at the top level
                    return $key;
            });

            return view('frontend.pages.alumnis')
                    ->with('grouped',$grouped);

    }

    public function contact(Request $request){

        return view('frontend.pages.contact');

    }



    public function contactPost(Request $request){


        $validator = Validator::make($request->all(), [
			'contact_name'             => 'required',
			'contact_email'            => 'required|email',
			'contact_subject'          => 'required',
			'contact_message'          => 'required',
		]);

		if ($request->input('contact_url')){

		}elseif ($validator->fails()) {

            return redirect()->route('contact')->withInput()
					->withErrors($validator);
        }
        else{

            $email = config('setting.admin_email');
            $lead = 'Dear '.config('setting.admin_name').',';
            $content = '<p>You got a new message from ICAA Education.</p>';
            $content .= '<p><blockquote><b>Subject: </b>'.$request->input('contact_subject').'<br/><b>Email: </b>'.$request->input('contact_email').'<br/><b>Name: </b>'.$request->input('contact_name').'<br/><b>Message: </b>'.$request->input('contact_message').'</blockquote></p>';
            $content .= '<p>The ICAA Education team</p>';
            $subject = 'You got a new contact message from ICAA Education';


            try {

                Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));

            } catch(\Exception $e) {


                return redirect()->route('contact')->withInput()
                        ->with('error','Fail to send the message, please try again later.');

            }

        }


        return redirect()->route('contact')
                        ->with('message','Your message has been successfully sent to ICAA Education.');





    }

    public function participants(Request $request,$course_slug){

        $course = Course::where('course_slug',$course_slug)->first();

        if($course!=null){

            $students = $course->enrollments()->with('student')->where('enrollment_status','IN_PROGRESS')->get()->pluck('student')->unique();


            $grouped = $students->groupBy(function($item,$key) {
                return $item->student_last_name[0];     //treats the name string as an array
            })
            ->sortBy(function($item,$key){      //sorts A-Z at the top level
                    return $key;
            });

            return view('frontend.pages.participants')
                    ->with('course',$course)
                    ->with('grouped',$grouped);
        }
    }

    public function student_profile(Request $request,$student_id){

        $student = Student::find($student_id);

        if($student!=null){

            return view('frontend.pages.profile')
            ->with('student',$student);

        }

        abort(404);



    }



    public function course_modules(Request $request,$course_slug,$module_id){

        $course = Course::where('course_slug',$course_slug)->first();

        if($course!=null && $this->checkCoursePermission($course->course_id)){


            $module = Module::find($module_id);

            if($module!=null && $course->course_id==$module->module_course_id){

                $nextModuleID = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->where('module_position', '>', $module->module_position)->orderBy('module_position')->first();

                if($nextModuleID!=null && $nextModuleID->sections()->where('section_status','PUBLIC')->count()>0){
                    $nextModuleID = $nextModuleID->module_id;
                }else{
                    $nextModuleID = null;
                }

                return view('frontend.courses.sections.index')
                ->with('module',$module)
                ->with('course_slug',$course_slug)
                ->with('module_id',$module_id)
                ->with('nextModuleID',$nextModuleID);
            }

        }



        abort(404);
    }

    public function course_page(Request $request,$course_slug,$module_id,$section_id,$page=1){


        $course = Course::where('course_slug',$course_slug)->first();

        if($course!=null){


            if(!$this->checkCoursePermission($course->course_id)){

                return redirect()->route('courses.index')
						->with('error', 'Your ICAA Education account does not permit access to this page. If you have questions about this, please contact ICAA Education.');
            }


            $module = Module::find($module_id);

            if($module!=null && $course->course_id==$module->module_course_id){

                $section = Section::find($section_id);

                $pages = 0;

                if($section!=null && $section->section_content!=null){
                    $pages = count($section->section_content);
                }

                if($section!=null && $module_id==$section->section_module_id &&  ($section->section_type!='CONTENT' || ($page<=$pages && $page>0)) && $section->section_status=='PUBLIC'){

                    $prevSectionID = Section::where('section_module_id',$module_id)->where('section_status','PUBLIC')->where('section_position', '<', $section->section_position)->orderBy('section_position','desc')->first();

                    if($prevSectionID!=null){
                        $prevSectionID = $prevSectionID->section_id;
                    }


                    $nextSectionID = Section::where('section_module_id',$module_id)->where('section_status','PUBLIC')->where('section_position', '>', $section->section_position)->orderBy('section_position')->first();

                    if($nextSectionID!=null){
                        $nextSectionID = $nextSectionID->section_id;
                    }

                    $totalSection = Section::where('section_module_id',$module_id)->where('section_status','PUBLIC')->count();
                    $currentSection = Section::where('section_module_id',$module_id)->where('section_status','PUBLIC')->where('section_position', '<=', $section->section_position)->count();

                    $nextModuleID = Module::where('module_course_id',$course->course_id)->where('module_status','PUBLIC')->where('module_position', '>', $module->module_position)->orderBy('module_position')->first();


                    $nextModuleFirstSectionID = null;

                    if($nextModuleID!=null && $nextModuleID->sections()->where('section_status','PUBLIC')->count()>0){

                        $nextModuleFirstSectionID = $nextModuleID->sections()->where('section_status','PUBLIC')->orderBy('section_position')->first()->section_id;

                        $nextModuleID = $nextModuleID->module_id;

                    }else{
                        $nextModuleID = null;
                    }


                    if(Auth::guard('student')->check()){

                        // $log_view = LogView::create([
                        //     'log_student_id'   => Auth::guard('student')->user()->student_id,
                        //     'log_section_id'   => $section_id,
                        //     'log_views'        => 1
                        // ]);

                        $log_view = LogView::updateOrCreate(
                            ['log_student_id' => Auth::guard('student')->user()->student_id, 'log_section_id' => $section_id]
                        )->increment('log_views');

                    }


                    switch($section->section_type){
                        case 'CONTENT':
                            return view('frontend.courses.sections.page')
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            break;
                        case 'PRETEST':

                            if(Auth::guard('student')->check()){
                                return view('frontend.courses.sections.pretest')
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            }
                            else{
                                return view('frontend.courses.sections.test')
                                ->with('section',$section)
                                ->with('course_slug',$course_slug)
                                ->with('module_id',$module_id)
                                ->with('section_id',$section_id)
                                ->with('page',$page)
                                ->with('prevSectionID',$prevSectionID)
                                ->with('nextSectionID',$nextSectionID)
                                ->with('totalSection',$totalSection)
                                ->with('currentSection',$currentSection)
                                ->with('nextModuleID',$nextModuleID)
                                ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            }

                            break;
                        case 'RETAKE_QUIZ':
                        if(Auth::guard('student')->check()){

                            $quiz_count = LogQuiz::where('log_test_section_id',$section_id)->where('log_student_id',Auth::guard('student')->user()->student_id)->count();

                            if($quiz_count<1){

                                return view('frontend.courses.sections.quiz')
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);

                            }
                            else{


                                $quiz_log = LogQuiz::where('log_test_section_id',$section_id)->where('log_student_id',Auth::guard('student')->user()->student_id)->first();

                                return view('frontend.courses.sections.result')
                                    ->with('quiz_log',$quiz_log)
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            }

                        }
                        else{
                                return view('frontend.courses.sections.test')
                                ->with('section',$section)
                                ->with('course_slug',$course_slug)
                                ->with('module_id',$module_id)
                                ->with('section_id',$section_id)
                                ->with('page',$page)
                                ->with('prevSectionID',$prevSectionID)
                                ->with('nextSectionID',$nextSectionID)
                                ->with('totalSection',$totalSection)
                                ->with('currentSection',$currentSection)
                                ->with('nextModuleID',$nextModuleID)
                                ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);


                        }

                        break;



                        case 'QUIZ':

                            if(Auth::guard('student')->check()){

                                $quiz_count = LogQuiz::where('log_test_section_id',$section_id)->where('log_student_id',Auth::guard('student')->user()->student_id)->count();

                                if($quiz_count<1){

                                    return view('frontend.courses.sections.quiz')
                                        ->with('section',$section)
                                        ->with('course_slug',$course_slug)
                                        ->with('module_id',$module_id)
                                        ->with('section_id',$section_id)
                                        ->with('page',$page)
                                        ->with('prevSectionID',$prevSectionID)
                                        ->with('nextSectionID',$nextSectionID)
                                        ->with('totalSection',$totalSection)
                                        ->with('currentSection',$currentSection)
                                        ->with('nextModuleID',$nextModuleID)
                                        ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);

                                }
                                else{


                                    $quiz_log = LogQuiz::where('log_test_section_id',$section_id)->where('log_student_id',Auth::guard('student')->user()->student_id)->first();

                                    return view('frontend.courses.sections.result')
                                        ->with('quiz_log',$quiz_log)
                                        ->with('section',$section)
                                        ->with('course_slug',$course_slug)
                                        ->with('module_id',$module_id)
                                        ->with('section_id',$section_id)
                                        ->with('page',$page)
                                        ->with('prevSectionID',$prevSectionID)
                                        ->with('nextSectionID',$nextSectionID)
                                        ->with('totalSection',$totalSection)
                                        ->with('currentSection',$currentSection)
                                        ->with('nextModuleID',$nextModuleID)
                                        ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                                }

                            }
                            else{
                                    return view('frontend.courses.sections.test')
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);


                            }

                            break;
                        case 'INTRODUCTION':
                            return view('frontend.courses.sections.introduction')
                                    ->with('section',$section)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('totalSection',$totalSection)
                                    ->with('currentSection',$currentSection)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            break;
                        case 'TABLE_OF_CONTENT':
                            return view('frontend.courses.sections.table-of-content')
                                    ->with('section',$section)
                                    ->with('module',$module)
                                    ->with('course_slug',$course_slug)
                                    ->with('module_id',$module_id)
                                    ->with('section_id',$section_id)
                                    ->with('nextModuleID',$nextModuleID)
                                    ->with('page',$page)
                                    ->with('prevSectionID',$prevSectionID)
                                    ->with('nextSectionID',$nextSectionID)
                                    ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);
                            break;
                        case 'ASSIGNMENT':


                            if(Auth::guard('student')->check()){

                                $assignment = $section->assignments->first();

                                $log_assignment = LogAssignment::updateOrCreate(
                                    ['log_student_id' => Auth::guard('student')->user()->student_id, 'log_assignment_section_id' => $section_id]
                                );


                                if($log_assignment->assignment_status==null){
                                    $log_assignment->assignment_status = 'IN_PROGRESS';
                                    $log_assignment->save();
                                }


                                $assignment_id = $log_assignment->section->assignments->first()->assignment_id;
                                $log_id = $log_assignment->log_id;
                                $files = Storage::files('assignment_log/'.$log_id.'/'.$assignment_id);
                                $filesArray = array();

                                foreach($files as $file){

                                    $tempFile = array();
                                    $tempFile['file_location'] = $file;
                                    $tempFile['file_name'] = basename($file);
                                    $tempFile['file_extension'] = pathinfo($file)['extension'];
                                    $tempFile['file_type'] = pathinfo($file)['extension'];
                                    $tempFile['file_log_id'] = $log_id;
                                    $tempFile['file_assignment_id'] = $assignment_id;

                                    array_push($filesArray,$tempFile);
                                }

                                if($log_assignment->assignment_status=='IN_MARKING' || $log_assignment->assignment_status=='COMPLETE'){

                                    return view('frontend.courses.sections.assignment-result')
                                        ->with('section',$section)
                                        ->with('module',$module)
                                        ->with('course_slug',$course_slug)
                                        ->with('module_id',$module_id)
                                        ->with('section_id',$section_id)
                                        ->with('nextModuleID',$nextModuleID)
                                        ->with('page',$page)
                                        ->with('prevSectionID',$prevSectionID)
                                        ->with('nextSectionID',$nextSectionID)
                                        ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID)
                                        ->with('log_assignment',$log_assignment)
                                        ->with('files',$filesArray);

                                }

                                return view('frontend.courses.sections.assignment')
                                        ->with('section',$section)
                                        ->with('module',$module)
                                        ->with('course_slug',$course_slug)
                                        ->with('module_id',$module_id)
                                        ->with('section_id',$section_id)
                                        ->with('nextModuleID',$nextModuleID)
                                        ->with('page',$page)
                                        ->with('prevSectionID',$prevSectionID)
                                        ->with('nextSectionID',$nextSectionID)
                                        ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID)
                                        ->with('log_assignment',$log_assignment)
                                        ->with('files',$filesArray);
                                break;

                            }
                            elseif(Auth::check()){


                                return view('frontend.courses.sections.assignment-display')
                                        ->with('section',$section)
                                        ->with('module',$module)
                                        ->with('course_slug',$course_slug)
                                        ->with('module_id',$module_id)
                                        ->with('section_id',$section_id)
                                        ->with('nextModuleID',$nextModuleID)
                                        ->with('page',$page)
                                        ->with('prevSectionID',$prevSectionID)
                                        ->with('nextSectionID',$nextSectionID)
                                        ->with('nextModuleFirstSectionID',$nextModuleFirstSectionID);


                            }



                    }

                }


            }


            return redirect()->route('courses.summary',['course_slug'=>$course_slug])
                    ->with('error', 'The page does not exist!');

        }

        return redirect()->route('courses.index')
						->with('error', 'The page does not exist!');

    }


    public function showSectionThumbnail(Request $request,$course_id,$module_id,$section_id){


	    if(Storage::exists('course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg')){

			return response()->file(storage_path('app/course/'.$course_id.'/module/'.$module_id.'/section/'.$section_id.'/thumbnail.jpg'),['Content-Type'=>'image/jpeg']);

		}
		else{

			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}

    }

    public function showCourseThumbnail(Request $request,$course_id){

        if(Storage::exists('course/'.$course_id.'/cover/1.jpg')){

			return response()->file(storage_path('app/course/'.$course_id.'/cover/1.jpg'),['Content-Type'=>'image/jpeg']);

		}
		else{

			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}
    }

    public function quizSubmit(Request $request,$section_id){

        $section = Section::find($section_id);

        $selections = json_decode($request->input('selections'), true);



        if($section!=null && $section->section_type=='QUIZ' || $section->section_type=='RETAKE_QUIZ'){

            $answers = $section->tests()->orderBy('test_position')->get();

            $total = count($answers);
            $count = 0;

            $quiz_questions = [];
            $quiz_options = [];
            $quiz_answers = $answers->toArray();


            foreach($selections as $index=>$selection){


                $tid = $selection['tid'];
                $search = $answers->where('test_id',$tid)->first();
                $options = $search->test_options;

                $quiz_questions[] = $search->test_question;
                $quiz_options[] = $options;


                $key = array_search('Yes', array_column($options, 'checked'));


                $correct_answer = $options[$key]['option'];


                if($correct_answer==$selection['selection']){
                    $count++;
                }

            }

            $score = round((floatval($count)/floatval($total))*100,2);



            if(Auth::guard('student')->check()){


                $quiz_count = LogQuiz::where('log_test_section_id',$section_id)->where('log_student_id',Auth::guard('student')->user()->student_id)->count();


                $selections_array = array();

                foreach($selections as $answer_selection){
                    $selections_array[$answer_selection['tid']] = $answer_selection['selection'];
                }


                if($quiz_count==0){

                    $log_quiz = LogQuiz::create([
                        'log_test_section_id'   => $section_id,
                        'log_student_id'        => Auth::guard('student')->user()->student_id,
                        'quiz_score'            => $score,
                        'quiz_options'          => $quiz_options,
                        'quiz_answers'          => $quiz_answers,
                        'quiz_selections'       => $selections_array,
                    ]);



                    //******* Update overall progress and score  */

                    // $module = $section->module;
                    // $modules = $module->course->modules;
                    // $sections = [];


                    // foreach($modules as $index=>$module){
                    //     $sections = array_merge($sections,$module->sections()->where('section_type','QUIZ')->pluck('section_id')->toArray());
                    // }


                    // $log_quiz = LogQuiz::where('log_student_id',Auth::guard('student')->user()->student_id)->whereIn('log_test_section_id', $sections)->get();

                    // $progress = 0;
                    // $average = 0;

                    // if($log_quiz->count()>0){


                    //     foreach($log_quiz as $quiz){
                    //         $average += $quiz->quiz_score;
                    //     }

                    //     $average = round($average/($log_quiz->count()*1.00));


                    //     if(count($sections)>0){

                    //         $progress = round(($log_quiz->count()*100.00)/(count($sections)*1.00));
                    //     }

                    //     $enrollment = Enrollment::where('enrollment_student_id',Auth::guard('student')->user()->student_id)->where('enrollment_course_id',$module->module_course_id)->where('enrollment_status','IN_PROGRESS')->orderBy('created_at','DESC')->first();

                    //     if($enrollment!=null){
                    //         $enrollment->enrollment_quiz_progress=$progress;
                    //         $enrollment->enrollment_quiz_score=$average;
                    //         $enrollment->save();
                    //     }



                    // }

                    if(Helpers::setStudentCourseStat(Auth::guard('student')->user()->student_id,$section->module->course->course_id)){

                    }
                    else{
                        return response()->json([
                            'status' => 'fail',
                            'score' => 0
                        ]);
                    }

                }
                else{
                    return response()->json([
                        'status' => 'fail',
                        'score' => 0
                    ]);
                }

            }


            return response()->json([
                'status' => 'success',
                'score' => $score,
                'explanation' => $section->section_explanation
            ]);


        }





    }


    public function assignmentFilesUpload(Request $request,$log_id,$assignment_id){


        if(!Auth::guard('student')->check()){
            return response()->json([
			    'status' => 'failure',
			    'message' => 'session timeout or you do not have permission to upload, please log-in again with a valid student account.'
			]);
        }


        $assignment = Assignment::find($assignment_id);
        $log = LogAssignment::find($log_id);

		if($assignment!=null && $log!=null){



            if(Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$log->log_student_id && ($log->assignment_status==null || $log->assignment_status=='IN_PROGRESS' || $log->assignment_status=='SUBMITTED')){


                $files = Storage::files('assignment_log/'.$log_id.'/'.$assignment_id);

                if(count($files)<config('setting.max_assignment_uploads')){

                    $path = $request->file('file')->storeAs(
                        'assignment_log/'.$log_id.'/'.$assignment_id, $request->file('file')->getClientOriginalName()
                    );

                    $log->assignment_updated_date = Carbon::now();
                    $log->save();

                    return response()->json([
                        'status' => 'success',
                        'name' => $request->file('file')->getClientOriginalName(),
                        'path' => Storage::path($path)
                    ]);

                }
                else{
                    return response()->json([
                        'status' => 'failure',
                        'message' => 'sorry, you can upload up to '.config('setting.max_assignment_uploads').' files'
                    ]);
                }



            }
            elseif(Auth::check()){


            }



		}


        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);

    }


    public function listAssignmentFolderContent(Request $request,$log_id,$assignment_id){

		$files = Storage::files('assignment_log/'.$log_id.'/'.$assignment_id);
		$filesArray = array();

		foreach($files as $file){

			$tempFile = array();
			$tempFile['file_location'] = $file;
			$tempFile['file_name'] = basename($file);
			$tempFile['file_extension'] = pathinfo($file)['extension'];
			$tempFile['file_type'] = pathinfo($file)['extension'];
			$tempFile['file_log_id'] = $log_id;
            $tempFile['file_assignment_id'] = $assignment_id;

			array_push($filesArray,$tempFile);
		}

		$response = view('frontend.courses.blocks.assignment-file')->with('files', $filesArray)->render();

		return response()->json([
			'status' => 'success',
			'response' => $response
		]);

	}

    public function displayAssignmentFile(Request $request,$log_id,$assignment_id,$file){

        $assignment = Assignment::find($assignment_id);

		if($assignment!=null){

            $path = 'assignment_log/'.$log_id.'/'.$assignment_id.'/'.$file;


            if(Storage::exists($path)){

                $pathToFile = Storage::path($path);

			    return response()->file($pathToFile);

            }


		}

    }

    public function removeAssignmentFile(Request $request,$log_id,$assignment_id){

        $assignment = Assignment::find($assignment_id);
        $log = LogAssignment::find($log_id);

		if($assignment!=null && $log!=null){

            if(Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$log->log_student_id && ($log->assignment_status==null || $log->assignment_status=='IN_PROGRESS' || $log->assignment_status=='SUBMITTED')){


                $file = $request->input('filename');

                $response = Storage::delete('assignment_log/'.$log_id.'/'.$assignment_id.'/'.$file)?'success':'failure';

                $log->assignment_updated_date = Carbon::now();
                $log->save();

                return response()->json([
                    'status' => $response
                ]);

            }
            elseif(Auth::check()){


            }



		}

		return response()->json([
			'status' => 'failure',
			'message' => 'fail to remove image'
		]);


    }
/*
    public function assignmentSubmit(Request $request,$log_id){

        $log = LogAssignment::find($log_id);

        if($log!=null){

            if(Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$log->log_student_id && ($log->assignment_status==null || $log->assignment_status=='IN_PROGRESS' || $log->assignment_status=='SUBMITTED')){

                $log->assignment_comments = $request->input('assignment_comments');
                $log->assignment_status = 'SUBMITTED';
                $log->assignment_updated_date = Carbon::now();
                $log->assignment_answers = $request->input('assignment_answers');
                $log->save();



                $assignment_id = $log->section->assignments->first()->assignment_id;
                $files = Storage::files('assignment_log/'.$log_id.'/'.$assignment_id);
                $filesArray = array();

                foreach($files as $file){

                    $tempFile = array();
                    $tempFile['file_location'] = $file;
                    $tempFile['file_name'] = basename($file);
                    $tempFile['file_extension'] = pathinfo($file)['extension'];
                    $tempFile['file_type'] = pathinfo($file)['extension'];
                    $tempFile['file_log_id'] = $log_id;
                    $tempFile['file_assignment_id'] = $assignment_id;

                    array_push($filesArray,$tempFile);
                }


                $response = view('frontend.courses.blocks.assignment-info')->with('log_assignment', $log)->with('files',$filesArray)->render();

                return response()->json([
                    'status'   => 'success',
                    'message'  => 'Assignment has been sumitted successfully',
                    'response' => $response
                ]);

            }


        }

        return response()->json([
			'status' => 'failure',
			'message' => 'fail to submit'
		]);

    }
*/

    public function assignmentSubmit(Request $request,$log_id){

        $log = LogAssignment::find($log_id);

        if($log!=null){

            if(Auth::guard('student')->check() && Auth::guard('student')->user()->student_id==$log->log_student_id && ($log->assignment_status==null || $log->assignment_status=='IN_PROGRESS' || $log->assignment_status=='SUBMITTED')){



                $log->assignment_comments = $request->input('assignment_comments');
                $log->assignment_status = 'SUBMITTED';
                $log->assignment_updated_date = Carbon::now();
                $log->assignment_answers = $request->input('assignment_answers');
                $log->save();

                $course = $log->getCourse();

                if($course->instructor!=null){

                    $email = $course->instructor->email;
                    $lead = 'Dear '.$course->instructor->getFullName().',';
                    $content = '<p>'.$log->student->getFullName().' has submitted a new assignment on '.$course->course_name.' Module ['.$log->section->module->module_position.'] - ['.$log->section->module->module_name.'] at ['.Carbon::now()->format('Y/m/d H:i:s').'].</p>';
                    $content .= '<p>The ICAA Education team</p>';
                    $subject = 'Assignment Submission';


                    try {

                        Mail::to($email)->bcc(config('setting.general_bcc'))->send(new SystemEmail($lead,$content,$subject));

                    } catch(\Exception $e) {


                    }
                }

                return back()->with('message','Assignment has been sumitted successfully');

            }


        }

        return back()->with('error','Fail to submit');

    }


    public function testExplanation(Request $request,$section_id){

        $section = Section::find($section_id);

        if($section!=null){

            return response()->json([
                'status' => 'success',
                'explanation' => $section->section_explanation
            ]);
        }

        return response()->json([
            'status' => 'fail',
            'explanation' => ''
        ]);

    }

    public function showEnrollment(Request $request,$sid){

        $student = Student::find($sid);

		if($student != null){

            $enrollments = $student->enrollments;

            return view('backend.enrollment.index')
				->with('enrollments',$enrollments);
        }


    }


    public function reset(Request $request){

		return view('frontend.forget-password');

	}

	public function resetPost(Request $request){


			$validator = Validator::make($request->all(), [
				'student_email'  => 'required|email|max:255',
			]);

			if ($validator->fails()) {

				return redirect()->route('student.login.reset')
							->withErrors($validator)
							->withInput();
			}
			else{

				$student = Student::where('student_email',$request->input('student_email'))->first();

				if($student != null){

					$student->student_reset_token = Str::random(30);
					$student->student_reset_token_expiry_date = Carbon::now()->addMinutes(20);
					$student->save();

					$email = $student->student_email;
					$lead = 'Dear '.$student->student_first_name.' '.$student->student_last_name.',';
					$content = '<p>We received your request to reset your ICAA Education account’s password.<br/>Please click on the “RESET” link below to do so.</p>';
					$url = route('student.login.reset.password', ['student_id' => $student->student_id,'student_reset_token' => $student->student_reset_token]);
					$url_label = 'RESET PASSWORD NOW';
					$content .= '<p><a href="'.$url.'"><b>'.$url_label.'</b></a></p>';
                    $content .= '<p>If you need any future assistance, please email us at info@icaa.cc or call 866-335-9777.</p>';
                    $content .= '<p>All the best,</p>';
                    $content .= '<p>The ICAA Education team</p>';
					$subject = 'Reset your ICAA Education account’s password';




                    try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

					} catch(\Exception $e) {


                        return redirect()->route('student.login.reset')
							    ->withInput()
                                ->with('error','Fail to resend reset password email, please make sure you provid a valid email address.');

					}


					return redirect()->route('student.login')
					->with('message', 'You will receive email to reset your password shortly.');
				}
				else{
					return redirect()->route('student.login.reset')
						->with('error', 'Invalid user!');
				}




			}


	}

	public function resetPassword(Request $request,$student_id,$student_reset_token){

		$student = Student::find($student_id);

		if($student!=null){

			if($student_reset_token!=$student->student_reset_token || Carbon::now()->greaterThan($student->student_reset_token_expiry_date)){
				abort(404);
			}
			else{
				return view('frontend.reset-password')
						->with('student',$student);
			}
		}
		else{

			abort(404);
		}



	}

	public function resetPasswordPost(Request $request,$student_id,$student_reset_token){

		$student = Student::find($student_id);

		if($student!=null && $student_reset_token==$student->student_reset_token){

			$validator = Validator::make($request->all(), [
				'student_password'          => 'required|min:8|max:20',
				'student_password_confirm'  => 'required|same:student_password',
			]);

			if ($validator->fails()) {

				return redirect()->route('student.login.reset.password',['student_id'=>$student_id,'student_reset_token'=>$student_reset_token])
							->withErrors($validator)
							->withInput();
			}
			else{

				$student->student_password = Hash::make($request->input('student_password'));
				$student->student_reset_token = null;
				$student->student_reset_token_expiry_date = null;
				$student->save();
				return redirect()->route('student.login')
				->with('message', 'Pasword has been changed successfully.');
			}

		}
		else{

			return redirect()->route('student.login')
			->with('error', 'Invalid operation');
		}



	}


    public function checkCoursePermission_bak($course_id){

        if(Auth::check()){
            return true;
        }
        elseif(Auth::guard('student')->check()){

            $student = Auth::guard('student')->user();
            $enrollments = $student->enrollments()->pluck('enrollment_course_id')->toArray();

            if(in_array($course_id,$enrollments)){

                // $enrollment = $student->enrollments->where('enrollment_course_id',$course_id)->get();

                // return $enrollment;

                return true;
            }
            else{
                return false;
            }



        }

        return false;

    }


    public function checkCoursePermission($course_id){

        if(Auth::check()){

            return Helpers::hasAssignmentPermission($course_id);
        }
        elseif(Auth::guard('student')->check()){

            $student = Auth::guard('student')->user();


            $enrollment = $student->enrollments()
                            ->where('enrollment_course_id',$course_id)
                            ->where(function ($query) {
                                $query->where('enrollment_status','IN_PROGRESS')
                                      ->orWhere('enrollment_status','COMPLETE');
                            })
                            ->orderBy('updated_at','desc')->get()->first();

            //if($enrollment!=null && $enrollment->enrollment_expiry_date>=Carbon::now()){
            if($enrollment!=null){

                return true;

            }

        }

        return false;

    }


    public function complete(Request $request,$course_id){

        $course = Course::find($course_id);


        if($course!=null){

            return view('frontend.courses.complete')
						->with('course',$course);

        }


    }

    public function emailtest(Request $request){


        $enrollment = Enrollment::find(620);

        $course_name = $enrollment->course->course_name;

        $student = $enrollment->student;

        $email = 'kelvinling@eseelynx.com';
        $name = $student->getFullName();
        $course_name = 'Leadership in Wellness Management Certificate Course';
        $course_slug = 'leadership-in-wellness-management-certificate-course';
        $lead = 'Dear '.$name.',';
        $content = '<p>Congratulations on completing '.$course_name.' course work. As one of an elite group invested in advancing the aging and wellness profession, you have learned valuable skills and knowledge that will support your wellness endeavors.</p>';
        $content .= '<p>We trust that this accomplishment has been personally and professionally challenging and fulfilling, and you and your organization should be proud.</p>';
        $content .= '<p>Attached is the '.$course_name.' Certificate. To highlight your commitment to professional development we have enclosed, for your use, the course graduation logo and support materials.</p>';
        $content .= '<p>Please note that you can audit this course at any time.</p>';
        $content .= '<p>Thank you for your commitment to our industry, and congratulations once again.</p>';
        $content .= '<p>Sincerely,</p>';
        $content .= '<p>Colin Milner<br>CEO<br>International Council on Active Aging<br><a href="mailto:colinmilner@icaa.cc">colinmilner@icaa.cc</a><br><a href="https://www.icaa.cc">www.icaa.cc</a><br>866-335-97776</p>';
        $subject = $course_name.' Completion';

        $pdf = PDF::loadView('frontend.courses.certificate-pdf', ['enrollment'=>$enrollment])->setPaper([0, 0, 905, 1190], 'landscape');

        try {

            $systemEmail = new SystemEmail($lead,$content,$subject);
            $systemEmail->attachData($pdf->output(), "certificate.pdf");

            $slug = $enrollment->course->course_slug;

            if(Storage::exists('attachments/'.$slug)){

                $files = Storage::files('attachments/'.$slug);

                foreach ($files as $file){
                    $systemEmail->attachFromStorage($file);
                }

            }

            Mail::to($email)->send($systemEmail);

        } catch(\Exception $e) {

        }

    }


    public function broadcast(Request $request){

        $students = [
            [
                'name'=>'kelvni ling',
                'email'=>'kelvinling@eseelynx.com',
            ],
            [
                'name'=>'kelvin ling',
                'email'=>'kelvinling@gmail.com',
            ],
        ];

        foreach($students as $index=>$student){

            $email = $student['email'];
            $name = $student['name'];
            $lead = 'Dear '.$name.',';
            $content = '<p>Please reset your password by clicking <a href="https://education.icaa.cc/login/reset">here</a>.</p>';
            $content .= '<p>The ICAA Education team</p>';
            $subject = 'You got a new message from ICAA Education';

            try {

                Mail::to($email)->bcc(config('setting.admin_bcc'))->send(new SystemEmail($lead,$content,$subject));

                echo $name.'['.$email.']'.' sending complete!<br/>';

            } catch(\Exception $e) {

                echo $name.'['.$email.']'.' sending error!<br/>';
            }


        }



    }








}
