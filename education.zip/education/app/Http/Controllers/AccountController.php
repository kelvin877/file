<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Mail\SystemEmail;
use App\Mail\CleanEmail;
use App\Models\Role;
use App\Models\User;
use Carbon\Carbon;

class AccountController extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth.admin',['except' => ['confirm','login','adminLogin','uploadAvatar','showAvatar','reset','resetPost','resetPassword','resetPasswordPost']]);
        
    }

	public function hasPermission(){

		if(Auth::user()->isAdmin()){
			return true;
		}

		return false;
	}

    

	public function index(){

		$users = User::paginate(10);

		return view('backend.users.index')
				->with('users',$users);
	}

	public function create(){

		$roles = Role::all();
		return view('backend.users.create')
				->with('roles',$roles);
	}

	public function store(Request $request){


		if($request->has('active')&&$request->input('active')=='Yes'){
			$request->merge(['active'=>'Yes']);
		}
		else{
			$request->merge(['active'=>'No']);
		}

		$social_media = [
			'facebook' => $request->input('facebook-link'),
			'twitter'	=> $request->input('twitter-link'),
			'instagram' => $request->input('instagram-link')
		];

		$request->merge(['social_media'=>$social_media]);

		$validator = Validator::make($request->all(), [
			'user_role_id'          => 'required|max:10',
			'name'                  => 'max:255',
			'first_name'            => 'required|max:255',
			'last_name'             => 'required|max:255',
			'email'                 => 'required|email|unique:users,email|max:255',
			'email_verified_at'     => 'nullable',
			'password'              => 'required|min:8|max:20',
			'password_confirm'		=> 'required|same:password', 
			'profile'               => 'nullable',
			'social_media'          => 'nullable',
			'last_login'            => 'nullable',
			'active'                => 'nullable',
			'confirmed'             => 'nullable',
			'confirmation_code'     => 'nullable',
		]);

		if ($validator->fails()) {
            return redirect()->route('admin.users.create')
                        ->withErrors($validator)
                        ->withInput();
        }
		else{
			
			$confirmation_code = Str::random(30);
			
			$user = User::create([
				'user_role_id'			=> $request->input('user_role_id'),
				'name'					=> $request->input('name'),
				'first_name'			=> $request->input('first_name'),
				'last_name'				=> $request->input('last_name'),
				'email'					=> $request->input('email'),
				'password'				=> Hash::make($request->input('password')),
				'profile'				=> $request->input('profile'),  
				'social_media'          => $request->input('social_media'),
				'active'				=> $request->input('active'),
				'confirmation_code' 	=> $confirmation_code
			]);
			
			$email = $request->input('email');
			$lead = $user->first_name.' '.$user->last_name.': Verify your account';
			$content = '<p>Please click the following link to verify your account.</p>';
			$content .= '<p>USERNAME: '.$request->input('email').'<br />PASSWORD: '.$request->input('password').'</p>';
			$url = route('account.verify', ['confirmation_code' => $confirmation_code]);
			$url_label = 'Verify Here';
			$content .= '<a href="'.$url.'">'.$url_label.'</a>';
			$subject = 'Please verify your email';


			try {

				Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

			} catch(\Exception $e) {

				
				$user->delete();

				return redirect()->route('admin.users.create')
                        ->withInput()
						->with('error','Fail to send the verification email. Please make sure you provide a valid email address or check the email server status.');
			}

			

			
			return redirect()->route('admin.users.edit',['uid'=>$user->id])->with('message','User has been created! You can also fill in the profile detail below.');
		}
	}

	public function show($id){

	}

	public function edit($id){
		
		$user = User::find($id);

		if($user != null){

			$roles = Role::all();

			return view('backend.users.edit')
				->with('user',$user)
				->with('roles',$roles);
		}
	}

	

	public function update(Request $request,$id){

		$user = User::find($id);

		if($user != null){

			if($request->has('active')&&$request->input('active')=='Yes'){
				$request->merge(['active'=>'Yes']);
			}
			else{
				$request->merge(['active'=>'No']);
			}

			$social_media = [
				'facebook' => $request->input('facebook-link'),
				'twitter'	=> $request->input('twitter-link'),
				'instagram' => $request->input('instagram-link')
			];

			$request->merge(['social_media'=>$social_media]);

			$validator = Validator::make($request->all(), [
				'name'                  => 'max:255',
				'first_name'            => 'required|max:255',
				'last_name'             => 'required|max:255',
				'email'                 => 'required|email|unique:users,email,'.$id.'|max:255',
				'password'              => 'min:8|max:20|nullable',
				'password_confirm'		=> 'same:password|nullable', 
				'profile'               => 'nullable',
				'social_media'          => 'nullable',
				'active'                => 'nullable'
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.users.edit',['uid'=>$user->id])
							->withErrors($validator)
							->withInput();
			}
			else{
				
				$pass_input = $request->input('password');
				
				if(empty($pass_input)){
					
					$user->update([
						'name'					=> $request->input('name'),
						'first_name'			=> $request->input('first_name'),
						'last_name'				=> $request->input('last_name'),
						'email'					=> $request->input('email'),
						'profile'				=> $request->input('profile'),  
						'social_media'          => $request->input('social_media'),
						'active'				=> $request->input('active')
					]);
					
				}
				else{
					
					$user->update([
						'name'					=> $request->input('name'),
						'first_name'			=> $request->input('first_name'),
						'last_name'				=> $request->input('last_name'),
						'email'					=> $request->input('email'),
						'password'				=> Hash::make($request->input('password')),
						'profile'				=> $request->input('profile'),  
						'social_media'          => $request->input('social_media'),
						'active'				=> $request->input('active')
					]);
					
				}
			}

			return redirect()->route('admin.users.edit',['uid'=>$user->id])
						->with('message','User has been updated successfully!');
		}

		
	}

	public function destroy(Request $request,$id){

		User::destroy($id);

		$this->removeAvatar($request, $id);

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted user.',
		]);
	}
	
	public function destroyMany(Request $request){


		$ids = explode(",",$request->input('ids'));

		User::destroy($ids);

		foreach($ids as $id){
			$this->removeAvatar($request, $id);
		}

		return response()->json([
			'status' => 'success',
			'message' => 'Successfully deleted users.',
		]);
	}

	public function resendConfirmationCode(Request $request,$id){

		$user = User::find($id);

		if($user != null){

			$confirmation_code = Str::random(30);

			$user->confirmed = 'No';
			$user->confirmation_code = $confirmation_code;
			$user->save();

			$email = $user->email;
			$lead = $user->first_name.' '.$user->last_name.': Verify your account';
			$content = '<p>Please click the following link to verify your account.</p>';
			$content .= '<p>USERNAME: '.$user->email.'<br />PASSWORD: '.$request->input('password').'</p>';
			$url = route('account.verify', ['confirmation_code' => $confirmation_code]);
			$url_label = 'Verify Here';
			$content .= '<a href="'.$url.'">'.$url_label.'</a>';
			$subject = 'Please verify your email';



			try {

				Mail::to($email)->send(new SystemEmail($lead,$content,$subject));

			} catch(\Exception $e) {
				
				return response()->json([
					'status' => 'failure',
					'message' => 'Fail to resend confirmation code. Please check your provided email address or the email server status.',
				]);
			}


			return response()->json([
				'status' => 'success',
				'message' => 'Successfully resend confirmation code.',
			]);

		}
		
		return response()->json([
			'status' => 'failure',
			'message' => 'Fail to resend confirmation code.',
		]);

	
	}

	public function profile(){

		$user = Auth::user();

		if($user != null){

			return view('backend.users.profile')
				->with('user',$user);
		}
	}

	public function profileUpdate(Request $request){

		$user = Auth::user();

		if($user != null){

			$social_media = [
				'facebook' => $request->input('facebook-link'),
				'twitter'	=> $request->input('twitter-link'),
				'instagram' => $request->input('instagram-link')
			];

			$request->merge(['social_media'=>$social_media]);

			$validator = Validator::make($request->all(), [
				'name'                  => 'max:255',
				'first_name'            => 'required|max:255',
				'last_name'             => 'required|max:255',
				'password'              => 'min:8|max:20|nullable',
				'password_confirm'		=> 'same:password|nullable', 
				'profile'               => 'nullable',
				'social_media'          => 'nullable',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.profile')
							->withErrors($validator)
							->withInput();
			}
			else{
				
				$pass_input = $request->input('password');
				
				if(empty($pass_input)){
					
					$user->update([
						'name'					=> $request->input('name'),
						'first_name'			=> $request->input('first_name'),
						'last_name'				=> $request->input('last_name'),
						'profile'				=> $request->input('profile'),  
						'social_media'          => $request->input('social_media'),
					]);
					
				}
				else{
					
					$user->update([
						'name'					=> $request->input('name'),
						'first_name'			=> $request->input('first_name'),
						'last_name'				=> $request->input('last_name'),
						'password'				=> Hash::make($request->input('password')),
						'profile'				=> $request->input('profile'),  
						'social_media'          => $request->input('social_media'),
					]);
					
				}
			}

			return redirect()->route('admin.dashboard');
		}

		
	}

	public function reset(Request $request){

		return view('backend.forget-password');

	}

	public function resetPost(Request $request){


			$validator = Validator::make($request->all(), [
				'email'  => 'required|email|max:255',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.login.reset')
							->withErrors($validator)
							->withInput();
			}
			else{
				
				$user = User::where('email',$request->input('email'))->first();

				if($user != null){

					$user->reset_token = Str::random(30);
					$user->reset_token_expiry_date = Carbon::now()->addMinutes(20);
					$user->save();

					$email = $user->email;
					$lead = $user->first_name.' '.$user->last_name.': Reset your password';
					$content = '<p>Please click the following link to reset your password.</p>';
					$content .= '<p>USERNAME: '.$user->email.'</p>';
					$url = route('admin.login.reset.password', ['uid' => $user->id,'reset_token' => $user->reset_token]);
					$url_label = 'Reset Here';
					$content .= '<a href="'.$url.'">'.$url_label.'</a>';
					$subject = 'Email to reset your password';


					try {

						Mail::to($email)->send(new SystemEmail($lead,$content,$subject));
		
					} catch(\Exception $e) {
						
						return redirect()->route('admin.login.reset')->with('error','Fail to send the email. Please make sure you provide a valid email address or check the email server status.');
					}


					return redirect()->route('admin.login')
					->with('message', 'You will receive email to reset your password shortly.');
				}
				else{
					return redirect()->route('admin.login.reset')
						->with('error', 'Invalid user!');
				}
				
				
				
				
			}


	}

	public function resetPassword(Request $request,$uid,$reset_token){

		$user = User::find($uid);

		if($user!=null){
			
			if($reset_token!=$user->reset_token || Carbon::now()->greaterThan($user->reset_token_expiry_date)){
				abort(404);
			}
			else{
				return view('backend.reset-password')
						->with('user',$user);
			}
		}
		else{

			abort(404);
		}

		

	}

	public function resetPasswordPost(Request $request,$uid,$reset_token){

		$user = User::find($uid);

		if($user!=null && $reset_token==$user->reset_token){

			$validator = Validator::make($request->all(), [
				'password'  		=> 'required|min:8',
				'confirm-password'  => 'same:password',
			]);
	
			if ($validator->fails()) {
				
				return redirect()->route('admin.login.reset.password',['uid'=>$uid,'reset_token'=>$reset_token])
							->withErrors($validator)
							->withInput();
			}
			else{
				
				$user->password = Hash::make($request->input('password'));
				$user->reset_token = null;
				$user->reset_token_expiry_date = null;
				$user->save();
				return redirect()->route('admin.login')
				->with('message', 'Pasword has been changed successfully.');
			}
			
		}
		else{

			return redirect()->route('admin.login')
			->with('error', 'Invalid operation');
		}

		

	}


	public function adminLogin(Request $request){

		if(Auth::guard('student')->check()){
    	
			Auth::guard('student')->logout();
		}


		if ( Auth::attempt(array('email' => $request->input('email'), 'password' => $request->input('password'))) )
		{

		
			if (Auth::check())
			{
					
					if(Auth::user()->confirmed=='No'){
						
						Auth::logout();
						return redirect()->route('admin.login')
							->with('error', 'Your email address has not been verified!');
							
					}elseif(Auth::user()->active=='No'){
					
						Auth::logout();
						return redirect()->route('admin.login')
							->with('error', 'Your account is inactive!');
						
					}

					$user = Auth::user();
					$user->last_login = Carbon::now();
					$user->save();
					
					return redirect()->route('admin.dashboard');
					
				
			}
			return 'not logged in';
			
		}else{
		
			return redirect()->route('admin.login')
        		->with('error', 'Your email / password combination was incorrect')
        		->withInput();
			
		}
		
	}

    public function adminLogout(){
	
	
		if(Auth::check()){
		
			Auth::logout();
			return redirect()->route('admin.login');
		}


	}

	public function showAvatar(Request $request,$uid){
	
	
	    if(Storage::exists('avatar/'.$uid.'.jpg')){
				
			return response()->file(storage_path('app/avatar/'.$uid.'.jpg'),['Content-Type'=>'image/jpeg']);
		
		}
		else{
		
			return response()->file(public_path('assets/images/avatar/user.jpg'),['Content-Type'=>'image/jpeg']);
		}
	    
	    
    }


	public function uploadAvatar(Request $request,$uid){
		
		$response = $request->input('avatar-file');
		
		$response = json_decode($response, true);
		
		$field =  $response['output']['field'];
		
		if (request()->hasFile($field)) {
			
		    $file = request()->file($field)->storeAs(
			    'avatar', $uid.'.jpg'
			);
			
			return response()->json([
			    'status' => 'success',
			    'name' => $uid.'.jpg',
			    'path' => $file
			]);
		    
		}

        return response()->json([
			    'status' => 'failure',
			    'message' => 'fail to upload'
			]);
		

	}
	
	public function removeAvatar(Request $request,$uid){
		
		$user = User::find($uid);
		
		
		if(Auth::user()->isAdmin() || $user->id==Auth::user()->id){
			
			if(Storage::exists('avatar/'.$uid.'.jpg')){
					
				Storage::delete('avatar/'.$uid.'.jpg');
				return response()->json([
			    'status' => 'success',
			    'name' => $uid.'.jpg'
				]);
			
			}
			else{
				
				return response()->json([
			    'status' => 'failure',
			    'message' => 'Avatar does not exist'
				]);
			}

		}
		else{
			
			return response()->json([
			    'status' => 'failure',
			    'message' => 'You do not have permission to delete this avatar'
			]);
		}
	}


	public function confirm(Request $request,$confirmation_code)
    {
    
    	if(Auth::check()){
    	
    		Auth::logout();
    	}
    	
        if( ! $confirmation_code)
        {
            return redirect()->route('admin.login')
        		->with('error', 'Verification code missing, we are not able to verify your account.');
        }

        $user = User::whereConfirmationCode($confirmation_code)->first();

        if ( ! $user)
        {
            return redirect()->route('admin.login')
        		->with('error', 'The verification code is no longer valid. Your account may have already been verified.');
        }

        $user->confirmed = 'Yes';
        $user->confirmation_code = null;
        $user->save();


        return redirect()->route('admin.login')
        		->with('message', 'Account has been verified successfully.');
    }
	
}
